module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// object to store loaded chunks
/******/ 	// "0" means "already loaded"
/******/ 	var installedChunks = {
/******/ 		"pages/index": 0
/******/ 	};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// uncaught error handler for webpack runtime
/******/ 	__webpack_require__.oe = function(err) {
/******/ 		process.nextTick(function() {
/******/ 			throw err; // catch this error by using import().catch()
/******/ 		});
/******/ 	};
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/head":
/*!****************************************************!*\
  !*** external "next/dist/next-server/lib/head.js" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/head.js");

/***/ }),

/***/ "../next-server/lib/to-base-64":
/*!**********************************************************!*\
  !*** external "next/dist/next-server/lib/to-base-64.js" ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/to-base-64.js");

/***/ }),

/***/ "../next-server/server/image-config":
/*!***************************************************************!*\
  !*** external "next/dist/next-server/server/image-config.js" ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/server/image-config.js");

/***/ }),

/***/ "./components/Layout/components/Footer.jsx":
/*!*************************************************!*\
  !*** ./components/Layout/components/Footer.jsx ***!
  \*************************************************/
/*! exports provided: Footer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Footer", function() { return Footer; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/icons/Facebook */ "@material-ui/icons/Facebook");
/* harmony import */ var _material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons/Instagram */ "@material-ui/icons/Instagram");
/* harmony import */ var _material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_icons_LinkedIn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/icons/LinkedIn */ "@material-ui/icons/LinkedIn");
/* harmony import */ var _material_ui_icons_LinkedIn__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_LinkedIn__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_icons_MailOutline__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/icons/MailOutline */ "@material-ui/icons/MailOutline");
/* harmony import */ var _material_ui_icons_MailOutline__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_MailOutline__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_icons_Phone__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/icons/Phone */ "@material-ui/icons/Phone");
/* harmony import */ var _material_ui_icons_Phone__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Phone__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_icons_LocationOn__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/icons/LocationOn */ "@material-ui/icons/LocationOn");
/* harmony import */ var _material_ui_icons_LocationOn__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_LocationOn__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _config_serverKey__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../config/serverKey */ "./components/config/serverKey.js");
/* harmony import */ var _config_CustomApi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../config/CustomApi */ "./components/config/CustomApi.js");

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\Footer.jsx";









const Footer = () => {
  const {
    0: data,
    1: setData
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    Object(_config_CustomApi__WEBPACK_IMPORTED_MODULE_9__["getApi"])().then(data => {
      console.log(data);
      setData(data);
    });
  }, []);
  const phone_no = data === null || data === void 0 ? void 0 : data.phone;
  const whatsapp_no = data === null || data === void 0 ? void 0 : data.wp_links;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("footer", {
      id: "footertop",
      className: "footer",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "container-section",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "SocialButton",
          id: "SocailSection",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                className: phone_no || _config_serverKey__WEBPACK_IMPORTED_MODULE_8__["STATIC_PHONE"],
                href: "tel:" + `${phone_no}`,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                  src: "assest/images/phone.png",
                  alt: "phoneImg"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 34,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 30,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 29,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                className: "whatsap_url",
                href: `${whatsapp_no}` + "!I want to know about Project_name",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                  src: "assest/images/whatsapp.png",
                  alt: "whatsappImg"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 39,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 38,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 37,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row align-items-top",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-lg-4 col-12 mt-sm-0 pt-2 pt-sm-0",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "title-heading",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "media contact-detail align-items-center mt-3",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "icon",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_MailOutline__WEBPACK_IMPORTED_MODULE_5___default.a, {
                    className: "fea icon-m-md text-light mr-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 49,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 48,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "media-body content",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
                    className: "title font-weight-bold mb-0",
                    children: "Email"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 52,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/# ",
                    id: "peplemail",
                    className: "text-primary",
                    children: "info@homesfy.in"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 53,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 51,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 47,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "media contact-detail align-items-center mt-3",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "icon",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_Phone__WEBPACK_IMPORTED_MODULE_6___default.a, {
                    className: "fea icon-m-md text-light mr-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 60,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 59,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "media-body content",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
                    className: "title font-weight-bold mb-0",
                    children: "Phone"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 63,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "tel:02240375730",
                    className: "text-primary btn-call",
                    id: "peplphone",
                    children: "02240375730"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 64,
                    columnNumber: 21
                  }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 71,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 62,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 58,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "media contact-detail align-items-center mt-3",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "icon",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_LocationOn__WEBPACK_IMPORTED_MODULE_7___default.a, {
                    className: "fea icon-m-md text-light mr-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 76,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 75,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "media-body content",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
                    className: "title font-weight-bold mb-0",
                    children: "Location"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 79,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                    children: "24, Myworkarea, Benaka Complex, 2nd Cross, Sirur Park Road, Sheshadripuram, Bangalore- 560020"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 80,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 78,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 74,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
                className: "list-unstyled social-icon mb-0 mt-4",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  className: "list-inline-item",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "https://www.facebook.com/homesfy",
                    target: "_new",
                    className: "rounded",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_2___default.a, {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 93,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 88,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 87,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  className: "list-inline-item",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "https://www.instagram.com/homesfyindia/?igshid=1hua89m9py0ue",
                    target: "_new",
                    className: "rounded",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_3___default.a, {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 102,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 97,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 96,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  className: "list-inline-item",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "https://www.linkedin.com/company/3374706/",
                    target: "_new",
                    className: "rounded",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_LinkedIn__WEBPACK_IMPORTED_MODULE_4___default.a, {}, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 111,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 106,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 105,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 86,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
              className: "text-light footer-head",
              children: "Ready Homes"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 118,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "list-unstyled footer-list mt-4",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "https://south-bangalore.prestige-realty.in/",
                  className: "text-foot",
                  target: "_new",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                    className: "mdi mdi-chevron-right mr-1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 126,
                    columnNumber: 21
                  }, undefined), " Prestige song of the south"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 121,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 120,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "https://royale-gardens.prestige-realty.in/",
                  className: "text-foot",
                  target: "_new",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                    className: "mdi mdi-chevron-right mr-1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 136,
                    columnNumber: 21
                  }, undefined), " Prestige Royale Gardens"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 131,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 130,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "https://www.prestige-realty.in/prestige-augusta/",
                  className: "text-foot",
                  target: "_new",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                    className: "mdi mdi-chevron-right mr-1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 146,
                    columnNumber: 21
                  }, undefined), " Prestige Augusta Golf Village"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 141,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 140,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "https://www.prestige-realty.in/prestige-lake/",
                  className: "text-foot",
                  target: "_new",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                    className: "mdi mdi-chevron-right mr-1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 156,
                    columnNumber: 21
                  }, undefined), " Prestige Lake Ridge"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 151,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 150,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 119,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 117,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
              className: "text-light footer-head",
              children: "Homes Ongoing"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 163,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "list-unstyled footer-list mt-4",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "https://www.prestige-realty.in/finsbury-park/",
                  className: "text-foot",
                  target: "_new",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                    className: "mdi mdi-chevron-right mr-1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 171,
                    columnNumber: 21
                  }, undefined), " Prestige Finsburry"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 166,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 165,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "https://jindal-city.prestige-realty.in/",
                  className: "text-foot",
                  target: "_new",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                    className: "mdi mdi-chevron-right mr-1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 181,
                    columnNumber: 21
                  }, undefined), " Prestige Jindal City"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 176,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 175,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 164,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 162,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-lg-2 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
              className: "text-light footer-head",
              children: "Useful Links"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 188,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "list-unstyled footer-list mt-4",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "https://www.homesfy.in/about-us.html",
                  className: "text-foot",
                  target: "_new",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                    className: "mdi mdi-chevron-right mr-1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 196,
                    columnNumber: 21
                  }, undefined), " About us"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 191,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 190,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "https://www.homesfy.in/rera.html",
                  className: "text-foot",
                  target: "_new",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                    className: "mdi mdi-chevron-right mr-1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 205,
                    columnNumber: 21
                  }, undefined), " About Rera"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 200,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 199,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "https://www.homesfy.in/privacy.html",
                  className: "text-foot",
                  target: "_new",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                    className: "mdi mdi-chevron-right mr-1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 214,
                    columnNumber: 21
                  }, undefined), " Privacy Policy"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 209,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 208,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "https://www.homesfy.in/terms.html",
                  className: "text-foot",
                  target: "_new",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                    className: "mdi mdi-chevron-right mr-1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 224,
                    columnNumber: 21
                  }, undefined), " Terms & Conditions"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 219,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 218,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 189,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 187,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 6
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("footer", {
      className: "footer footer-bar",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "container-section text-center",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row align-items-center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-sm-12",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-sm-center",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                className: "mb-3",
                children: "Disclaimer:The content is for information purposes only and does not constitute an offer to avail of any service. Prices mentioned are subject to change without notice and properties mentioned are subject to availability. Images for representation purpose only. This is not the official website. Website maintained by our online marketing agency pact partners. We may share data with rera registered brokers/companies for further processing. We may also send updates to the mobile number/email id registered with us. You may unsubscribe anytime by writing to us at unsubscribe@pactpartners.in All Rights Reserved."
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 238,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 237,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 236,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 235,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 234,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 233,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 24,
    columnNumber: 9
  }, undefined);
};

/***/ }),

/***/ "./components/Layout/components/Header.jsx":
/*!*************************************************!*\
  !*** ./components/Layout/components/Header.jsx ***!
  \*************************************************/
/*! exports provided: Header */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Header", function() { return Header; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/AppBar */ "@material-ui/core/AppBar");
/* harmony import */ var _material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_Toolbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Toolbar */ "@material-ui/core/Toolbar");
/* harmony import */ var _material_ui_core_Toolbar__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Toolbar__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Typography */ "@material-ui/core/Typography");
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/IconButton */ "@material-ui/core/IconButton");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/icons/Menu */ "@material-ui/icons/Menu");
/* harmony import */ var _material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/icons */ "@material-ui/icons");
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _config_serverKey__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../config/serverKey */ "./components/config/serverKey.js");
/* harmony import */ var _config_CustomApi__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../config/CustomApi */ "./components/config/CustomApi.js");

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\Header.jsx";






 // import { PROJECT_LOGO, STATIC_PHONE } from "../config/serverKey";





const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_8__["makeStyles"])(theme => ({
  root: {
    flexGrow: 1
  },
  menuButton: {
    marginRight: theme.spacing(2)
  },
  title: {
    flexGrow: 1
  }
}));
const Header = ({
  article
}) => {
  const {
    bangaloreProjectsList,
    bangaloreProjectLinks
  } = article.fields;
  const {
    0: open,
    1: setOpen
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);

  const handleDrawer = () => {
    setOpen(true);
  };

  const {
    0: data,
    1: setData
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    Object(_config_CustomApi__WEBPACK_IMPORTED_MODULE_11__["getApi"])().then(data => {
      setData(data);
    });
  }, []);
  const classes = useStyles();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "top_head",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: classes.root,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["CssBaseline"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Toolbar__WEBPACK_IMPORTED_MODULE_3___default.a, {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_4___default.a, {
              variant: "h6",
              className: classes.title,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                src: "https://www.prestigeconstructions.com/images/logo.png",
                alt: "logo"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 48,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "navigation-menu mobBlock",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/#",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    children: "Home"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 56,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 55,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 54,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                className: "has-submenu ",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/#",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    children: ["Projects ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "menu-arrow"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 62,
                      columnNumber: 32
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 61,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 60,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
                  className: "submenu",
                  children: bangaloreProjectsList.map((item, i) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                      href: bangaloreProjectLinks[i],
                      target: "_new",
                      children: bangaloreProjectsList[i]
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 69,
                      columnNumber: 23
                    }, undefined)
                  }, i, false, {
                    fileName: _jsxFileName,
                    lineNumber: 68,
                    columnNumber: 23
                  }, undefined))
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 65,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 59,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/#",
                  "data-toggle": "modal",
                  "data-target": "#mymodal",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    children: "Contact us"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 79,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 78,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 77,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/#",
                  "data-toggle": "modal",
                  "data-target": "#mymodal",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    children: "Luxury Homes"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 84,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 83,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 82,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/#",
                  "data-toggle": "modal",
                  "data-target": "#mymodal",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    children: "Ready Homes"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 89,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 88,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 87,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 53,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_5___default.a, {
                onClick: handleDrawer,
                edge: "start",
                className: `${classes.menuButton} `,
                color: "inherit",
                "aria-label": "menu",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_6___default.a, {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 101,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 94,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 93,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 46,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 45,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__["Drawer"], {
          anchor: "right",
          open: open,
          onClose: () => {
            setOpen(false);
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              height: "100vh",
              padding: "20px 40px",
              width: "415px"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_5___default.a, {
              onClick: () => {
                setOpen(false);
              },
              color: "primary",
              style: {
                position: "absolute",
                right: "0",
                top: "-3px"
              },
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons__WEBPACK_IMPORTED_MODULE_9__["CloseOutlined"], {
                color: "primary"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 123,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 116,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "demo-list",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                      href: "#about_us",
                      children: "About Us "
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 129,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 128,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                      href: "/#",
                      "data-toggle": "modal",
                      "data-target": "#mymodal",
                      children: ["Contact us", " "]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 132,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 131,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                      href: "/#",
                      "data-toggle": "modal",
                      "data-target": "#mymodal",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        children: "Luxury Homes"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 138,
                        columnNumber: 25
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 137,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 136,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                      href: "/#",
                      "data-toggle": "modal",
                      "data-target": "#mymodal",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        children: "Ready Homes"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 143,
                        columnNumber: 25
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 142,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 141,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                      className: "phone_url",
                      href: "tel:07949130465",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "phone_no",
                        children: (data === null || data === void 0 ? void 0 : data.phone) || _config_serverKey__WEBPACK_IMPORTED_MODULE_10__["STATIC_PHONE"]
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 148,
                        columnNumber: 25
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 147,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 146,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 127,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 126,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 125,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 113,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 106,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 41,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./components/Layout/components/page_component/BangaloreProject.jsx":
/*!**************************************************************************!*\
  !*** ./components/Layout/components/page_component/BangaloreProject.jsx ***!
  \**************************************************************************/
/*! exports provided: BangaloreProject */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BangaloreProject", function() { return BangaloreProject; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dynamic */ "next/dynamic");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! owl.carousel/dist/assets/owl.carousel.css */ "./node_modules/owl.carousel/dist/assets/owl.carousel.css");
/* harmony import */ var owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! owl.carousel/dist/assets/owl.theme.default.css */ "./node_modules/owl.carousel/dist/assets/owl.theme.default.css");
/* harmony import */ var owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_icons_AirlineSeatFlat__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/icons/AirlineSeatFlat */ "@material-ui/icons/AirlineSeatFlat");
/* harmony import */ var _material_ui_icons_AirlineSeatFlat__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_AirlineSeatFlat__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\page_component\\BangaloreProject.jsx";

const OwlCarousel = next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(() => Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(null, /*! react-owl-carousel */ "react-owl-carousel", 7)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! react-owl-carousel */ "react-owl-carousel")],
    modules: ["..\\components\\Layout\\components\\page_component\\BangaloreProject.jsx -> " + 'react-owl-carousel']
  }
});



const BangaloreProject = ({
  article
}) => {
  const {
    projectsInBangalore,
    bangaloreSlide1Address,
    bangaloreSlide1BedInfo,
    bangaloreSlide1PriceInfo
  } = article.fields;
  const state1 = {
    responsive: {
      0: {
        items: 1
      },
      450: {
        items: 2
      },
      600: {
        items: 3
      },
      1000: {
        items: 3
      }
    }
  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(OwlCarousel, {
        items: 3,
        className: "owl-theme",
        loop: true,
        nav: true,
        margin: 20,
        responsive: state1.responsive,
        children: projectsInBangalore.map((item, i) => {
          var _projectsInBangalore$, _projectsInBangalore$2, _projectsInBangalore$3, _projectsInBangalore$4, _projectsInBangalore$5, _projectsInBangalore$6, _projectsInBangalore$7, _projectsInBangalore$8, _projectsInBangalore$9;

          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "card border-0 work-container work-grid position-relative d-block",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "card-body p-0",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "/#",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                  src: (_projectsInBangalore$ = projectsInBangalore[i]) === null || _projectsInBangalore$ === void 0 ? void 0 : (_projectsInBangalore$2 = _projectsInBangalore$.fields) === null || _projectsInBangalore$2 === void 0 ? void 0 : (_projectsInBangalore$3 = _projectsInBangalore$2.file) === null || _projectsInBangalore$3 === void 0 ? void 0 : _projectsInBangalore$3.url,
                  className: "img-fluid",
                  alt: (_projectsInBangalore$4 = projectsInBangalore[i]) === null || _projectsInBangalore$4 === void 0 ? void 0 : (_projectsInBangalore$5 = _projectsInBangalore$4.fields) === null || _projectsInBangalore$5 === void 0 ? void 0 : _projectsInBangalore$5.title
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 49,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 48,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "content bg-white p-3",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
                  className: "mb-0",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/#",
                    children: (_projectsInBangalore$6 = projectsInBangalore[i]) === null || _projectsInBangalore$6 === void 0 ? void 0 : (_projectsInBangalore$7 = _projectsInBangalore$6.fields) === null || _projectsInBangalore$7 === void 0 ? void 0 : _projectsInBangalore$7.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 57,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 56,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "text-muted tag mb-0",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/#",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                      className: "subtitle",
                      children: bangaloreSlide1Address[i]
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 61,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 60,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 59,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "post-meta d-flex justify-content-between mt-3",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
                    className: "list-unstyled mb-0",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                      className: "list-inline-item mr-3",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                        className: "mdi mdi-bed-empty mdi-24px mr-2",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_AirlineSeatFlat__WEBPACK_IMPORTED_MODULE_4___default.a, {}, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 68,
                          columnNumber: 27
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 67,
                        columnNumber: 25
                      }, undefined), bangaloreSlide1BedInfo[i]]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 65,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    className: "btn btn-sm btn-info",
                    "data-toggle": "modal",
                    "data-target": "#mymodal",
                    href: "/#",
                    children: bangaloreSlide1PriceInfo[i]
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 73,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 64,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 55,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "read_more pstatus text-center rounded-circle",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "statusl_Ready",
                  children: (_projectsInBangalore$8 = projectsInBangalore[i]) === null || _projectsInBangalore$8 === void 0 ? void 0 : (_projectsInBangalore$9 = _projectsInBangalore$8.fields) === null || _projectsInBangalore$9 === void 0 ? void 0 : _projectsInBangalore$9.description
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 84,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 83,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 15
            }, undefined)
          }, i, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 13
          }, undefined);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./components/Layout/components/page_component/BangaloreSlide2.jsx":
/*!*************************************************************************!*\
  !*** ./components/Layout/components/page_component/BangaloreSlide2.jsx ***!
  \*************************************************************************/
/*! exports provided: BangaloreSlide2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BangaloreSlide2", function() { return BangaloreSlide2; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_icons_AirlineSeatFlat__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/icons/AirlineSeatFlat */ "@material-ui/icons/AirlineSeatFlat");
/* harmony import */ var _material_ui_icons_AirlineSeatFlat__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_AirlineSeatFlat__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dynamic */ "next/dynamic");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! owl.carousel/dist/assets/owl.carousel.css */ "./node_modules/owl.carousel/dist/assets/owl.carousel.css");
/* harmony import */ var owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! owl.carousel/dist/assets/owl.theme.default.css */ "./node_modules/owl.carousel/dist/assets/owl.theme.default.css");
/* harmony import */ var owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\page_component\\BangaloreSlide2.jsx";


const OwlCarousel = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(() => Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(null, /*! react-owl-carousel */ "react-owl-carousel", 7)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! react-owl-carousel */ "react-owl-carousel")],
    modules: ["..\\components\\Layout\\components\\page_component\\BangaloreSlide2.jsx -> " + 'react-owl-carousel']
  }
});


const BangaloreSlide2 = ({
  article
}) => {
  const {
    bangaloreProjectSlide2,
    bangaloreSlide2Address,
    bangaloreSlide2BedInfo,
    bangaloreSlide2PriceInfo
  } = article.fields;
  const state = {
    responsive: {
      0: {
        items: 1
      },
      450: {
        items: 2
      },
      600: {
        items: 3
      },
      1000: {
        items: 3
      }
    }
  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(OwlCarousel, {
        items: 3,
        className: "owl-theme",
        loop: true,
        nav: true,
        margin: 20,
        responsive: state.responsive,
        children: bangaloreProjectSlide2.map((item, i) => {
          var _bangaloreProjectSlid, _bangaloreProjectSlid2, _bangaloreProjectSlid3, _bangaloreProjectSlid4, _bangaloreProjectSlid5, _bangaloreProjectSlid6, _bangaloreProjectSlid7, _bangaloreProjectSlid8, _bangaloreProjectSlid9;

          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "card border-0 work-container work-grid position-relative d-block",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "card-body p-0",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "/#",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                  src: (_bangaloreProjectSlid = bangaloreProjectSlide2[i]) === null || _bangaloreProjectSlid === void 0 ? void 0 : (_bangaloreProjectSlid2 = _bangaloreProjectSlid.fields) === null || _bangaloreProjectSlid2 === void 0 ? void 0 : (_bangaloreProjectSlid3 = _bangaloreProjectSlid2.file) === null || _bangaloreProjectSlid3 === void 0 ? void 0 : _bangaloreProjectSlid3.url,
                  className: "img-fluid",
                  alt: (_bangaloreProjectSlid4 = bangaloreProjectSlide2[i]) === null || _bangaloreProjectSlid4 === void 0 ? void 0 : (_bangaloreProjectSlid5 = _bangaloreProjectSlid4.fields) === null || _bangaloreProjectSlid5 === void 0 ? void 0 : _bangaloreProjectSlid5.title
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 44,
                  columnNumber: 29
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 43,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "content bg-white p-3",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
                  className: "mb-0",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/#",
                    target: "_new",
                    children: (_bangaloreProjectSlid6 = bangaloreProjectSlide2[i]) === null || _bangaloreProjectSlid6 === void 0 ? void 0 : (_bangaloreProjectSlid7 = _bangaloreProjectSlid6.fields) === null || _bangaloreProjectSlid7 === void 0 ? void 0 : _bangaloreProjectSlid7.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 52,
                    columnNumber: 31
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 51,
                  columnNumber: 29
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "text-muted tag mb-0",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/#",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                      className: "subtitle",
                      children: bangaloreSlide2Address[i]
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 58,
                      columnNumber: 33
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 57,
                    columnNumber: 31
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 56,
                  columnNumber: 29
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "post-meta d-flex justify-content-between mt-3",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
                    className: "list-unstyled mb-0",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                      className: "list-inline-item mr-3",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                        className: "mdi mdi-bed-empty mdi-24px mr-2",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_AirlineSeatFlat__WEBPACK_IMPORTED_MODULE_1___default.a, {}, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 67,
                          columnNumber: 37
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 66,
                        columnNumber: 35
                      }, undefined), bangaloreSlide2BedInfo[i]]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 33
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 64,
                    columnNumber: 31
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    className: "btn btn-sm btn-info",
                    "data-toggle": "modal",
                    "data-target": "#mymodal",
                    href: "/#",
                    children: bangaloreSlide2PriceInfo[i]
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 72,
                    columnNumber: 31
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 63,
                  columnNumber: 29
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 50,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "read_more pstatus text-center rounded-circle",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "statusl_Ready",
                  children: (_bangaloreProjectSlid8 = bangaloreProjectSlide2[i]) === null || _bangaloreProjectSlid8 === void 0 ? void 0 : (_bangaloreProjectSlid9 = _bangaloreProjectSlid8.fields) === null || _bangaloreProjectSlid9 === void 0 ? void 0 : _bangaloreProjectSlid9.description
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 83,
                  columnNumber: 29
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 82,
                columnNumber: 27
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 42,
              columnNumber: 25
            }, undefined)
          }, i, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 23
          }, undefined);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 19
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 15
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 30,
    columnNumber: 9
  }, undefined);
};

/***/ }),

/***/ "./components/Layout/components/page_component/Banner.jsx":
/*!****************************************************************!*\
  !*** ./components/Layout/components/page_component/Banner.jsx ***!
  \****************************************************************/
/*! exports provided: Banner */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Banner", function() { return Banner; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_bootstrap_Carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-bootstrap/Carousel */ "react-bootstrap/Carousel");
/* harmony import */ var react_bootstrap_Carousel__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Carousel__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\page_component\\Banner.jsx";

const Banner = ({
  article
}) => {
  const {
    bannerImages
  } = article.fields;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "Banner_Section",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_bootstrap_Carousel__WEBPACK_IMPORTED_MODULE_1___default.a, {
      children: bannerImages.map((item, i) => {
        var _bannerImages$i, _bannerImages$i$field, _bannerImages$i$field2, _bannerImages$i2, _bannerImages$i2$fiel;

        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_bootstrap_Carousel__WEBPACK_IMPORTED_MODULE_1___default.a.Item, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            className: "d-block w-100",
            src: (_bannerImages$i = bannerImages[i]) === null || _bannerImages$i === void 0 ? void 0 : (_bannerImages$i$field = _bannerImages$i.fields) === null || _bannerImages$i$field === void 0 ? void 0 : (_bannerImages$i$field2 = _bannerImages$i$field.file) === null || _bannerImages$i$field2 === void 0 ? void 0 : _bannerImages$i$field2.url,
            alt: (_bannerImages$i2 = bannerImages[i]) === null || _bannerImages$i2 === void 0 ? void 0 : (_bannerImages$i2$fiel = _bannerImages$i2.fields) === null || _bannerImages$i2$fiel === void 0 ? void 0 : _bannerImages$i2$fiel.title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 10,
            columnNumber: 15
          }, undefined)
        }, i, false, {
          fileName: _jsxFileName,
          lineNumber: 9,
          columnNumber: 13
        }, undefined);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 9
  }, undefined);
};

/***/ }),

/***/ "./components/Layout/components/page_component/CountryCode.jsx":
/*!*********************************************************************!*\
  !*** ./components/Layout/components/page_component/CountryCode.jsx ***!
  \*********************************************************************/
/*! exports provided: CountryCode */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountryCode", function() { return CountryCode; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);


var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\page_component\\CountryCode.jsx";
const CountryCode = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "IN",
      value: "+91",
      defaultValue: true,
      children: "India (+91)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 5,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "AU",
      value: "+61",
      children: "Australia (+61)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "BH",
      value: "+973",
      children: "Bahrain (+973)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "CA",
      value: "+1",
      children: "Canada (+1)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "HK",
      value: "+852",
      children: "Hong Kong (+852)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "QA",
      value: "+974",
      children: "Qatar (+974)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "SA",
      value: "+966",
      children: "Saudi Arabia (+966)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "SG",
      value: "+65",
      children: "Singapore (+65)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "ZA",
      value: "+27",
      children: "South Africa (+27)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "AE",
      value: "+971",
      children: "United Arab Emirates (+971)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "US",
      value: "+1",
      children: "USA (+1)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
      "data-countrycode": "GB",
      name: "countrycode",
      value: "+44",
      children: "UK (+44)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("optgroup", {
      label: "Other countries",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AF",
        value: "+93",
        children: "Afghanistan (+93)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AL",
        value: "+355",
        children: "Albania (+355)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "DZ",
        value: "+213",
        children: "Algeria (+213)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AS",
        value: "+1-684",
        children: "American Samoa (+1-684)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AD",
        value: "+376",
        children: "Andorra (+376)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AO",
        value: "+244",
        children: "Angola (+244)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AI",
        value: "+1-264",
        children: "Anguilla (+1-264)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AQ",
        value: "+672",
        children: "Antarctica (+672)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AG",
        value: "+1-268",
        children: "Antigua and Barbuda (+1-268)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AR",
        value: "+54",
        children: "Argentina (+54)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AM",
        value: "+374",
        children: "Armenia (+374)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AW",
        value: "+297",
        children: "Aruba (+297)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AT",
        value: "+43",
        children: "Austria (+43)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AZ",
        value: "+994",
        children: "Azerbaijan (+994)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BS",
        value: "+1-242",
        children: "Bahamas (+1-242)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 84,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BD",
        value: "+880",
        children: "Bangladesh (+880)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BB",
        value: "+1-246",
        children: "Barbados (+1-246)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 90,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BY",
        value: "+375",
        children: "Belarus (+375)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BE",
        value: "+32",
        children: "Belgium (+32)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BZ",
        value: "+501",
        children: "Belize (+501)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 99,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BJ",
        value: "+229",
        children: "Benin (+229)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 102,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BM",
        value: "+1-441",
        children: "Bermuda (+1-441)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 105,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BT",
        value: "+975",
        children: "Bhutan (+975)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 108,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BO",
        value: "+591",
        children: "Bolivia (+591)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 111,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BA",
        value: "+387",
        children: "Bosnia and Herzegowina (+387)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 114,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BW",
        value: "+267",
        children: "Botswana (+267)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 117,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BV",
        value: "+47",
        children: "Bouvet Island (+47)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 120,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BR",
        value: "+55",
        children: "Brazil (+55)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 123,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "IO",
        value: "+246",
        children: "British Indian Ocean Territory (+246)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 126,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BN",
        value: "+673",
        children: "Brunei Darussalam (+673)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 129,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BG",
        value: "+359",
        children: "Bulgaria (+359)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BF",
        value: "+226",
        children: "Burkina Faso (+226)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 135,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "BI",
        value: "+257",
        children: "Burundi (+257)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 138,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KH",
        value: "+855",
        children: "Cambodia (+855)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 141,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CM",
        value: "+237",
        children: "Cameroon (+237)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 144,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CV",
        value: "+238",
        children: "Cape Verde (+238)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 147,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KY",
        value: "+1-345",
        children: "Cayman Islands (+1-345)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 150,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CF",
        value: "+236",
        children: "Central African Republic (+236)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 153,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TD",
        value: "+235",
        children: "Chad (+235)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 156,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CL",
        value: "+56",
        children: "Chile (+56)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 159,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CN",
        value: "+86",
        children: "China (+86)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 162,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CX",
        value: "+61",
        children: "Christmas Island (+61)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 165,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CC",
        value: "+61",
        children: "Cocos (Keeling) Islands (+61)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 168,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CO",
        value: "+57",
        children: "Colombia (+57)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 171,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KM",
        value: "+269",
        children: "Comoros (+269)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 174,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CG",
        value: "+242",
        children: "Congo Democratic Republic of (+242)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 177,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CK",
        value: "+682",
        children: "Cook Islands (+682)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 180,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CR",
        value: "+506",
        children: "Costa Rica (+506)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 183,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CI",
        value: "+225",
        children: "Cote D'Ivoire (+225)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 186,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "HR",
        value: "+385",
        children: "Croatia (+385)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 189,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CU",
        value: "+53",
        children: "Cuba (+53)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 192,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CY",
        value: "+357",
        children: "Cyprus (+357)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 195,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CZ",
        value: "+420",
        children: "Czech Republic (+420)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 198,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "DK",
        value: "+45",
        children: "Denmark (+45)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 201,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "DJ",
        value: "+253",
        children: "Djibouti (+253)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 204,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "DM",
        value: "+1-767",
        children: "Dominica (+1-767)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 207,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "DO",
        value: "+1-809",
        children: "Dominican Republic (+1-809)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 210,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TL",
        value: "+670",
        children: "Timor-Leste (+670)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 213,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "EC",
        value: "+593",
        children: "Ecuador (+593)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 216,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "EG",
        value: "+20",
        children: "Egypt (+20)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 219,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SV",
        value: "+503",
        children: "El Salvador (+503)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 222,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GQ",
        value: "+240",
        children: "Equatorial Guinea (+240)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 225,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "ER",
        value: "+291",
        children: "Eritrea (+291)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 228,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "EE",
        value: "+372",
        children: "Estonia (+372)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 231,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "ET",
        value: "+251",
        children: "Ethiopia (+251)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 234,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "FK",
        value: "+500",
        children: "Falkland Islands (Malvinas) (+500)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 237,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "FO",
        value: "+298",
        children: "Faroe Islands (+298)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 240,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "FJ",
        value: "+679",
        children: "Fiji (+679)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 243,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "FI",
        value: "+358",
        children: "Finland (+358)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 246,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "FR",
        value: "+33",
        children: "France (+33)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 249,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GF",
        value: "+594",
        children: "French Guiana (+594)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 252,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PF",
        value: "+689",
        children: "French Polynesia (+689)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 255,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TF",
        value: "+",
        children: "French Southern Territories (+)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 258,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GA",
        value: "+241",
        children: "Gabon (+241)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 261,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GM",
        value: "+220",
        children: "Gambia (+220)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 264,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GE",
        value: "+995",
        children: "Georgia (+995)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 267,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "DE",
        value: "+49",
        children: "Germany (+49)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 270,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GH",
        value: "+233",
        children: "Ghana (+233)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 273,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GI",
        value: "+350",
        children: "Gibraltar (+350)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 276,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GR",
        value: "+30",
        children: "Greece (+30)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 279,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GL",
        value: "+299",
        children: "Greenland (+299)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 282,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GD",
        value: "+1-473",
        children: "Grenada (+1-473)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 285,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GP",
        value: "+590",
        children: "Guadeloupe (+590)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 288,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GU",
        value: "+1-671",
        children: "Guam (+1-671)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 291,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GT",
        value: "+502",
        children: "Guatemala (+502)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 294,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GN",
        value: "+224",
        children: "Guinea (+224)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 297,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GW",
        value: "+245",
        children: "Guinea-bissau (+245)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 300,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GY",
        value: "+592",
        children: "Guyana (+592)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 303,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "HT",
        value: "+509",
        children: "Haiti (+509)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 306,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "HM",
        value: "+011",
        children: "Heard Island and McDonald Islands (+011)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 309,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "HN",
        value: "+504",
        children: "Honduras (+504)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 312,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "HU",
        value: "+36",
        children: "Hungary (+36)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 315,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "IS",
        value: "+354",
        children: "Iceland (+354)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 318,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "ID",
        value: "+62",
        children: "Indonesia (+62)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 321,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "IR",
        value: "+98",
        children: "Iran (Islamic Republic of) (+98)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 324,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "IQ",
        value: "+964",
        children: "Iraq (+964)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 327,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "IE",
        value: "+353",
        children: "Ireland (+353)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 330,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "IL",
        value: "+972",
        children: "Israel (+972)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 333,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "IT",
        value: "+39",
        children: "Italy (+39)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 336,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "JM",
        value: "+1-876",
        children: "Jamaica (+1-876)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 339,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "JP",
        value: "+81",
        children: "Japan (+81)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 342,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "JO",
        value: "+962",
        children: "Jordan (+962)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 345,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KZ",
        value: "+7",
        children: "Kazakhstan (+7)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 348,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KE",
        value: "+254",
        children: "Kenya (+254)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 351,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KI",
        value: "+686",
        children: "Kiribati (+686)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 354,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KP",
        value: "+850",
        children: "Korea, Democratic People's Republic of (+850)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 357,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KR",
        value: "+82",
        children: "South Korea (+82)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 360,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KW",
        value: "+965",
        children: "Kuwait (+965)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 363,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KG",
        value: "+996",
        children: "Kyrgyzstan (+996)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 366,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LA",
        value: "+856",
        children: "Lao People's Democratic Republic (+856)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 369,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LV",
        value: "+371",
        children: "Latvia (+371)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 372,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LB",
        value: "+961",
        children: "Lebanon (+961)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 375,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LS",
        value: "+266",
        children: "Lesotho (+266)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 378,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LR",
        value: "+231",
        children: "Liberia (+231)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 381,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LY",
        value: "+218",
        children: "Libya (+218)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 384,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LI",
        value: "+423",
        children: "Liechtenstein (+423)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 387,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LT",
        value: "+370",
        children: "Lithuania (+370)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 390,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LU",
        value: "+352",
        children: "Luxembourg (+352)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 393,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MO",
        value: "+853",
        children: "Macao (+853)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 396,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MK",
        value: "+389",
        children: "Macedonia, The Former Yugoslav Republic of (+389)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 399,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MG",
        value: "+261",
        children: "Madagascar (+261)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 402,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MW",
        value: "+265",
        children: "Malawi (+265)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 405,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MY",
        value: "+60",
        children: "Malaysia (+60)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 408,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MV",
        value: "+960",
        children: "Maldives (+960)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 411,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "ML",
        value: "+223",
        children: "Mali (+223)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 414,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MT",
        value: "+356",
        children: "Malta (+356)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 417,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MH",
        value: "+692",
        children: "Marshall Islands (+692)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 420,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MQ",
        value: "+596",
        children: "Martinique (+596)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 423,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MR",
        value: "+222",
        children: "Mauritania (+222)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 426,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MU",
        value: "+230",
        children: "Mauritius (+230)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 429,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "YT",
        value: "+262",
        children: "Mayotte (+262)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 432,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MX",
        value: "+52",
        children: "Mexico (+52)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 435,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "FM",
        value: "+691",
        children: "Micronesia, Federated States of (+691)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 438,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MD",
        value: "+373",
        children: "Moldova (+373)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 441,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MC",
        value: "+377",
        children: "Monaco (+377)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 444,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MN",
        value: "+976",
        children: "Mongolia (+976)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 447,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MS",
        value: "+1-664",
        children: "Montserrat (+1-664)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 450,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MA",
        value: "+212",
        children: "Morocco (+212)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 453,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MZ",
        value: "+258",
        children: "Mozambique (+258)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 456,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MM",
        value: "+95",
        children: "Myanmar (+95)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 459,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NA",
        value: "+264",
        children: "Namibia (+264)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 462,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NR",
        value: "+674",
        children: "Nauru (+674)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 465,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NP",
        value: "+977",
        children: "Nepal (+977)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 468,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NL",
        value: "+31",
        children: "Netherlands (+31)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 471,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AN",
        value: "+599",
        children: "Netherlands Antilles (+599)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 474,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NC",
        value: "+687  ",
        children: "New Caledonia (+687 )"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 477,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NZ",
        value: "+64",
        children: "New Zealand (+64)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 480,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NI",
        value: "+505",
        children: "Nicaragua (+505)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 483,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NE",
        value: "+227",
        children: "Niger (+227)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 486,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NG",
        value: "+234",
        children: "Nigeria (+234)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 489,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NU",
        value: "+683",
        children: "Niue (+683)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 492,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NF",
        value: "+672",
        children: "Norfolk Island (+672)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 495,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "MP",
        value: "+1-670",
        children: "Northern Mariana Islands (+1-670)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 498,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "NO",
        value: "+47",
        children: "Norway (+47)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 501,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "OM",
        value: "+968",
        children: "Oman (+968)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 504,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PK",
        value: "+92",
        children: "Pakistan (+92)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 507,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PW",
        value: "+680",
        children: "Palau (+680)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 510,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PA",
        value: "+507",
        children: "Panama (+507)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 513,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PG",
        value: "+675",
        children: "Papua New Guinea (+675)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 516,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PY",
        value: "+595",
        children: "Paraguay (+595)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 519,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PE",
        value: "+51",
        children: "Peru (+51)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 522,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PH",
        value: "+63",
        children: "Philippines (+63)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 525,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PN",
        value: "+64",
        children: "Pitcairn (+64)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 528,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PL",
        value: "+48",
        children: "Poland (+48)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 531,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PT",
        value: "+351",
        children: "Portugal (+351)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 534,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PR",
        value: "+1-787",
        children: "Puerto Rico (+1-787)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 537,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "RE",
        value: "+262",
        children: "Reunion (+262)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 540,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "RO",
        value: "+40",
        children: "Romania (+40)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 543,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "RU",
        value: "+7",
        children: "Russian Federation (+7)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 546,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "RW",
        value: "+250",
        children: "Rwanda (+250)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 549,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "KN",
        value: "+1-869",
        children: "Saint Kitts and Nevis (+1-869)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 552,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LC",
        value: "+1-758",
        children: "Saint Lucia (+1-758)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 555,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "VC",
        value: "+1-784",
        children: "Saint Vincent and the Grenadines (+1-784)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 558,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "WS",
        value: "+685",
        children: "Samoa (+685)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 561,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SM",
        value: "+378",
        children: "San Marino (+378)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 564,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "ST",
        value: "+239",
        children: "Sao Tome and Principe (+239)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 567,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SN",
        value: "+221",
        children: "Senegal (+221)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 570,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SC",
        value: "+248",
        children: "Seychelles (+248)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 573,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SL",
        value: "+232",
        children: "Sierra Leone (+232)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 576,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SK",
        value: "+421",
        children: "Slovakia (Slovak Republic) (+421)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 579,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SI",
        value: "+386",
        children: "Slovenia (+386)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 582,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SB",
        value: "+677",
        children: "Solomon Islands (+677)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 585,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SO",
        value: "+252",
        children: "Somalia (+252)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 588,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GS",
        value: "+500",
        children: "South Georgia and the South Sandwich Islands (+500)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 591,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "ES",
        value: "+34",
        children: "Spain (+34)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 594,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "LK",
        value: "+94",
        children: "Sri Lanka (+94)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 597,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SH",
        value: "+290",
        children: "Saint Helena, Ascension and Tristan da Cunha (+290)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 600,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PM",
        value: "+508",
        children: "St. Pierre and Miquelon (+508)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 603,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SD",
        value: "+249",
        children: "Sudan (+249)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 606,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SR",
        value: "+597",
        children: "Suriname (+597)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 609,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SJ",
        value: "+47",
        children: "Svalbard and Jan Mayen Islands (+47)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 612,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SZ",
        value: "+268",
        children: "Swaziland (+268)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 615,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SE",
        value: "+46",
        children: "Sweden (+46)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 618,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CH",
        value: "+41",
        children: "Switzerland (+41)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 621,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "SY",
        value: "+963",
        children: "Syrian Arab Republic (+963)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 624,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TW",
        value: "+886",
        children: "Taiwan (+886)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 627,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TJ",
        value: "+992",
        children: "Tajikistan (+992)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 630,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TZ",
        value: "+255",
        children: "Tanzania, United Republic of (+255)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 633,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TH",
        value: "+66",
        children: "Thailand (+66)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 636,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TG",
        value: "+228",
        children: "Togo (+228)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 639,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TK",
        value: "+690",
        children: "Tokelau (+690)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 642,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TO",
        value: "+676",
        children: "Tonga (+676)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 645,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TT",
        value: "+1-868",
        children: "Trinidad and Tobago (+1-868)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 648,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TN",
        value: "+216",
        children: "Tunisia (+216)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 651,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TR",
        value: "+90",
        children: "Turkey (+90)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 654,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TM",
        value: "+993",
        children: "Turkmenistan (+993)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 657,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TC",
        value: "+1-649",
        children: "Turks and Caicos Islands (+1-649)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 660,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "TV",
        value: "+688",
        children: "Tuvalu (+688)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 663,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "UG",
        value: "+256",
        children: "Uganda (+256)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 666,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "UA",
        value: "+380",
        children: "Ukraine (+380)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 669,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GB",
        value: "+44",
        children: "United Kingdom (+44)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 672,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "US",
        value: "+1",
        children: "United States (+1)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 675,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "UM",
        value: "+246",
        children: "United States Minor Outlying Islands (+246)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 678,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "UY",
        value: "+598",
        children: "Uruguay (+598)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 681,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "UZ",
        value: "+998",
        children: "Uzbekistan (+998)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 684,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "VU",
        value: "+678",
        children: "Vanuatu (+678)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 687,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "VA",
        value: "+379",
        children: "Vatican City State (Holy See) (+379)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 690,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "VE",
        value: "+58",
        children: "Venezuela (+58)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 693,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "VN",
        value: "+84",
        children: "Vietnam (+84)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 696,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "VG",
        value: "+1-284",
        children: "Virgin Islands (British) (+1-284)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 699,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "VI",
        value: "+1-340",
        children: "Virgin Islands (U.S.) (+1-340)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 702,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "WF",
        value: "+681",
        children: "Wallis and Futuna Islands (+681)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 705,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "EH",
        value: "+212",
        children: "Western Sahara (+212)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 708,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "YE",
        value: "+967",
        children: "Yemen (+967)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 711,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "RS",
        value: "+381",
        children: "Serbia (+381)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 714,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "ZM",
        value: "+260",
        children: "Zambia (+260)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 717,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "ZW",
        value: "+263",
        children: "Zimbabwe (+263)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 720,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "AX",
        value: "+358",
        children: "Aaland Islands (+358)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 723,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "PS",
        value: "+970",
        children: "Palestine (+970)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 726,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "ME",
        value: "+382",
        children: "Montenegro (+382)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 729,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "GG",
        value: "+44-1481",
        children: "Guernsey (+44-1481)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 732,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "IM",
        value: "+44-1624",
        children: "Isle of Man (+44-1624)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 735,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "JE",
        value: "+44-1534",
        children: "Jersey (+44-1534)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 738,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CW",
        value: "+599",
        children: "Cura\xC3\xA7ao (+599)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 741,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "CI",
        value: "+225",
        children: "Ivory Coast (+225)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 744,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        "data-countrycode": "XK",
        value: "+383",
        children: "Kosovo (+383)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 747,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 7
    }, undefined)]
  }, void 0, true);
};

/***/ }),

/***/ "./components/Layout/components/page_component/Form.jsx":
/*!**************************************************************!*\
  !*** ./components/Layout/components/page_component/Form.jsx ***!
  \**************************************************************/
/*! exports provided: Form */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Form", function() { return Form; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config_CustomApi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../config/CustomApi */ "./components/config/CustomApi.js");
/* harmony import */ var _config_serverKey__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../config/serverKey */ "./components/config/serverKey.js");
/* harmony import */ var _CountryCode__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./CountryCode */ "./components/Layout/components/page_component/CountryCode.jsx");

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\page_component\\Form.jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const Form = () => {
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"])();
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    Object(_config_CustomApi__WEBPACK_IMPORTED_MODULE_3__["getApi"])().then(data => {
      window.projectname = data.project_name;
      window.city = data.city;
    });
  }, []);
  let initialData = {
    name: "",
    email: "",
    number: "",
    countrycode: "+91",
    message: ""
  };
  const {
    0: dataForm,
    1: setDataForm
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(initialData);

  const handleSubmit = async e => {
    e.preventDefault();
    let obj = {};
    obj.p_username = dataForm.name;
    obj.p_mobilenumber = dataForm.number;
    obj.p_email = dataForm.email;
    obj.p_countrycode = dataForm.countrycode;
    obj.p_msg = dataForm.message;
    obj.p_leadtype = window.projectname;
    obj.p_launchname = "";
    obj.p_source = "website";
    obj.p_city = window.city;
    Object(_config_CustomApi__WEBPACK_IMPORTED_MODULE_3__["postApi"])(obj);
    router.push("/thankyou");
  };

  const handleChange = e => {
    const {
      name,
      value
    } = e.target;
    setDataForm(_objectSpread(_objectSpread({}, dataForm), {}, {
      [name]: value
    })); // console.log(`name: ${e.target.name},value: ${e.target.value}`);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "container",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "modal fade",
      id: "mymodal",
      tabIndex: "-1",
      role: "dialog",
      "aria-labelledby": "exampleModalLabel",
      "aria-hidden": "true",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "modal-dialog",
        role: "document",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "modal-content",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "modal-header",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
              className: "modal-title",
              children: "Register Here"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 58,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              type: "button",
              className: "close",
              "data-dismiss": "modal",
              "aria-label": "Close",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                "aria-hidden": "true",
                children: "\xD7"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 65,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 59,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "modal-body",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              id: "eformcdiv",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
                id: "dropAnEnquiry",
                name: "ecform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "form-group position-relative",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                    children: ["Name ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "text-danger",
                      children: "*"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 73,
                      columnNumber: 28
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 72,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
                    xmlns: _config_serverKey__WEBPACK_IMPORTED_MODULE_4__["FORM_ICON"],
                    width: "24",
                    height: "24",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: "feather feather-user fea icon-sm icons",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
                      d: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 87,
                      columnNumber: 23
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("circle", {
                      cx: "12",
                      cy: "7",
                      r: "4"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 88,
                      columnNumber: 23
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 75,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                    type: "text",
                    name: "name",
                    className: "form-control pl-5",
                    pattern: "[a-zA-Z ]+",
                    minLength: "3",
                    placeholder: "Your name",
                    required: "",
                    onChange: e => handleChange(e),
                    value: dataForm.name
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 90,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 71,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "form-group position-relative"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 102,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "form-group position-relative",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                    children: "Email ID "
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 104,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
                    xmlns: _config_serverKey__WEBPACK_IMPORTED_MODULE_4__["FORM_ICON"],
                    width: "24",
                    height: "24",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    className: "feather feather-mail fea icon-sm icons",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
                      d: "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 117,
                      columnNumber: 23
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("polyline", {
                      points: "22,6 12,13 2,6"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 118,
                      columnNumber: 23
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 105,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                    name: "email",
                    type: "email",
                    className: "form-control pl-5",
                    placeholder: "Your email",
                    required: "",
                    onChange: e => handleChange(e),
                    value: dataForm.email
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 120,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 103,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "form-group position-relative",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                    children: ["Your Number ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "text-danger",
                      children: "*"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 132,
                      columnNumber: 35
                    }, undefined), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 131,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "row no-gutters",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "col-md-4",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("select", {
                        name: "countrycode",
                        className: "form-control countrycode",
                        required: "",
                        id: "dropAnEnquiry_countrycode",
                        onChange: e => handleChange(e),
                        value: dataForm.countrycode,
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_CountryCode__WEBPACK_IMPORTED_MODULE_5__["CountryCode"], {}, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 144,
                          columnNumber: 25
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 136,
                        columnNumber: 25
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 135,
                      columnNumber: 23
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "col-md-8",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
                        xmlns: _config_serverKey__WEBPACK_IMPORTED_MODULE_4__["FORM_ICON"],
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        stroke: "currentColor",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        className: "feather feather-activity phone_style",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
                          d: "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 160,
                          columnNumber: 27
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 148,
                        columnNumber: 25
                      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                        name: "number",
                        id: "dropAnEnquiry_number",
                        type: "tel",
                        className: "form-control pl-5",
                        placeholder: "Your Number",
                        required: "",
                        onChange: e => handleChange(e),
                        value: dataForm.number
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 162,
                        columnNumber: 25
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 147,
                      columnNumber: 23
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 134,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 130,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "form-group form-radio flexd",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                    className: "left",
                    children: "Request a Site Visit"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 176,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "radio",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                        type: "radio",
                        name: "message",
                        required: "",
                        onChange: e => handleChange(e),
                        value: dataForm.message
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 179,
                        columnNumber: 25
                      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                        className: "helper"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 186,
                        columnNumber: 25
                      }, undefined), "Yes"]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 178,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 177,
                    columnNumber: 21
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "radio",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                        type: "radio",
                        name: "message",
                        onChange: e => handleChange(e),
                        value: dataForm.message
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 191,
                        columnNumber: 25
                      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                        className: "helper"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 197,
                        columnNumber: 25
                      }, undefined), "No"]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 190,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 189,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 175,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "button-container",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
                    className: "button btn btn-info rounded",
                    onClick: e => handleSubmit(e),
                    "data-dismiss": "modal",
                    children: "submit"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 202,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 201,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 70,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 69,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 68,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 46,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./components/Layout/components/page_component/HomePage.jsx":
/*!******************************************************************!*\
  !*** ./components/Layout/components/page_component/HomePage.jsx ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HomePage; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _BangaloreProject__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BangaloreProject */ "./components/Layout/components/page_component/BangaloreProject.jsx");
/* harmony import */ var _BangaloreSlide2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./BangaloreSlide2 */ "./components/Layout/components/page_component/BangaloreSlide2.jsx");
/* harmony import */ var _Banner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Banner */ "./components/Layout/components/page_component/Banner.jsx");
/* harmony import */ var _WhyPrestige__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./WhyPrestige */ "./components/Layout/components/page_component/WhyPrestige.jsx");
/* harmony import */ var _PrestigePrimrose__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./PrestigePrimrose */ "./components/Layout/components/page_component/PrestigePrimrose.jsx");
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Header */ "./components/Layout/components/Header.jsx");
/* harmony import */ var _ModalForm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ModalForm */ "./components/Layout/components/page_component/ModalForm.jsx");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core/IconButton */ "@material-ui/core/IconButton");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/icons */ "@material-ui/icons");
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Form */ "./components/Layout/components/page_component/Form.jsx");
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../Footer */ "./components/Layout/components/Footer.jsx");

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\page_component\\HomePage.jsx";













function HomePage({
  article
}) {
  const {
    prestigeBangalorePara
  } = article.fields;
  const {
    0: openForm,
    1: setOpenForm
  } = Object(react__WEBPACK_IMPORTED_MODULE_9__["useState"])(false);

  const handleDrawerForm = () => {
    setOpenForm(true);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Header__WEBPACK_IMPORTED_MODULE_6__["Header"], {
      article: article
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 9
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Banner__WEBPACK_IMPORTED_MODULE_3__["Banner"], {
      article: article
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 10
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      id: "why_prestige",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "container-section",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row justify-content-center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-12",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "section-title  mt-4",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
                className: "title about_circle",
                children: "Why Choose Prestige Group"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 35,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 31,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_WhyPrestige__WEBPACK_IMPORTED_MODULE_4__["WhyPrestige"], {
              article: article
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 37,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 30,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 9
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      className: "section mb-5",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "container-section",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row justify-content-center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-12",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "section-title",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
                className: "title mb-4",
                children: "Projects in Bangalore"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 47,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "row justify-content-center",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "col-12",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                  className: "ml-4 mb-4",
                  children: prestigeBangalorePara.content[0].content[0].value
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 51,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 50,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 49,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: " no-padding",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_BangaloreProject__WEBPACK_IMPORTED_MODULE_1__["BangaloreProject"], {
                article: article
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 57,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 56,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "col-lg-12 no-padding mt-3",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_BangaloreSlide2__WEBPACK_IMPORTED_MODULE_2__["BangaloreSlide2"], {
                article: article
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 61,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 60,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      className: "section mb-5",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "container-section",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row justify-content-center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-12",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "section-title",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
                className: "title mb-4",
                children: "Prestige Primrose Hills"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 72,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 71,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_PrestigePrimrose__WEBPACK_IMPORTED_MODULE_5__["PrestigePrimrose"], {
              article: article
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 67,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_8__["Drawer"], {
      anchor: "right",
      open: openForm,
      onClose: () => {
        setOpenForm(false);
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          height: "100vh",
          padding: "20px",
          width: "580px"
        },
        className: "register_panel",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_10___default.a, {
          onClick: () => {
            setOpenForm(false);
          },
          color: "primary",
          style: {
            position: "absolute",
            right: "20px",
            top: "10px",
            zIndex: "3",
            color: "#000"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons__WEBPACK_IMPORTED_MODULE_11__["CloseOutlined"], {
            color: "primary"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 104,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 91,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ModalForm__WEBPACK_IMPORTED_MODULE_7__["ModalForm"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 106,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 80,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
      type: "button",
      className: "enquireNowScroll",
      "data-panel": "main",
      onClick: handleDrawerForm,
      children: "Register Here"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 109,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Form__WEBPACK_IMPORTED_MODULE_12__["Form"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 117,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Footer__WEBPACK_IMPORTED_MODULE_13__["Footer"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 118,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 24,
    columnNumber: 9
  }, this);
}

/***/ }),

/***/ "./components/Layout/components/page_component/ModalForm.jsx":
/*!*******************************************************************!*\
  !*** ./components/Layout/components/page_component/ModalForm.jsx ***!
  \*******************************************************************/
/*! exports provided: ModalForm */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalForm", function() { return ModalForm; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _CountryCode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CountryCode */ "./components/Layout/components/page_component/CountryCode.jsx");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _config_CustomApi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../config/CustomApi */ "./components/config/CustomApi.js");
/* harmony import */ var _config_serverKey__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config/serverKey */ "./components/config/serverKey.js");

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\page_component\\ModalForm.jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const ModalForm = () => {
  let initialData = {
    name: "",
    email: "",
    phone: "",
    location: "",
    countrycode: "+91"
  };
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    Object(_config_CustomApi__WEBPACK_IMPORTED_MODULE_4__["getApi"])().then(data => {
      window.projectname = data.project_name;
      window.city = data.city;
    });
  }, []);
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"])();
  const {
    0: data,
    1: setData
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(initialData);

  const handleSubmit = async e => {
    e.preventDefault();
    let obj = {};
    obj.p_username = data.name;
    obj.p_mobilenumber = data.phone;
    obj.p_email = data.email;
    obj.p_countrycode = data.countrycode;
    obj.p_leadtype = window.projectname;
    obj.p_launchname = "";
    obj.p_source = "website";
    obj.p_city = window.city;
    Object(_config_CustomApi__WEBPACK_IMPORTED_MODULE_4__["postApi"])(obj);
    router.push("/thankyou");
  };

  const handleChange = e => {
    const {
      name,
      value
    } = e.target;
    setData(_objectSpread(_objectSpread({}, data), {}, {
      [name]: value
    })); // console.log(`name: ${e.target.name},value: ${e.target.value}`)
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("header", {
      className: "cd-panel__header",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          style: {
            color: "#996600"
          },
          children: "EXPRESS"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 11
        }, undefined), " Your Interest Here"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "cd-panel__container",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "cd-panel__content",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
          id: "sform",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "form-group",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
              children: ["Preferred Location ? ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "text-danger",
                children: "*"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 54,
                columnNumber: 38
              }, undefined), " ", "(Click to select)"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 53,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "radio-tile-group form-group",
              children: _config_serverKey__WEBPACK_IMPORTED_MODULE_5__["MY_LOCATION"].map((item, i) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "input-container",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                  value: item,
                  className: "radio-button",
                  type: "radio",
                  name: "location"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 60,
                  columnNumber: 21
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "radio-tile",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "icon",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                      src: _config_serverKey__WEBPACK_IMPORTED_MODULE_5__["LOCATION_IMG"] + item + "-icon.png",
                      alt: "city-icon"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 68,
                      columnNumber: 25
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 67,
                    columnNumber: 23
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                    htmlFor: "walk",
                    className: "radio-tile-label text-capitalize",
                    children: item
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 73,
                    columnNumber: 23
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 66,
                  columnNumber: 21
                }, undefined)]
              }, i, true, {
                fileName: _jsxFileName,
                lineNumber: 59,
                columnNumber: 19
              }, undefined))
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 57,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "form-group",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
              children: "Your Name"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 85,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
              type: "text",
              className: "form-control",
              placeholder: "Name",
              required: "",
              id: "sname",
              pattern: "[a-zA-Z ]{4,35}",
              name: "name",
              onChange: e => handleChange(e),
              value: data.name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 86,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 84,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "form-group",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
              children: "Your Email"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 99,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
              type: "email",
              className: "form-control",
              name: "email",
              placeholder: "Email",
              pattern: "^([a-zA-Z0-9_.]{2,}@[a-zA-Z0-9]{2,}.[a-zA-Z]{2,}(.[a-zA-Z]{2,3})?)$",
              id: "semail",
              onChange: e => handleChange(e),
              value: data.email
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 100,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 98,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "Your Number"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 111,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "row no-gutters",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "col-md-4",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "form-group",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("select", {
                  name: "countrycode",
                  className: "form-control countrycode",
                  required: "",
                  id: "scountrycode",
                  onChange: e => handleChange(e),
                  value: data.countrycode,
                  children: ["=", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_CountryCode__WEBPACK_IMPORTED_MODULE_2__["CountryCode"], {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 123,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 115,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 114,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 113,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "col-md-8",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "form-group",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                  type: "tel",
                  className: "form-control",
                  name: "phone",
                  placeholder: "Phone",
                  minLength: "10",
                  maxLength: "14",
                  required: "",
                  id: "snumber",
                  pattern: "[0-9]{10}$",
                  onChange: e => handleChange(e),
                  value: data.phone
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 129,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 128,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 127,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 112,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "button-container",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
              type: "button",
              name: "search",
              className: "button btn btn-info rounded",
              value: "SUBMIT",
              onClick: e => handleSubmit(e)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 146,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 145,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 43,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./components/Layout/components/page_component/PrestigePrimrose.jsx":
/*!**************************************************************************!*\
  !*** ./components/Layout/components/page_component/PrestigePrimrose.jsx ***!
  \**************************************************************************/
/*! exports provided: PrestigePrimrose */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrestigePrimrose", function() { return PrestigePrimrose; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dynamic */ "next/dynamic");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! owl.carousel/dist/assets/owl.carousel.css */ "./node_modules/owl.carousel/dist/assets/owl.carousel.css");
/* harmony import */ var owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! owl.carousel/dist/assets/owl.theme.default.css */ "./node_modules/owl.carousel/dist/assets/owl.theme.default.css");
/* harmony import */ var owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_3__);

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\page_component\\PrestigePrimrose.jsx";

const OwlCarousel = next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(() => Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(null, /*! react-owl-carousel */ "react-owl-carousel", 7)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! react-owl-carousel */ "react-owl-carousel")],
    modules: ["..\\components\\Layout\\components\\page_component\\PrestigePrimrose.jsx -> " + 'react-owl-carousel']
  }
});


const PrestigePrimrose = ({
  article
}) => {
  const state = {
    responsive: {
      0: {
        items: 1
      },
      450: {
        items: 2
      },
      600: {
        items: 3
      },
      1000: {
        items: 3
      }
    }
  };
  const {
    prestigePrimrose
  } = article.fields;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(OwlCarousel, {
        items: 3,
        className: "owl-theme",
        loop: true,
        nav: true,
        margin: 20,
        responsive: state.responsive,
        children: prestigePrimrose.map((item, i) => {
          var _prestigePrimrose$i, _prestigePrimrose$i$f, _prestigePrimrose$i$f2, _prestigePrimrose$i2, _prestigePrimrose$i2$, _prestigePrimrose$i3, _prestigePrimrose$i3$;

          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "card border-0 work-container work-grid position-relative d-block",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "card-body p-0",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "/#",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                  src: (_prestigePrimrose$i = prestigePrimrose[i]) === null || _prestigePrimrose$i === void 0 ? void 0 : (_prestigePrimrose$i$f = _prestigePrimrose$i.fields) === null || _prestigePrimrose$i$f === void 0 ? void 0 : (_prestigePrimrose$i$f2 = _prestigePrimrose$i$f.file) === null || _prestigePrimrose$i$f2 === void 0 ? void 0 : _prestigePrimrose$i$f2.url,
                  className: "img-fluid",
                  alt: (_prestigePrimrose$i2 = prestigePrimrose[i]) === null || _prestigePrimrose$i2 === void 0 ? void 0 : (_prestigePrimrose$i2$ = _prestigePrimrose$i2.fields) === null || _prestigePrimrose$i2$ === void 0 ? void 0 : _prestigePrimrose$i2$.title
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 42,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 41,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "content bg-white p-3",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
                  className: "mb-0 text-center",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/#",
                    children: "Get New Launch Project Details "
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 50,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 49,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "post-meta d-flex justify-content-between mt-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/#",
                    className: "btn btn-sm btn-info btn1",
                    "data-toggle": "modal",
                    "data-target": "#mymodal",
                    children: "Click To Know More"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 53,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 52,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 48,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "read_more pstatus text-center rounded-circle",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "statusl_New",
                  children: (_prestigePrimrose$i3 = prestigePrimrose[i]) === null || _prestigePrimrose$i3 === void 0 ? void 0 : (_prestigePrimrose$i3$ = _prestigePrimrose$i3.fields) === null || _prestigePrimrose$i3$ === void 0 ? void 0 : _prestigePrimrose$i3$.title
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 64,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 63,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 40,
              columnNumber: 15
            }, undefined)
          }, i, false, {
            fileName: _jsxFileName,
            lineNumber: 36,
            columnNumber: 13
          }, undefined);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 25,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./components/Layout/components/page_component/WhyPrestige.jsx":
/*!*********************************************************************!*\
  !*** ./components/Layout/components/page_component/WhyPrestige.jsx ***!
  \*********************************************************************/
/*! exports provided: WhyPrestige */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhyPrestige", function() { return WhyPrestige; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dynamic */ "next/dynamic");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! owl.carousel/dist/assets/owl.carousel.css */ "./node_modules/owl.carousel/dist/assets/owl.carousel.css");
/* harmony import */ var owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! owl.carousel/dist/assets/owl.theme.default.css */ "./node_modules/owl.carousel/dist/assets/owl.theme.default.css");
/* harmony import */ var owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\components\\Layout\\components\\page_component\\WhyPrestige.jsx";


const OwlCarousel = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(() => Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(null, /*! react-owl-carousel */ "react-owl-carousel", 7)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(/*! react-owl-carousel */ "react-owl-carousel")],
    modules: ["..\\components\\Layout\\components\\page_component\\WhyPrestige.jsx -> " + 'react-owl-carousel']
  }
});


const WhyPrestige = ({
  article
}) => {
  const state = {
    responsive: {
      0: {
        items: 1
      },
      450: {
        items: 2
      },
      600: {
        items: 3
      },
      1000: {
        items: 3
      }
    }
  };
  const {
    whyPrestige
  } = article.fields;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(OwlCarousel, {
        items: 3,
        className: "owl-theme",
        loop: true,
        nav: true,
        margin: 20,
        responsive: state.responsive,
        children: whyPrestige.map((item, i) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ProjectPart card border-0 work-container work-grid position-relative d-block",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "card-body p-0",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              className: "img-fluid",
              src: whyPrestige[i].fields.file.url,
              alt: whyPrestige[i].fields.title
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 39,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "content1 bg-white p-3",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
                className: "mb-4 title",
                children: whyPrestige[i].fields.title
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 45,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 44,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 38,
            columnNumber: 15
          }, undefined)
        }, i, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 13
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./components/config/CustomApi.js":
/*!****************************************!*\
  !*** ./components/config/CustomApi.js ***!
  \****************************************/
/*! exports provided: getApi, postApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getApi", function() { return getApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "postApi", function() { return postApi; });
/* harmony import */ var _serverKey__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./serverKey */ "./components/config/serverKey.js");


const getApi = async () => {
  const res = await fetch(_serverKey__WEBPACK_IMPORTED_MODULE_0__["API_URL"] + _serverKey__WEBPACK_IMPORTED_MODULE_0__["GET_DATA_API"]);
  const json = await res.json();
  return json.result;
};

const postApi = async body => {
  await fetch(_serverKey__WEBPACK_IMPORTED_MODULE_0__["API_URL"] + "leads", {
    method: "post",
    headers: {
      "content-type": "application/json"
    },
    body: JSON.stringify(body)
  }).then(result => {
    result.json().then(resp => {});
  });
};



/***/ }),

/***/ "./components/config/serverKey.js":
/*!****************************************!*\
  !*** ./components/config/serverKey.js ***!
  \****************************************/
/*! exports provided: STATIC_PHONE, API_URL, LOCATION_IMG, FORM_ICON, MY_LOCATION, PROJECT_LOGO, GET_DATA_API, HOMESFY_LOGO, HOMESFY_URL, HOMESFY_FACEBOOK, HOMESFY_INSTAGRAM */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STATIC_PHONE", function() { return STATIC_PHONE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "API_URL", function() { return API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LOCATION_IMG", function() { return LOCATION_IMG; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FORM_ICON", function() { return FORM_ICON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MY_LOCATION", function() { return MY_LOCATION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PROJECT_LOGO", function() { return PROJECT_LOGO; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GET_DATA_API", function() { return GET_DATA_API; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HOMESFY_LOGO", function() { return HOMESFY_LOGO; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HOMESFY_URL", function() { return HOMESFY_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HOMESFY_FACEBOOK", function() { return HOMESFY_FACEBOOK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HOMESFY_INSTAGRAM", function() { return HOMESFY_INSTAGRAM; });
const STATIC_PHONE = '07411782406';
const API_URL = "https://www.myhomesfy.com/api/";
const LOCATION_IMG = "https://www.prestigeconstructions.com/images/city/";
const FORM_ICON = "http://www.w3.org/2000/svg";
const MY_LOCATION = ["bangalore", "chennai", "hyderabad", "kochi", "mangalore"];
const PROJECT_LOGO = "https://www.prestigeconstructions.com/images/logo.png";
const GET_DATA_API = "leads/projectdata/1260";
const HOMESFY_LOGO = "https://refrance.s3.ap-south-1.amazonaws.com/HomesfyLogo.png";
const HOMESFY_URL = "https://www.homesfy.in/";
const HOMESFY_FACEBOOK = "https://www.facebook.com/homesfy";
const HOMESFY_INSTAGRAM = "https://instagram.com/homesfyindia?igshid=1hua89m9py0ue";


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/extends.js":
/*!********************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/extends.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

module.exports = _objectWithoutPropertiesLoose;

/***/ }),

/***/ "./node_modules/next/dist/client/image.js":
/*!************************************************!*\
  !*** ./node_modules/next/dist/client/image.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = Image;

var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/objectWithoutPropertiesLoose */ "./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js"));

var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js"));

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _head = _interopRequireDefault(__webpack_require__(/*! ../next-server/lib/head */ "../next-server/lib/head"));

var _toBase = __webpack_require__(/*! ../next-server/lib/to-base-64 */ "../next-server/lib/to-base-64");

var _imageConfig = __webpack_require__(/*! ../next-server/server/image-config */ "../next-server/server/image-config");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

if (true) {
  ;
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['default', defaultLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];
const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains,
  enableBlurryPlaceholder: configEnableBlurryPlaceholder
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","domains":[],"enableBlurryPlaceholder":false} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout, sizes) {
  if (sizes && (layout === 'fill' || layout === 'responsive')) {
    // Find all the "vw" percent sizes used in the sizes prop
    const viewportWidthRe = /(^|\s)(1?\d?\d)vw/g;
    const percentSizes = [];

    for (let match; match = viewportWidthRe.exec(sizes); match) {
      percentSizes.push(parseInt(match[2]));
    }

    if (percentSizes.length) {
      const smallestRatio = Math.min(...percentSizes) * 0.01;
      return {
        widths: allSizes.filter(s => s >= configDeviceSizes[0] * smallestRatio),
        kind: 'w'
      };
    }

    return {
      widths: allSizes,
      kind: 'w'
    };
  }

  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout, sizes);
  const last = widths.length - 1;
  return {
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', '),
    // It's intended to keep `src` the last attribute because React updates
    // attributes in order. If we keep `src` the first one, Safari will
    // immediately start to fetch `src`, before `sizes` and `srcSet` are even
    // updated by React. That causes multiple unnecessary requests if `srcSet`
    // and `sizes` are defined.
    // This bug cannot be reproduced in Chrome or Firefox.
    src: loader({
      src,
      quality,
      width: widths[last]
    })
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load((0, _extends2.default)({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
} // See https://stackoverflow.com/q/39777833/266535 for why we use this ref
// handler instead of the img's onLoad attribute.


function removePlaceholder(element, placeholder) {
  if (placeholder === 'blur' && element) {
    if (element.complete) {
      // If the real image fails to load, this will still remove the placeholder.
      // This is the desired behavior for now, and will be revisited when error
      // handling is worked on for the image component itself.
      element.style.backgroundImage = 'none';
    } else {
      element.onload = () => {
        element.style.backgroundImage = 'none';
      };
    }
  }
}

function Image(_ref) {
  let {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    loader = defaultImageLoader,
    placeholder = 'empty',
    blurDataURL
  } = _ref,
      all = (0, _objectWithoutPropertiesLoose2.default)(_ref, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "objectFit", "objectPosition", "loader", "placeholder", "blurDataURL"]);
  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';
  let unsized = false;

  if ('unsized' in rest) {
    unsized = Boolean(rest.unsized); // Remove property so it's not spread into image:

    delete rest['unsized'];
  } else if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  if (!configEnableBlurryPlaceholder) {
    placeholder = 'empty';
  }

  if (true) {
    if (!src) {
      throw new Error(`Image is missing required "src" property. Make sure you pass "src" in props to the \`next/image\` component. Received: ${JSON.stringify({
        width,
        height,
        quality
      })}`);
    }

    if (!VALID_LAYOUT_VALUES.includes(layout)) {
      throw new Error(`Image with src "${src}" has invalid "layout" property. Provided "${layout}" should be one of ${VALID_LAYOUT_VALUES.map(String).join(',')}.`);
    }

    if (!VALID_LOADING_VALUES.includes(loading)) {
      throw new Error(`Image with src "${src}" has invalid "loading" property. Provided "${loading}" should be one of ${VALID_LOADING_VALUES.map(String).join(',')}.`);
    }

    if (priority && loading === 'lazy') {
      throw new Error(`Image with src "${src}" has both "priority" and "loading='lazy'" properties. Only one should be used.`);
    }

    if (unsized) {
      throw new Error(`Image with src "${src}" has deprecated "unsized" property, which was removed in favor of the "layout='fill'" property`);
    }
  }

  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src && src.startsWith('data:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  const [setRef, isIntersected] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px',
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);
  const MIN_IMG_SIZE_FOR_PLACEHOLDER = 5000;
  const tooSmallForBlurryPlaceholder = widthInt && heightInt && widthInt * heightInt < MIN_IMG_SIZE_FOR_PLACEHOLDER;
  const shouldShowBlurryPlaceholder = placeholder === 'blur' && !tooSmallForBlurryPlaceholder;
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = (0, _extends2.default)({
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  }, shouldShowBlurryPlaceholder ? {
    backgroundSize: 'cover',
    backgroundImage: `url("${blurDataURL}")`
  } : undefined);

  if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined' && layout !== 'fill') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else if (typeof widthInt === 'undefined' && typeof heightInt === 'undefined' && layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else {
    // <Image src="i.png" />
    if (true) {
      throw new Error(`Image with src "${src}" must use "width" and "height" properties or "layout='fill'" property.`);
    }
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  if (unsized) {
    wrapperStyle = undefined;
    sizerStyle = undefined;
    imgStyle = undefined;
  }

  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    role: "presentation",
    src: `data:image/svg+xml;base64,${(0, _toBase.toBase64)(sizerSvg)}`
  }) : null) : null, !isVisible && /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, generateImgAttrs({
    src,
    unoptimized,
    layout,
    width: widthInt,
    quality: qualityInt,
    sizes,
    loader
  }), {
    src: src,
    decoding: "async",
    sizes: sizes,
    style: imgStyle,
    className: className
  }))), /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    className: className,
    ref: element => {
      setRef(element);
      removePlaceholder(element, placeholder);
    },
    style: imgStyle
  })), priority ?
  /*#__PURE__*/
  // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src // @ts-ignore: imagesrcset is not yet in the link element type
    ,
    imagesrcset: imgAttributes.srcSet // @ts-ignore: imagesizes is not yet in the link element type
    ,
    imagesizes: imgAttributes.sizes
  })) : null);
} //BUILT IN LOADERS


function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?format=auto&fit=max&w=300
  const params = ['auto=format', 'fit=max', 'w=' + width];
  let paramsString = '';

  if (quality) {
    params.push('q=' + quality);
  }

  if (params.length) {
    paramsString = '?' + params.join('&');
  }

  return `${root}${normalizeSrc(src)}${paramsString}`;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (true) {
    const missingValues = []; // these should always be provided but make sure they are

    if (!src) missingValues.push('src');
    if (!width) missingValues.push('width');

    if (missingValues.length > 0) {
      throw new Error(`Next Image Optimization requires ${missingValues.join(', ')} to be provided. Make sure you pass them as props to the \`next/image\` component. Received: ${JSON.stringify({
        src,
        width,
        quality
      })}`);
    }

    if (src.startsWith('//')) {
      throw new Error(`Failed to parse src "${src}" on \`next/image\`, protocol-relative URL (//) must be changed to an absolute URL (http:// or https://)`);
    }

    if (!src.startsWith('/') && configDomains) {
      let parsedSrc;

      try {
        parsedSrc = new URL(src);
      } catch (err) {
        console.error(err);
        throw new Error(`Failed to parse src "${src}" on \`next/image\`, if using relative image it must start with a leading slash "/" or be an absolute URL (http:// or https://)`);
      }

      if (!configDomains.includes(parsedSrc.hostname)) {
        throw new Error(`Invalid src prop (${src}) on \`next/image\`, hostname "${parsedSrc.hostname}" is not configured under images in your \`next.config.js\`\n` + `See more info: https://nextjs.org/docs/messages/next-image-unconfigured-host`);
      }
    }
  }

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/use-intersection.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/client/use-intersection.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/image.js":
/*!************************************!*\
  !*** ./node_modules/next/image.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/image */ "./node_modules/next/dist/client/image.js")


/***/ }),

/***/ "./node_modules/owl.carousel/dist/assets/owl.carousel.css":
/*!****************************************************************!*\
  !*** ./node_modules/owl.carousel/dist/assets/owl.carousel.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./node_modules/owl.carousel/dist/assets/owl.theme.default.css":
/*!*********************************************************************!*\
  !*** ./node_modules/owl.carousel/dist/assets/owl.theme.default.css ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: getStaticProps, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStaticProps", function() { return getStaticProps; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var contentful__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! contentful */ "contentful");
/* harmony import */ var contentful__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(contentful__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Layout_components_page_component_HomePage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Layout/components/page_component/HomePage */ "./components/Layout/components/page_component/HomePage.jsx");

var _jsxFileName = "C:\\Users\\User\\Desktop\\NextJs\\prestige_nextapp1\\pages\\index.js";





async function getStaticProps() {
  const client = Object(contentful__WEBPACK_IMPORTED_MODULE_4__["createClient"])({
    space: process.env.CONTENTFUL_SPACE_ID,
    accessToken: process.env.CONTENTFUL_ACCESS_KEY
  });
  const res = await client.getEntries({
    content_type: 'lodhaGoup'
  });
  console.log(res);
  return {
    props: {
      articles: res.items
    }
  };
}
function Home({
  articles
}) {
  console.warn(articles);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: articles.map((article, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_Layout_components_page_component_HomePage__WEBPACK_IMPORTED_MODULE_5__["default"], {
      article: article
    }, index, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, this))
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./styles/Home.module.css":
/*!********************************!*\
  !*** ./styles/Home.module.css ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Exports
module.exports = {
	"container": "Home_container__1EcsU",
	"main": "Home_main__1x8gC",
	"footer": "Home_footer__1WdhD",
	"title": "Home_title__3DjR7",
	"description": "Home_description__17Z4F",
	"code": "Home_code__axx2Y",
	"grid": "Home_grid__2Ei2F",
	"card": "Home_card__2SdtB",
	"logo": "Home_logo__1YbrH"
};


/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "@material-ui/core/AppBar":
/*!*******************************************!*\
  !*** external "@material-ui/core/AppBar" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/AppBar");

/***/ }),

/***/ "@material-ui/core/IconButton":
/*!***********************************************!*\
  !*** external "@material-ui/core/IconButton" ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/IconButton");

/***/ }),

/***/ "@material-ui/core/Toolbar":
/*!********************************************!*\
  !*** external "@material-ui/core/Toolbar" ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Toolbar");

/***/ }),

/***/ "@material-ui/core/Typography":
/*!***********************************************!*\
  !*** external "@material-ui/core/Typography" ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Typography");

/***/ }),

/***/ "@material-ui/core/styles":
/*!*******************************************!*\
  !*** external "@material-ui/core/styles" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "@material-ui/icons":
/*!*************************************!*\
  !*** external "@material-ui/icons" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons");

/***/ }),

/***/ "@material-ui/icons/AirlineSeatFlat":
/*!*****************************************************!*\
  !*** external "@material-ui/icons/AirlineSeatFlat" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/AirlineSeatFlat");

/***/ }),

/***/ "@material-ui/icons/Facebook":
/*!**********************************************!*\
  !*** external "@material-ui/icons/Facebook" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Facebook");

/***/ }),

/***/ "@material-ui/icons/Instagram":
/*!***********************************************!*\
  !*** external "@material-ui/icons/Instagram" ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Instagram");

/***/ }),

/***/ "@material-ui/icons/LinkedIn":
/*!**********************************************!*\
  !*** external "@material-ui/icons/LinkedIn" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/LinkedIn");

/***/ }),

/***/ "@material-ui/icons/LocationOn":
/*!************************************************!*\
  !*** external "@material-ui/icons/LocationOn" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/LocationOn");

/***/ }),

/***/ "@material-ui/icons/MailOutline":
/*!*************************************************!*\
  !*** external "@material-ui/icons/MailOutline" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/MailOutline");

/***/ }),

/***/ "@material-ui/icons/Menu":
/*!******************************************!*\
  !*** external "@material-ui/icons/Menu" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Menu");

/***/ }),

/***/ "@material-ui/icons/Phone":
/*!*******************************************!*\
  !*** external "@material-ui/icons/Phone" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Phone");

/***/ }),

/***/ "contentful":
/*!*****************************!*\
  !*** external "contentful" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("contentful");

/***/ }),

/***/ "next/dynamic":
/*!*******************************!*\
  !*** external "next/dynamic" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dynamic");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-bootstrap/Carousel":
/*!*******************************************!*\
  !*** external "react-bootstrap/Carousel" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-bootstrap/Carousel");

/***/ }),

/***/ "react-owl-carousel":
/*!*************************************!*\
  !*** external "react-owl-carousel" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-owl-carousel");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi90by1iYXNlLTY0LmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9pbWFnZS1jb25maWcuanNcIiIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0xheW91dC9jb21wb25lbnRzL0Zvb3Rlci5qc3giLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9MYXlvdXQvY29tcG9uZW50cy9IZWFkZXIuanN4Iiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvTGF5b3V0L2NvbXBvbmVudHMvcGFnZV9jb21wb25lbnQvQmFuZ2Fsb3JlUHJvamVjdC5qc3giLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9MYXlvdXQvY29tcG9uZW50cy9wYWdlX2NvbXBvbmVudC9CYW5nYWxvcmVTbGlkZTIuanN4Iiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvTGF5b3V0L2NvbXBvbmVudHMvcGFnZV9jb21wb25lbnQvQmFubmVyLmpzeCIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0xheW91dC9jb21wb25lbnRzL3BhZ2VfY29tcG9uZW50L0NvdW50cnlDb2RlLmpzeCIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0xheW91dC9jb21wb25lbnRzL3BhZ2VfY29tcG9uZW50L0Zvcm0uanN4Iiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvTGF5b3V0L2NvbXBvbmVudHMvcGFnZV9jb21wb25lbnQvSG9tZVBhZ2UuanN4Iiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvTGF5b3V0L2NvbXBvbmVudHMvcGFnZV9jb21wb25lbnQvTW9kYWxGb3JtLmpzeCIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0xheW91dC9jb21wb25lbnRzL3BhZ2VfY29tcG9uZW50L1ByZXN0aWdlUHJpbXJvc2UuanN4Iiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvTGF5b3V0L2NvbXBvbmVudHMvcGFnZV9jb21wb25lbnQvV2h5UHJlc3RpZ2UuanN4Iiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvY29uZmlnL0N1c3RvbUFwaS5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL2NvbmZpZy9zZXJ2ZXJLZXkuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXh0ZW5kcy5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHQuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZS5qcyIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L2ltYWdlLnRzeCIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3JlcXVlc3QtaWRsZS1jYWxsYmFjay50cyIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3VzZS1pbnRlcnNlY3Rpb24udHN4Iiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L2ltYWdlLmpzIiwid2VicGFjazovLy8uL3BhZ2VzL2luZGV4LmpzIiwid2VicGFjazovLy8uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9BcHBCYXJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9JY29uQnV0dG9uXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvVG9vbGJhclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL1R5cG9ncmFwaHlcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvQWlybGluZVNlYXRGbGF0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL0ZhY2Vib29rXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL0luc3RhZ3JhbVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9pY29ucy9MaW5rZWRJblwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9pY29ucy9Mb2NhdGlvbk9uXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL01haWxPdXRsaW5lXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL01lbnVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvUGhvbmVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJjb250ZW50ZnVsXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9keW5hbWljXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9oZWFkXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9yb3V0ZXJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0LWJvb3RzdHJhcC9DYXJvdXNlbFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0LW93bC1jYXJvdXNlbFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIl0sIm5hbWVzIjpbIkZvb3RlciIsImRhdGEiLCJzZXREYXRhIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJnZXRBcGkiLCJ0aGVuIiwiY29uc29sZSIsImxvZyIsInBob25lX25vIiwicGhvbmUiLCJ3aGF0c2FwcF9ubyIsIndwX2xpbmtzIiwiU1RBVElDX1BIT05FIiwidXNlU3R5bGVzIiwibWFrZVN0eWxlcyIsInRoZW1lIiwicm9vdCIsImZsZXhHcm93IiwibWVudUJ1dHRvbiIsIm1hcmdpblJpZ2h0Iiwic3BhY2luZyIsInRpdGxlIiwiSGVhZGVyIiwiYXJ0aWNsZSIsImJhbmdhbG9yZVByb2plY3RzTGlzdCIsImJhbmdhbG9yZVByb2plY3RMaW5rcyIsImZpZWxkcyIsIm9wZW4iLCJzZXRPcGVuIiwiaGFuZGxlRHJhd2VyIiwiY2xhc3NlcyIsIm1hcCIsIml0ZW0iLCJpIiwiaGVpZ2h0IiwicGFkZGluZyIsIndpZHRoIiwicG9zaXRpb24iLCJyaWdodCIsInRvcCIsIk93bENhcm91c2VsIiwiZHluYW1pYyIsIkJhbmdhbG9yZVByb2plY3QiLCJwcm9qZWN0c0luQmFuZ2Fsb3JlIiwiYmFuZ2Fsb3JlU2xpZGUxQWRkcmVzcyIsImJhbmdhbG9yZVNsaWRlMUJlZEluZm8iLCJiYW5nYWxvcmVTbGlkZTFQcmljZUluZm8iLCJzdGF0ZTEiLCJyZXNwb25zaXZlIiwiaXRlbXMiLCJmaWxlIiwidXJsIiwiZGVzY3JpcHRpb24iLCJCYW5nYWxvcmVTbGlkZTIiLCJiYW5nYWxvcmVQcm9qZWN0U2xpZGUyIiwiYmFuZ2Fsb3JlU2xpZGUyQWRkcmVzcyIsImJhbmdhbG9yZVNsaWRlMkJlZEluZm8iLCJiYW5nYWxvcmVTbGlkZTJQcmljZUluZm8iLCJzdGF0ZSIsIkJhbm5lciIsImJhbm5lckltYWdlcyIsIkNvdW50cnlDb2RlIiwiRm9ybSIsInJvdXRlciIsInVzZVJvdXRlciIsIndpbmRvdyIsInByb2plY3RuYW1lIiwicHJvamVjdF9uYW1lIiwiY2l0eSIsImluaXRpYWxEYXRhIiwibmFtZSIsImVtYWlsIiwibnVtYmVyIiwiY291bnRyeWNvZGUiLCJtZXNzYWdlIiwiZGF0YUZvcm0iLCJzZXREYXRhRm9ybSIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsIm9iaiIsInBfdXNlcm5hbWUiLCJwX21vYmlsZW51bWJlciIsInBfZW1haWwiLCJwX2NvdW50cnljb2RlIiwicF9tc2ciLCJwX2xlYWR0eXBlIiwicF9sYXVuY2huYW1lIiwicF9zb3VyY2UiLCJwX2NpdHkiLCJwb3N0QXBpIiwicHVzaCIsImhhbmRsZUNoYW5nZSIsInZhbHVlIiwidGFyZ2V0IiwiRk9STV9JQ09OIiwiSG9tZVBhZ2UiLCJwcmVzdGlnZUJhbmdhbG9yZVBhcmEiLCJvcGVuRm9ybSIsInNldE9wZW5Gb3JtIiwiaGFuZGxlRHJhd2VyRm9ybSIsImNvbnRlbnQiLCJ6SW5kZXgiLCJjb2xvciIsIk1vZGFsRm9ybSIsImxvY2F0aW9uIiwiTVlfTE9DQVRJT04iLCJMT0NBVElPTl9JTUciLCJQcmVzdGlnZVByaW1yb3NlIiwicHJlc3RpZ2VQcmltcm9zZSIsIldoeVByZXN0aWdlIiwid2h5UHJlc3RpZ2UiLCJyZXMiLCJmZXRjaCIsIkFQSV9VUkwiLCJHRVRfREFUQV9BUEkiLCJqc29uIiwicmVzdWx0IiwiYm9keSIsIm1ldGhvZCIsImhlYWRlcnMiLCJKU09OIiwic3RyaW5naWZ5IiwicmVzcCIsIlBST0pFQ1RfTE9HTyIsIkhPTUVTRllfTE9HTyIsIkhPTUVTRllfVVJMIiwiSE9NRVNGWV9GQUNFQk9PSyIsIkhPTUVTRllfSU5TVEFHUkFNIiwiZ2xvYmFsIiwiVkFMSURfTE9BRElOR19WQUxVRVMiLCJsb2FkZXJzIiwiVkFMSURfTEFZT1VUX1ZBTFVFUyIsImRldmljZVNpemVzIiwiaW1hZ2VTaXplcyIsImxvYWRlciIsInBhdGgiLCJkb21haW5zIiwiZW5hYmxlQmx1cnJ5UGxhY2Vob2xkZXIiLCJwcm9jZXNzIiwiaW1hZ2VDb25maWdEZWZhdWx0IiwiYWxsU2l6ZXMiLCJjb25maWdEZXZpY2VTaXplcyIsImEiLCJzaXplcyIsImxheW91dCIsInZpZXdwb3J0V2lkdGhSZSIsInBlcmNlbnRTaXplcyIsIm1hdGNoIiwicGFyc2VJbnQiLCJzbWFsbGVzdFJhdGlvIiwiTWF0aCIsIndpZHRocyIsInMiLCJraW5kIiwidyIsInAiLCJzcmNTZXQiLCJnZXRXaWR0aHMiLCJsYXN0Iiwic3JjIiwibG9hZCIsIlZBTElEX0xPQURFUlMiLCJjb25maWdMb2FkZXIiLCJwbGFjZWhvbGRlciIsImVsZW1lbnQiLCJ1bm9wdGltaXplZCIsInByaW9yaXR5IiwiYWxsIiwicmVzdCIsInVuc2l6ZWQiLCJCb29sZWFuIiwibG9hZGluZyIsImlzTGF6eSIsInJvb3RNYXJnaW4iLCJkaXNhYmxlZCIsImlzVmlzaWJsZSIsIndpZHRoSW50IiwiZ2V0SW50IiwiaGVpZ2h0SW50IiwicXVhbGl0eUludCIsIk1JTl9JTUdfU0laRV9GT1JfUExBQ0VIT0xERVIiLCJ0b29TbWFsbEZvckJsdXJyeVBsYWNlaG9sZGVyIiwic2hvdWxkU2hvd0JsdXJyeVBsYWNlaG9sZGVyIiwiaW1nU3R5bGUiLCJsZWZ0IiwiYm90dG9tIiwiYm94U2l6aW5nIiwiYm9yZGVyIiwibWFyZ2luIiwiZGlzcGxheSIsIm1pbldpZHRoIiwibWF4V2lkdGgiLCJtaW5IZWlnaHQiLCJtYXhIZWlnaHQiLCJiYWNrZ3JvdW5kU2l6ZSIsImJhY2tncm91bmRJbWFnZSIsImJsdXJEYXRhVVJMIiwicXVvdGllbnQiLCJwYWRkaW5nVG9wIiwiaXNOYU4iLCJ3cmFwcGVyU3R5bGUiLCJvdmVyZmxvdyIsInNpemVyU3R5bGUiLCJzaXplclN2ZyIsImltZ0F0dHJpYnV0ZXMiLCJnZW5lcmF0ZUltZ0F0dHJzIiwicXVhbGl0eSIsInNldFJlZiIsInJlbW92ZVBsYWNlaG9sZGVyIiwicGFyYW1zIiwicGFyYW1zU3RyaW5nIiwibm9ybWFsaXplU3JjIiwibWlzc2luZ1ZhbHVlcyIsInBhcnNlZFNyYyIsImNvbmZpZ0RvbWFpbnMiLCJob3N0bmFtZSIsImVuY29kZVVSSUNvbXBvbmVudCIsInJlcXVlc3RJZGxlQ2FsbGJhY2siLCJzZWxmIiwic3RhcnQiLCJEYXRlIiwic2V0VGltZW91dCIsImNiIiwiZGlkVGltZW91dCIsInRpbWVSZW1haW5pbmciLCJjYW5jZWxJZGxlQ2FsbGJhY2siLCJjbGVhclRpbWVvdXQiLCJoYXNJbnRlcnNlY3Rpb25PYnNlcnZlciIsImlzRGlzYWJsZWQiLCJ1bm9ic2VydmUiLCJlbCIsIm9ic2VydmUiLCJzZXRWaXNpYmxlIiwiaWRsZUNhbGxiYWNrIiwiY3JlYXRlT2JzZXJ2ZXIiLCJlbGVtZW50cyIsIm9ic2VydmVyIiwib2JzZXJ2ZXJzIiwiaWQiLCJvcHRpb25zIiwiaW5zdGFuY2UiLCJlbnRyaWVzIiwiZW50cnkiLCJjYWxsYmFjayIsImdldFN0YXRpY1Byb3BzIiwiY2xpZW50IiwiY3JlYXRlQ2xpZW50Iiwic3BhY2UiLCJlbnYiLCJDT05URU5URlVMX1NQQUNFX0lEIiwiYWNjZXNzVG9rZW4iLCJDT05URU5URlVMX0FDQ0VTU19LRVkiLCJnZXRFbnRyaWVzIiwiY29udGVudF90eXBlIiwicHJvcHMiLCJhcnRpY2xlcyIsIkhvbWUiLCJ3YXJuIiwiaW5kZXgiXSwibWFwcGluZ3MiOiI7O1FBQUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQUk7UUFDSjtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSxjQUFjO1FBQ2QsSUFBSTtRQUNKOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7QUNyR0EsOEQ7Ozs7Ozs7Ozs7O0FDQUEsb0U7Ozs7Ozs7Ozs7O0FDQUEseUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHTyxNQUFNQSxNQUFNLEdBQUcsTUFBTTtBQUV4QixRQUFNO0FBQUEsT0FBQ0MsSUFBRDtBQUFBLE9BQU9DO0FBQVAsTUFBa0JDLHNEQUFRLENBQUMsSUFBRCxDQUFoQztBQUNBQyx5REFBUyxDQUFDLE1BQU07QUFDZEMsb0VBQU0sR0FBR0MsSUFBVCxDQUFlTCxJQUFELElBQVU7QUFDdEJNLGFBQU8sQ0FBQ0MsR0FBUixDQUFZUCxJQUFaO0FBQ0FDLGFBQU8sQ0FBQ0QsSUFBRCxDQUFQO0FBQ0QsS0FIRDtBQUlELEdBTFEsRUFLTixFQUxNLENBQVQ7QUFNQSxRQUFNUSxRQUFRLEdBQUNSLElBQUQsYUFBQ0EsSUFBRCx1QkFBQ0EsSUFBSSxDQUFFUyxLQUFyQjtBQUNBLFFBQU1DLFdBQVcsR0FBQ1YsSUFBRCxhQUFDQSxJQUFELHVCQUFDQSxJQUFJLENBQUVXLFFBQXhCO0FBQ0Esc0JBQ0k7QUFBQSw0QkFDSDtBQUFRLFFBQUUsRUFBQyxXQUFYO0FBQXVCLGVBQVMsRUFBQyxRQUFqQztBQUFBLDZCQUNHO0FBQUssaUJBQVMsRUFBQyxtQkFBZjtBQUFBLGdDQUNFO0FBQUssbUJBQVMsRUFBQyxjQUFmO0FBQThCLFlBQUUsRUFBQyxlQUFqQztBQUFBLGlDQUNFO0FBQUEsb0NBQ0U7QUFBQSxxQ0FDRTtBQUNFLHlCQUFTLEVBQUVILFFBQVEsSUFBSUksOERBRHpCO0FBRUUsb0JBQUksRUFBRSxTQUFRLEdBQUVKLFFBQVMsRUFGM0I7QUFBQSx1Q0FJRTtBQUFLLHFCQUFHLEVBQUMseUJBQVQ7QUFBbUMscUJBQUcsRUFBQztBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFTRTtBQUFBLHFDQUNFO0FBQUcseUJBQVMsRUFBQyxhQUFiO0FBQTJCLG9CQUFJLEVBQUcsR0FBRUUsV0FBWSxFQUFmLEdBQWlCLG9DQUFsRDtBQUFBLHVDQUNFO0FBQUsscUJBQUcsRUFBQyw0QkFBVDtBQUFzQyxxQkFBRyxFQUFDO0FBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBa0JFO0FBQUssbUJBQVMsRUFBQyxxQkFBZjtBQUFBLGtDQUNFO0FBQUsscUJBQVMsRUFBQyxzQ0FBZjtBQUFBLG1DQUNFO0FBQUssdUJBQVMsRUFBQyxlQUFmO0FBQUEsc0NBQ0U7QUFBSyx5QkFBUyxFQUFDLDhDQUFmO0FBQUEsd0NBQ0U7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSx5Q0FDRSxxRUFBQyxxRUFBRDtBQUFpQiw2QkFBUyxFQUFDO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURGLGVBSUU7QUFBSywyQkFBUyxFQUFDLG9CQUFmO0FBQUEsMENBQ0U7QUFBSSw2QkFBUyxFQUFDLDZCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLGVBRUU7QUFBRyx3QkFBSSxFQUFDLEtBQVI7QUFBYyxzQkFBRSxFQUFDLFdBQWpCO0FBQTZCLDZCQUFTLEVBQUMsY0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQVlFO0FBQUsseUJBQVMsRUFBQyw4Q0FBZjtBQUFBLHdDQUNFO0FBQUssMkJBQVMsRUFBQyxNQUFmO0FBQUEseUNBQ0UscUVBQUMsK0RBQUQ7QUFBVyw2QkFBUyxFQUFDO0FBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURGLGVBSUU7QUFBSywyQkFBUyxFQUFDLG9CQUFmO0FBQUEsMENBQ0U7QUFBSSw2QkFBUyxFQUFDLDZCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLGVBRUU7QUFDRSx3QkFBSSxFQUFDLGlCQURQO0FBRUUsNkJBQVMsRUFBQyx1QkFGWjtBQUdFLHNCQUFFLEVBQUMsV0FITDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFGRixFQVFPLEdBUlAsZUFTRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBWkYsZUE0QkU7QUFBSyx5QkFBUyxFQUFDLDhDQUFmO0FBQUEsd0NBQ0U7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSx5Q0FDRSxxRUFBQyxvRUFBRDtBQUFnQiw2QkFBUyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURGLGVBSUU7QUFBSywyQkFBUyxFQUFDLG9CQUFmO0FBQUEsMENBQ0U7QUFBSSw2QkFBUyxFQUFDLDZCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkE1QkYsZUF3Q0U7QUFBSSx5QkFBUyxFQUFDLHFDQUFkO0FBQUEsd0NBQ0U7QUFBSSwyQkFBUyxFQUFDLGtCQUFkO0FBQUEseUNBQ0U7QUFDRSx3QkFBSSxFQUFDLGtDQURQO0FBRUUsMEJBQU0sRUFBQyxNQUZUO0FBR0UsNkJBQVMsRUFBQyxTQUhaO0FBQUEsMkNBS0UscUVBQUMsa0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURGLGVBVUU7QUFBSSwyQkFBUyxFQUFDLGtCQUFkO0FBQUEseUNBQ0U7QUFDRSx3QkFBSSxFQUFDLDhEQURQO0FBRUUsMEJBQU0sRUFBQyxNQUZUO0FBR0UsNkJBQVMsRUFBQyxTQUhaO0FBQUEsMkNBS0UscUVBQUMsbUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVZGLGVBbUJFO0FBQUksMkJBQVMsRUFBQyxrQkFBZDtBQUFBLHlDQUNFO0FBQ0Usd0JBQUksRUFBQywyQ0FEUDtBQUVFLDBCQUFNLEVBQUMsTUFGVDtBQUdFLDZCQUFTLEVBQUMsU0FIWjtBQUFBLDJDQUtFLHFFQUFDLGtFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBeUVFO0FBQUsscUJBQVMsRUFBQyxvREFBZjtBQUFBLG9DQUNFO0FBQUksdUJBQVMsRUFBQyx3QkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUVFO0FBQUksdUJBQVMsRUFBQyxnQ0FBZDtBQUFBLHNDQUNFO0FBQUEsdUNBQ0U7QUFDRSxzQkFBSSxFQUFDLDZDQURQO0FBRUUsMkJBQVMsRUFBQyxXQUZaO0FBR0Usd0JBQU0sRUFBQyxNQUhUO0FBQUEsMENBS0U7QUFBRyw2QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBV0U7QUFBQSx1Q0FDRTtBQUNFLHNCQUFJLEVBQUMsNENBRFA7QUFFRSwyQkFBUyxFQUFDLFdBRlo7QUFHRSx3QkFBTSxFQUFDLE1BSFQ7QUFBQSwwQ0FLRTtBQUFHLDZCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBWEYsZUFxQkU7QUFBQSx1Q0FDRTtBQUNFLHNCQUFJLEVBQUMsa0RBRFA7QUFFRSwyQkFBUyxFQUFDLFdBRlo7QUFHRSx3QkFBTSxFQUFDLE1BSFQ7QUFBQSwwQ0FLRTtBQUFHLDZCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBckJGLGVBK0JFO0FBQUEsdUNBQ0U7QUFDRSxzQkFBSSxFQUFDLCtDQURQO0FBRUUsMkJBQVMsRUFBQyxXQUZaO0FBR0Usd0JBQU0sRUFBQyxNQUhUO0FBQUEsMENBS0U7QUFBRyw2QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXpFRixlQXNIRTtBQUFLLHFCQUFTLEVBQUMsb0RBQWY7QUFBQSxvQ0FDRTtBQUFJLHVCQUFTLEVBQUMsd0JBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFFRTtBQUFJLHVCQUFTLEVBQUMsZ0NBQWQ7QUFBQSxzQ0FDRTtBQUFBLHVDQUNFO0FBQ0Usc0JBQUksRUFBQywrQ0FEUDtBQUVFLDJCQUFTLEVBQUMsV0FGWjtBQUdFLHdCQUFNLEVBQUMsTUFIVDtBQUFBLDBDQUtFO0FBQUcsNkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQVdFO0FBQUEsdUNBQ0U7QUFDRSxzQkFBSSxFQUFDLHlDQURQO0FBRUUsMkJBQVMsRUFBQyxXQUZaO0FBR0Usd0JBQU0sRUFBQyxNQUhUO0FBQUEsMENBS0U7QUFBRyw2QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdEhGLGVBK0lFO0FBQUsscUJBQVMsRUFBQyxvREFBZjtBQUFBLG9DQUNFO0FBQUksdUJBQVMsRUFBQyx3QkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUVFO0FBQUksdUJBQVMsRUFBQyxnQ0FBZDtBQUFBLHNDQUNFO0FBQUEsdUNBQ0U7QUFDRSxzQkFBSSxFQUFDLHNDQURQO0FBRUUsMkJBQVMsRUFBQyxXQUZaO0FBR0Usd0JBQU0sRUFBQyxNQUhUO0FBQUEsMENBS0U7QUFBRyw2QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBVUU7QUFBQSx1Q0FDRTtBQUNFLHNCQUFJLEVBQUMsa0NBRFA7QUFFRSwyQkFBUyxFQUFDLFdBRlo7QUFHRSx3QkFBTSxFQUFDLE1BSFQ7QUFBQSwwQ0FLRTtBQUFHLDZCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVkYsZUFtQkU7QUFBQSx1Q0FDRTtBQUNFLHNCQUFJLEVBQUMscUNBRFA7QUFFRSwyQkFBUyxFQUFDLFdBRlo7QUFHRSx3QkFBTSxFQUFDLE1BSFQ7QUFBQSwwQ0FLRTtBQUFHLDZCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBbkJGLGVBNkJFO0FBQUEsdUNBQ0U7QUFDRSxzQkFBSSxFQUFDLG1DQURQO0FBRUUsMkJBQVMsRUFBQyxXQUZaO0FBR0Usd0JBQU0sRUFBQyxNQUhUO0FBQUEsMENBS0U7QUFBRyw2QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQS9JRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREcsZUFpTkY7QUFBUSxlQUFTLEVBQUMsbUJBQWxCO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLCtCQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLHdCQUFmO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLFdBQWY7QUFBQSxtQ0FDRTtBQUFLLHVCQUFTLEVBQUMsZ0JBQWY7QUFBQSxxQ0FDRTtBQUFHLHlCQUFTLEVBQUMsTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWpORTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQTJPSCxDQXRQTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1hQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQUVBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTUcsU0FBUyxHQUFHQywyRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDdkNDLE1BQUksRUFBRTtBQUNKQyxZQUFRLEVBQUU7QUFETixHQURpQztBQUl2Q0MsWUFBVSxFQUFFO0FBQ1ZDLGVBQVcsRUFBRUosS0FBSyxDQUFDSyxPQUFOLENBQWMsQ0FBZDtBQURILEdBSjJCO0FBT3ZDQyxPQUFLLEVBQUU7QUFDTEosWUFBUSxFQUFFO0FBREw7QUFQZ0MsQ0FBWixDQUFELENBQTVCO0FBWU8sTUFBTUssTUFBTSxHQUFHLENBQUM7QUFBQ0M7QUFBRCxDQUFELEtBQWU7QUFDbkMsUUFBTTtBQUFDQyx5QkFBRDtBQUF1QkM7QUFBdkIsTUFBOENGLE9BQU8sQ0FBQ0csTUFBNUQ7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsSUFBRDtBQUFBLE9BQU9DO0FBQVAsTUFBa0IxQixzREFBUSxDQUFDLEtBQUQsQ0FBaEM7O0FBQ0EsUUFBTTJCLFlBQVksR0FBRyxNQUFNO0FBQ3pCRCxXQUFPLENBQUMsSUFBRCxDQUFQO0FBQ0QsR0FGRDs7QUFHQSxRQUFNO0FBQUEsT0FBQzVCLElBQUQ7QUFBQSxPQUFPQztBQUFQLE1BQWtCQyxzREFBUSxDQUFDLEVBQUQsQ0FBaEM7QUFDQUMseURBQVMsQ0FBQyxNQUFNO0FBQ2RDLHFFQUFNLEdBQUdDLElBQVQsQ0FBZUwsSUFBRCxJQUFVO0FBQ3RCQyxhQUFPLENBQUNELElBQUQsQ0FBUDtBQUNELEtBRkQ7QUFHRCxHQUpRLEVBSU4sRUFKTSxDQUFUO0FBS0EsUUFBTThCLE9BQU8sR0FBR2pCLFNBQVMsRUFBekI7QUFFQSxzQkFDRTtBQUFBLDJCQUNFO0FBQUssZUFBUyxFQUFDLFVBQWY7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUVpQixPQUFPLENBQUNkLElBQXhCO0FBQUEsZ0NBQ0UscUVBQUMsNkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFLHFFQUFDLCtEQUFEO0FBQUEsaUNBQ0UscUVBQUMsZ0VBQUQ7QUFBQSxvQ0FDRSxxRUFBQyxtRUFBRDtBQUFZLHFCQUFPLEVBQUMsSUFBcEI7QUFBeUIsdUJBQVMsRUFBRWMsT0FBTyxDQUFDVCxLQUE1QztBQUFBLHFDQUNFO0FBQ0UsbUJBQUcsRUFBQyx1REFETjtBQUVFLG1CQUFHLEVBQUM7QUFGTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQU9FO0FBQUksdUJBQVMsRUFBQywwQkFBZDtBQUFBLHNDQUNFO0FBQUEsdUNBQ0U7QUFBRyxzQkFBSSxFQUFDLElBQVI7QUFBQSx5Q0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBTUU7QUFBSSx5QkFBUyxFQUFDLGNBQWQ7QUFBQSx3Q0FDRTtBQUFHLHNCQUFJLEVBQUMsSUFBUjtBQUFBLHlDQUNFO0FBQUEseURBQ1c7QUFBTSwrQkFBUyxFQUFDO0FBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFERixlQU1FO0FBQUksMkJBQVMsRUFBQyxTQUFkO0FBQUEsNEJBRUVHLHFCQUFxQixDQUFDTyxHQUF0QixDQUEwQixDQUFDQyxJQUFELEVBQU1DLENBQU4sa0JBQ3hCO0FBQUEsMkNBQ0E7QUFBRywwQkFBSSxFQUFFUixxQkFBcUIsQ0FBQ1EsQ0FBRCxDQUE5QjtBQUFtQyw0QkFBTSxFQUFDLE1BQTFDO0FBQUEsZ0NBQ0dULHFCQUFxQixDQUFDUyxDQUFEO0FBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQSxxQkFBU0EsQ0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGO0FBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTkYsZUF3QkU7QUFBQSx1Q0FDRTtBQUFHLHNCQUFJLEVBQUMsSUFBUjtBQUFhLGlDQUFZLE9BQXpCO0FBQWlDLGlDQUFZLFVBQTdDO0FBQUEseUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkF4QkYsZUE2QkU7QUFBQSx1Q0FDRTtBQUFHLHNCQUFJLEVBQUMsSUFBUjtBQUFhLGlDQUFZLE9BQXpCO0FBQWlDLGlDQUFZLFVBQTdDO0FBQUEseUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkE3QkYsZUFrQ0U7QUFBQSx1Q0FDRTtBQUFHLHNCQUFJLEVBQUMsSUFBUjtBQUFhLGlDQUFZLE9BQXpCO0FBQWlDLGlDQUFZLFVBQTdDO0FBQUEseUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVBGLGVBK0NFO0FBQUEscUNBQ0UscUVBQUMsbUVBQUQ7QUFDRSx1QkFBTyxFQUFFSixZQURYO0FBRUUsb0JBQUksRUFBQyxPQUZQO0FBR0UseUJBQVMsRUFBRyxHQUFFQyxPQUFPLENBQUNaLFVBQVcsR0FIbkM7QUFJRSxxQkFBSyxFQUFDLFNBSlI7QUFLRSw4QkFBVyxNQUxiO0FBQUEsdUNBT0UscUVBQUMsOERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBK0RFLHFFQUFDLHdEQUFEO0FBQ0UsZ0JBQU0sRUFBQyxPQURUO0FBRUUsY0FBSSxFQUFFUyxJQUZSO0FBR0UsaUJBQU8sRUFBRSxNQUFNO0FBQ2JDLG1CQUFPLENBQUMsS0FBRCxDQUFQO0FBQ0QsV0FMSDtBQUFBLGlDQU9FO0FBQ0UsaUJBQUssRUFBRTtBQUFFTSxvQkFBTSxFQUFFLE9BQVY7QUFBbUJDLHFCQUFPLEVBQUUsV0FBNUI7QUFBeUNDLG1CQUFLLEVBQUU7QUFBaEQsYUFEVDtBQUFBLG9DQUdFLHFFQUFDLG1FQUFEO0FBQ0UscUJBQU8sRUFBRSxNQUFNO0FBQ2JSLHVCQUFPLENBQUMsS0FBRCxDQUFQO0FBQ0QsZUFISDtBQUlFLG1CQUFLLEVBQUMsU0FKUjtBQUtFLG1CQUFLLEVBQUU7QUFBRVMsd0JBQVEsRUFBRSxVQUFaO0FBQXdCQyxxQkFBSyxFQUFFLEdBQS9CO0FBQW9DQyxtQkFBRyxFQUFFO0FBQXpDLGVBTFQ7QUFBQSxxQ0FPRSxxRUFBQyxnRUFBRDtBQUFlLHFCQUFLLEVBQUM7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSEYsZUFZRTtBQUFBLHFDQUNFO0FBQUsseUJBQVMsRUFBQyxXQUFmO0FBQUEsdUNBQ0U7QUFBQSwwQ0FDRTtBQUFBLDJDQUNFO0FBQUcsMEJBQUksRUFBQyxXQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERixlQUlFO0FBQUEsMkNBQ0U7QUFBRywwQkFBSSxFQUFDLElBQVI7QUFBYSxxQ0FBWSxPQUF6QjtBQUFpQyxxQ0FBWSxVQUE3QztBQUFBLCtDQUNhLEdBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFKRixlQVNFO0FBQUEsMkNBQ0U7QUFBRywwQkFBSSxFQUFDLElBQVI7QUFBYSxxQ0FBWSxPQUF6QjtBQUFpQyxxQ0FBWSxVQUE3QztBQUFBLDZDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBVEYsZUFjRTtBQUFBLDJDQUNFO0FBQUcsMEJBQUksRUFBQyxJQUFSO0FBQWEscUNBQVksT0FBekI7QUFBaUMscUNBQVksVUFBN0M7QUFBQSw2Q0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQWRGLGVBbUJFO0FBQUEsMkNBQ0U7QUFBRywrQkFBUyxFQUFDLFdBQWI7QUFBeUIsMEJBQUksRUFBQyxpQkFBOUI7QUFBQSw2Q0FDRTtBQUFNLGlDQUFTLEVBQUMsVUFBaEI7QUFBQSxrQ0FDRyxDQUFBdkMsSUFBSSxTQUFKLElBQUFBLElBQUksV0FBSixZQUFBQSxJQUFJLENBQUVTLEtBQU4sS0FBZUcsK0RBQVlBO0FBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEvREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTBIRCxDQXhJTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCUDtBQUNBLE1BQU00QixXQUFXLEdBQUdDLG1EQUFPLE9BQUMsMEhBQUQ7QUFBQTtBQUFBLHdDQUFRLDhDQUFSO0FBQUEsK0ZBQVEsb0JBQVI7QUFBQTtBQUFBLEVBQTNCO0FBQ0E7QUFDQTtBQUNBO0FBRU8sTUFBTUMsZ0JBQWdCLEdBQUcsQ0FBQztBQUFFbkI7QUFBRixDQUFELEtBQWlCO0FBQy9DLFFBQU07QUFDSm9CLHVCQURJO0FBRUpDLDBCQUZJO0FBR0pDLDBCQUhJO0FBSUpDO0FBSkksTUFLRnZCLE9BQU8sQ0FBQ0csTUFMWjtBQU1BLFFBQU1xQixNQUFNLEdBQUc7QUFDYkMsY0FBVSxFQUFFO0FBQ1YsU0FBRztBQUNEQyxhQUFLLEVBQUU7QUFETixPQURPO0FBSVYsV0FBSztBQUNIQSxhQUFLLEVBQUU7QUFESixPQUpLO0FBT1YsV0FBSztBQUNIQSxhQUFLLEVBQUU7QUFESixPQVBLO0FBVVYsWUFBTTtBQUNKQSxhQUFLLEVBQUU7QUFESDtBQVZJO0FBREMsR0FBZjtBQWlCQSxzQkFDRTtBQUFBLDJCQUNFO0FBQUssZUFBUyxFQUFDLEtBQWY7QUFBQSw2QkFDRSxxRUFBQyxXQUFEO0FBQ0UsYUFBSyxFQUFFLENBRFQ7QUFFRSxpQkFBUyxFQUFDLFdBRlo7QUFHRSxZQUFJLE1BSE47QUFJRSxXQUFHLE1BSkw7QUFLRSxjQUFNLEVBQUUsRUFMVjtBQU1FLGtCQUFVLEVBQUVGLE1BQU0sQ0FBQ0MsVUFOckI7QUFBQSxrQkFRR0wsbUJBQW1CLENBQUNaLEdBQXBCLENBQXdCLENBQUNDLElBQUQsRUFBT0MsQ0FBUDtBQUFBOztBQUFBLDhCQUN2QjtBQUNFLHFCQUFTLEVBQUMsa0VBRFo7QUFBQSxtQ0FJRTtBQUFLLHVCQUFTLEVBQUMsZUFBZjtBQUFBLHNDQUNFO0FBQUcsb0JBQUksRUFBQyxJQUFSO0FBQUEsdUNBQ0U7QUFDRSxxQkFBRywyQkFBRVUsbUJBQW1CLENBQUNWLENBQUQsQ0FBckIsb0ZBQUUsc0JBQXdCUCxNQUExQixxRkFBRSx1QkFBZ0N3QixJQUFsQywyREFBRSx1QkFBc0NDLEdBRDdDO0FBRUUsMkJBQVMsRUFBQyxXQUZaO0FBR0UscUJBQUcsNEJBQUVSLG1CQUFtQixDQUFDVixDQUFELENBQXJCLHFGQUFFLHVCQUF3QlAsTUFBMUIsMkRBQUUsdUJBQWdDTDtBQUh2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQVFFO0FBQUsseUJBQVMsRUFBQyxzQkFBZjtBQUFBLHdDQUNFO0FBQUksMkJBQVMsRUFBQyxNQUFkO0FBQUEseUNBQ0U7QUFBRyx3QkFBSSxFQUFDLElBQVI7QUFBQSx3REFBY3NCLG1CQUFtQixDQUFDVixDQUFELENBQWpDLHFGQUFjLHVCQUF3QlAsTUFBdEMsMkRBQWMsdUJBQWdDTDtBQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFERixlQUlFO0FBQUksMkJBQVMsRUFBQyxxQkFBZDtBQUFBLHlDQUNFO0FBQUcsd0JBQUksRUFBQyxJQUFSO0FBQUEsMkNBQ0U7QUFBRywrQkFBUyxFQUFDLFVBQWI7QUFBQSxnQ0FBeUJ1QixzQkFBc0IsQ0FBQ1gsQ0FBRDtBQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSkYsZUFTRTtBQUFLLDJCQUFTLEVBQUMsK0NBQWY7QUFBQSwwQ0FDRTtBQUFJLDZCQUFTLEVBQUMsb0JBQWQ7QUFBQSwyQ0FDRTtBQUFJLCtCQUFTLEVBQUMsdUJBQWQ7QUFBQSw4Q0FDRTtBQUFHLGlDQUFTLEVBQUMsaUNBQWI7QUFBQSwrQ0FDRSxxRUFBQyx5RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FERixFQUlHWSxzQkFBc0IsQ0FBQ1osQ0FBRCxDQUp6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLGVBU0U7QUFDRSw2QkFBUyxFQUFDLHFCQURaO0FBRUUsbUNBQVksT0FGZDtBQUdFLG1DQUFZLFVBSGQ7QUFJRSx3QkFBSSxFQUFDLElBSlA7QUFBQSw4QkFNR2Esd0JBQXdCLENBQUNiLENBQUQ7QUFOM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVJGLGVBb0NFO0FBQUsseUJBQVMsRUFBQyw4Q0FBZjtBQUFBLHVDQUNFO0FBQU0sMkJBQVMsRUFBQyxlQUFoQjtBQUFBLHNEQUNHVSxtQkFBbUIsQ0FBQ1YsQ0FBRCxDQUR0QixxRkFDRyx1QkFBd0JQLE1BRDNCLDJEQUNHLHVCQUFnQzBCO0FBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRixhQUVPbkIsQ0FGUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUR1QjtBQUFBLFNBQXhCO0FBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFnRUQsQ0F4Rk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNOUDtBQUNBO0FBQ0EsTUFBTU8sV0FBVyxHQUFHQyxtREFBTyxPQUFDLDBIQUFEO0FBQUE7QUFBQSx3Q0FBUSw4Q0FBUjtBQUFBLDhGQUFRLG9CQUFSO0FBQUE7QUFBQSxFQUEzQjtBQUNBO0FBQ0E7QUFFTyxNQUFNWSxlQUFlLEdBQUcsQ0FBQztBQUFDOUI7QUFBRCxDQUFELEtBQWU7QUFDMUMsUUFBTTtBQUNGK0IsMEJBREU7QUFFRkMsMEJBRkU7QUFHRkMsMEJBSEU7QUFJRkM7QUFKRSxNQUl5QmxDLE9BQU8sQ0FBQ0csTUFKdkM7QUFLSSxRQUFNZ0MsS0FBSyxHQUFHO0FBQ1ZWLGNBQVUsRUFBRTtBQUNWLFNBQUc7QUFDREMsYUFBSyxFQUFFO0FBRE4sT0FETztBQUlWLFdBQUs7QUFDSEEsYUFBSyxFQUFFO0FBREosT0FKSztBQU9WLFdBQUs7QUFDSEEsYUFBSyxFQUFFO0FBREosT0FQSztBQVVWLFlBQU07QUFDSkEsYUFBSyxFQUFFO0FBREg7QUFWSTtBQURGLEdBQWQ7QUFnQkosc0JBQ0k7QUFBQSwyQkFDTTtBQUFLLGVBQVMsRUFBQyxLQUFmO0FBQUEsNkJBQ0kscUVBQUMsV0FBRDtBQUNFLGFBQUssRUFBRSxDQURUO0FBRUUsaUJBQVMsRUFBQyxXQUZaO0FBR0UsWUFBSSxNQUhOO0FBSUUsV0FBRyxNQUpMO0FBS0UsY0FBTSxFQUFFLEVBTFY7QUFNRSxrQkFBVSxFQUFFUyxLQUFLLENBQUNWLFVBTnBCO0FBQUEsa0JBUUdNLHNCQUFzQixDQUFDdkIsR0FBdkIsQ0FBMkIsQ0FBQ0MsSUFBRCxFQUFPQyxDQUFQO0FBQUE7O0FBQUEsOEJBQzFCO0FBQUsscUJBQVMsRUFBQyxrRUFBZjtBQUFBLG1DQUNFO0FBQUssdUJBQVMsRUFBQyxlQUFmO0FBQUEsc0NBQ0U7QUFBRyxvQkFBSSxFQUFDLElBQVI7QUFBQSx1Q0FDRTtBQUNFLHFCQUFHLDJCQUFFcUIsc0JBQXNCLENBQUNyQixDQUFELENBQXhCLG9GQUFFLHNCQUEyQlAsTUFBN0IscUZBQUUsdUJBQW1Dd0IsSUFBckMsMkRBQUUsdUJBQXlDQyxHQURoRDtBQUVFLDJCQUFTLEVBQUMsV0FGWjtBQUdFLHFCQUFHLDRCQUFFRyxzQkFBc0IsQ0FBQ3JCLENBQUQsQ0FBeEIscUZBQUUsdUJBQTJCUCxNQUE3QiwyREFBRSx1QkFBbUNMO0FBSDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBUUU7QUFBSyx5QkFBUyxFQUFDLHNCQUFmO0FBQUEsd0NBQ0U7QUFBSSwyQkFBUyxFQUFDLE1BQWQ7QUFBQSx5Q0FDRTtBQUFHLHdCQUFJLEVBQUMsSUFBUjtBQUFhLDBCQUFNLEVBQUMsTUFBcEI7QUFBQSx3REFDR2lDLHNCQUFzQixDQUFDckIsQ0FBRCxDQUR6QixxRkFDRyx1QkFBMkJQLE1BRDlCLDJEQUNHLHVCQUFtQ0w7QUFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFNRTtBQUFJLDJCQUFTLEVBQUMscUJBQWQ7QUFBQSx5Q0FDRTtBQUFHLHdCQUFJLEVBQUMsSUFBUjtBQUFBLDJDQUNFO0FBQUcsK0JBQVMsRUFBQyxVQUFiO0FBQUEsZ0NBQ0drQyxzQkFBc0IsQ0FBQ3RCLENBQUQ7QUFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQU5GLGVBYUU7QUFBSywyQkFBUyxFQUFDLCtDQUFmO0FBQUEsMENBQ0U7QUFBSSw2QkFBUyxFQUFDLG9CQUFkO0FBQUEsMkNBQ0U7QUFBSSwrQkFBUyxFQUFDLHVCQUFkO0FBQUEsOENBQ0U7QUFBRyxpQ0FBUyxFQUFDLGlDQUFiO0FBQUEsK0NBQ0UscUVBQUMseUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBREYsRUFJR3VCLHNCQUFzQixDQUFDdkIsQ0FBRCxDQUp6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLGVBU0U7QUFDRSw2QkFBUyxFQUFDLHFCQURaO0FBRUUsbUNBQVksT0FGZDtBQUdFLG1DQUFZLFVBSGQ7QUFJRSx3QkFBSSxFQUFDLElBSlA7QUFBQSw4QkFNR3dCLHdCQUF3QixDQUFDeEIsQ0FBRDtBQU4zQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUkYsZUF3Q0U7QUFBSyx5QkFBUyxFQUFDLDhDQUFmO0FBQUEsdUNBQ0U7QUFBTSwyQkFBUyxFQUFDLGVBQWhCO0FBQUEsc0RBQ0dxQixzQkFBc0IsQ0FBQ3JCLENBQUQsQ0FEekIscUZBQ0csdUJBQTJCUCxNQUQ5QiwyREFDRyx1QkFBbUMwQjtBQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkF4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsYUFBdUZuQixDQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUQwQjtBQUFBLFNBQTNCO0FBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFETjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFrRUgsQ0F4Rk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNOUDtBQUVPLE1BQU0wQixNQUFNLEdBQUcsQ0FBQztBQUFDcEM7QUFBRCxDQUFELEtBQWU7QUFDakMsUUFBSztBQUFDcUM7QUFBRCxNQUFlckMsT0FBTyxDQUFDRyxNQUE1QjtBQUNBLHNCQUNJO0FBQUssYUFBUyxFQUFDLGdCQUFmO0FBQUEsMkJBQ0kscUVBQUMsK0RBQUQ7QUFBQSxnQkFDRGtDLFlBQVksQ0FBQzdCLEdBQWIsQ0FBaUIsQ0FBQ0MsSUFBRCxFQUFPQyxDQUFQO0FBQUE7O0FBQUEsNEJBQ2hCLHFFQUFDLCtEQUFELENBQVUsSUFBVjtBQUFBLGlDQUNFO0FBQ0UscUJBQVMsRUFBQyxlQURaO0FBRUUsZUFBRyxxQkFBRTJCLFlBQVksQ0FBQzNCLENBQUQsQ0FBZCw2RUFBRSxnQkFBaUJQLE1BQW5CLG9GQUFFLHNCQUF5QndCLElBQTNCLDJEQUFFLHVCQUErQkMsR0FGdEM7QUFHRSxlQUFHLHNCQUFFUyxZQUFZLENBQUMzQixDQUFELENBQWQsOEVBQUUsaUJBQWlCUCxNQUFuQiwwREFBRSxzQkFBeUJMO0FBSGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixXQUFvQlksQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFEZ0I7QUFBQSxPQUFqQjtBQURDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFlSCxDQWpCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDREEsTUFBTTRCLFdBQVcsR0FBRyxNQUFNO0FBQy9CLHNCQUNFO0FBQUEsNEJBQ0U7QUFBUSwwQkFBaUIsSUFBekI7QUFBOEIsV0FBSyxFQUFDLEtBQXBDO0FBQTBDLGtCQUFZLE1BQXREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBSUU7QUFBUSwwQkFBaUIsSUFBekI7QUFBOEIsV0FBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLGVBT0U7QUFBUSwwQkFBaUIsSUFBekI7QUFBOEIsV0FBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVBGLGVBVUU7QUFBUSwwQkFBaUIsSUFBekI7QUFBOEIsV0FBSyxFQUFDLElBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVZGLGVBYUU7QUFBUSwwQkFBaUIsSUFBekI7QUFBOEIsV0FBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWJGLGVBZ0JFO0FBQVEsMEJBQWlCLElBQXpCO0FBQThCLFdBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFoQkYsZUFtQkU7QUFBUSwwQkFBaUIsSUFBekI7QUFBOEIsV0FBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW5CRixlQXNCRTtBQUFRLDBCQUFpQixJQUF6QjtBQUE4QixXQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdEJGLGVBeUJFO0FBQVEsMEJBQWlCLElBQXpCO0FBQThCLFdBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF6QkYsZUE0QkU7QUFBUSwwQkFBaUIsSUFBekI7QUFBOEIsV0FBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTVCRixlQStCRTtBQUFRLDBCQUFpQixJQUF6QjtBQUE4QixXQUFLLEVBQUMsSUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBL0JGLGVBa0NFO0FBQVEsMEJBQWlCLElBQXpCO0FBQThCLFVBQUksRUFBQyxhQUFuQztBQUFpRCxXQUFLLEVBQUMsS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbENGLGVBcUNFO0FBQVUsV0FBSyxFQUFDLGlCQUFoQjtBQUFBLDhCQUNFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUlFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKRixlQU9FO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRixlQVVFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFWRixlQWFFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFiRixlQWdCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaEJGLGVBbUJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuQkYsZUFzQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXRCRixlQXlCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBekJGLGVBNEJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE1QkYsZUErQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQS9CRixlQWtDRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbENGLGVBcUNFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFyQ0YsZUF3Q0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXhDRixlQTJDRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM0NGLGVBOENFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE5Q0YsZUFpREU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpERixlQW9ERTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcERGLGVBdURFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF2REYsZUEwREU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTFERixlQTZERTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBN0RGLGVBZ0VFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFoRUYsZUFtRUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5FRixlQXNFRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdEVGLGVBeUVFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6RUYsZUE0RUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTVFRixlQStFRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBL0VGLGVBa0ZFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFsRkYsZUFxRkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXJGRixlQXdGRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeEZGLGVBMkZFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEzRkYsZUE4RkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTlGRixlQWlHRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBakdGLGVBb0dFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFwR0YsZUF1R0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXZHRixlQTBHRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMUdGLGVBNkdFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE3R0YsZUFnSEU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhIRixlQW1IRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbkhGLGVBc0hFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF0SEYsZUF5SEU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXpIRixlQTRIRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNUhGLGVBK0hFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEvSEYsZUFrSUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWxJRixlQXFJRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcklGLGVBd0lFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF4SUYsZUEySUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTNJRixlQThJRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOUlGLGVBaUpFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFqSkYsZUFvSkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXBKRixlQXVKRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdkpGLGVBMEpFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkExSkYsZUE2SkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdKRixlQWdLRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaEtGLGVBbUtFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuS0YsZUFzS0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXRLRixlQXlLRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBektGLGVBNEtFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE1S0YsZUErS0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQS9LRixlQWtMRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbExGLGVBcUxFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFyTEYsZUF3TEU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXhMRixlQTJMRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM0xGLGVBOExFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE5TEYsZUFpTUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpNRixlQW9NRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcE1GLGVBdU1FO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF2TUYsZUEwTUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTFNRixlQTZNRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBN01GLGVBZ05FO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFoTkYsZUFtTkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5ORixlQXNORTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdE5GLGVBeU5FO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxHQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6TkYsZUE0TkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTVORixlQStORTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBL05GLGVBa09FO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFsT0YsZUFxT0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXJPRixlQXdPRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeE9GLGVBMk9FO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEzT0YsZUE4T0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTlPRixlQWlQRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBalBGLGVBb1BFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFwUEYsZUF1UEU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXZQRixlQTBQRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMVBGLGVBNlBFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE3UEYsZUFnUUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhRRixlQW1RRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBblFGLGVBc1FFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF0UUYsZUF5UUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXpRRixlQTRRRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNVFGLGVBK1FFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEvUUYsZUFrUkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWxSRixlQXFSRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBclJGLGVBd1JFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF4UkYsZUEyUkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTNSRixlQThSRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOVJGLGVBaVNFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFqU0YsZUFvU0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXBTRixlQXVTRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdlNGLGVBMFNFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkExU0YsZUE2U0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdTRixlQWdURTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaFRGLGVBbVRFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxJQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuVEYsZUFzVEU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXRURixlQXlURTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBelRGLGVBNFRFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE1VEYsZUErVEU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQS9URixlQWtVRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbFVGLGVBcVVFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFyVUYsZUF3VUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXhVRixlQTJVRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM1VGLGVBOFVFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE5VUYsZUFpVkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpWRixlQW9WRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcFZGLGVBdVZFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF2VkYsZUEwVkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTFWRixlQTZWRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBN1ZGLGVBZ1dFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFoV0YsZUFtV0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5XRixlQXNXRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdFdGLGVBeVdFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6V0YsZUE0V0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTVXRixlQStXRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBL1dGLGVBa1hFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFsWEYsZUFxWEU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXJYRixlQXdYRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeFhGLGVBMlhFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEzWEYsZUE4WEU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTlYRixlQWlZRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBallGLGVBb1lFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFwWUYsZUF1WUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXZZRixlQTBZRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMVlGLGVBNllFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE3WUYsZUFnWkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhaRixlQW1aRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBblpGLGVBc1pFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF0WkYsZUF5WkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXpaRixlQTRaRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNVpGLGVBK1pFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEvWkYsZUFrYUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWxhRixlQXFhRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcmFGLGVBd2FFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF4YUYsZUEyYUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTNhRixlQThhRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOWFGLGVBaWJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFqYkYsZUFvYkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXBiRixlQXViRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdmJGLGVBMGJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkExYkYsZUE2YkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdiRixlQWdjRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaGNGLGVBbWNFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuY0YsZUFzY0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXRjRixlQXljRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBemNGLGVBNGNFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE1Y0YsZUErY0U7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQS9jRixlQWtkRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbGRGLGVBcWRFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFyZEYsZUF3ZEU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXhkRixlQTJkRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM2RGLGVBOGRFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE5ZEYsZUFpZUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWplRixlQW9lRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcGVGLGVBdWVFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF2ZUYsZUEwZUU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTFlRixlQTZlRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBN2VGLGVBZ2ZFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFoZkYsZUFtZkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5mRixlQXNmRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdGZGLGVBeWZFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxJQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6ZkYsZUE0ZkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTVmRixlQStmRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBL2ZGLGVBa2dCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbGdCRixlQXFnQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXJnQkYsZUF3Z0JFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF4Z0JGLGVBMmdCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM2dCRixlQThnQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTlnQkYsZUFpaEJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFqaEJGLGVBb2hCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcGhCRixlQXVoQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXZoQkYsZUEwaEJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkExaEJGLGVBNmhCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBN2hCRixlQWdpQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhpQkYsZUFtaUJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuaUJGLGVBc2lCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdGlCRixlQXlpQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXppQkYsZUE0aUJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE1aUJGLGVBK2lCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBL2lCRixlQWtqQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWxqQkYsZUFxakJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFyakJGLGVBd2pCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeGpCRixlQTJqQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTNqQkYsZUE4akJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE5akJGLGVBaWtCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBamtCRixlQW9rQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXBrQkYsZUF1a0JFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF2a0JGLGVBMGtCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMWtCRixlQTZrQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdrQkYsZUFnbEJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFobEJGLGVBbWxCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbmxCRixlQXNsQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXRsQkYsZUF5bEJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6bEJGLGVBNGxCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNWxCRixlQStsQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQS9sQkYsZUFrbUJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFsbUJGLGVBcW1CRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcm1CRixlQXdtQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXhtQkYsZUEybUJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEzbUJGLGVBOG1CRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOW1CRixlQWluQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpuQkYsZUFvbkJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFwbkJGLGVBdW5CRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdm5CRixlQTBuQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLElBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTFuQkYsZUE2bkJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE3bkJGLGVBZ29CRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaG9CRixlQW1vQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5vQkYsZUFzb0JFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF0b0JGLGVBeW9CRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBem9CRixlQTRvQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTVvQkYsZUErb0JFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEvb0JGLGVBa3BCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbHBCRixlQXFwQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXJwQkYsZUF3cEJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF4cEJGLGVBMnBCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM3BCRixlQThwQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTlwQkYsZUFpcUJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFqcUJGLGVBb3FCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcHFCRixlQXVxQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXZxQkYsZUEwcUJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkExcUJGLGVBNnFCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBN3FCRixlQWdyQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhyQkYsZUFtckJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxVQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuckJGLGVBc3JCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsVUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdHJCRixlQXlyQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLFVBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXpyQkYsZUE0ckJFO0FBQVEsNEJBQWlCLElBQXpCO0FBQThCLGFBQUssRUFBQyxNQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE1ckJGLGVBK3JCRTtBQUFRLDRCQUFpQixJQUF6QjtBQUE4QixhQUFLLEVBQUMsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBL3JCRixlQWtzQkU7QUFBUSw0QkFBaUIsSUFBekI7QUFBOEIsYUFBSyxFQUFDLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWxzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXJDRjtBQUFBLGtCQURGO0FBOHVCRCxDQS91Qk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRU8sTUFBTUMsSUFBSSxHQUFHLE1BQU07QUFDeEIsUUFBTUMsTUFBTSxHQUFHQyw2REFBUyxFQUF4QjtBQUNBN0QseURBQVMsQ0FBQyxNQUFNO0FBQ2RDLG9FQUFNLEdBQUdDLElBQVQsQ0FBZUwsSUFBRCxJQUFVO0FBQ3RCaUUsWUFBTSxDQUFDQyxXQUFQLEdBQXFCbEUsSUFBSSxDQUFDbUUsWUFBMUI7QUFDQUYsWUFBTSxDQUFDRyxJQUFQLEdBQWNwRSxJQUFJLENBQUNvRSxJQUFuQjtBQUNELEtBSEQ7QUFJRCxHQUxRLEVBS04sRUFMTSxDQUFUO0FBTUEsTUFBSUMsV0FBVyxHQUFHO0FBQ2hCQyxRQUFJLEVBQUUsRUFEVTtBQUVoQkMsU0FBSyxFQUFFLEVBRlM7QUFHaEJDLFVBQU0sRUFBRSxFQUhRO0FBSWhCQyxlQUFXLEVBQUUsS0FKRztBQUtoQkMsV0FBTyxFQUFFO0FBTE8sR0FBbEI7QUFRQSxRQUFNO0FBQUEsT0FBQ0MsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEIxRSxzREFBUSxDQUFDbUUsV0FBRCxDQUF4Qzs7QUFDQSxRQUFNUSxZQUFZLEdBQUcsTUFBT0MsQ0FBUCxJQUFhO0FBQ2hDQSxLQUFDLENBQUNDLGNBQUY7QUFDQSxRQUFJQyxHQUFHLEdBQUcsRUFBVjtBQUNBQSxPQUFHLENBQUNDLFVBQUosR0FBaUJOLFFBQVEsQ0FBQ0wsSUFBMUI7QUFDQVUsT0FBRyxDQUFDRSxjQUFKLEdBQXFCUCxRQUFRLENBQUNILE1BQTlCO0FBQ0FRLE9BQUcsQ0FBQ0csT0FBSixHQUFjUixRQUFRLENBQUNKLEtBQXZCO0FBQ0FTLE9BQUcsQ0FBQ0ksYUFBSixHQUFvQlQsUUFBUSxDQUFDRixXQUE3QjtBQUNBTyxPQUFHLENBQUNLLEtBQUosR0FBWVYsUUFBUSxDQUFDRCxPQUFyQjtBQUNBTSxPQUFHLENBQUNNLFVBQUosR0FBaUJyQixNQUFNLENBQUNDLFdBQXhCO0FBQ0FjLE9BQUcsQ0FBQ08sWUFBSixHQUFtQixFQUFuQjtBQUNBUCxPQUFHLENBQUNRLFFBQUosR0FBZSxTQUFmO0FBQ0FSLE9BQUcsQ0FBQ1MsTUFBSixHQUFheEIsTUFBTSxDQUFDRyxJQUFwQjtBQUNBc0IscUVBQU8sQ0FBQ1YsR0FBRCxDQUFQO0FBQ0FqQixVQUFNLENBQUM0QixJQUFQLENBQVksV0FBWjtBQUNELEdBZEQ7O0FBZUEsUUFBTUMsWUFBWSxHQUFJZCxDQUFELElBQU87QUFDMUIsVUFBTTtBQUFFUixVQUFGO0FBQVF1QjtBQUFSLFFBQWtCZixDQUFDLENBQUNnQixNQUExQjtBQUNBbEIsZUFBVyxpQ0FBTUQsUUFBTjtBQUFnQixPQUFDTCxJQUFELEdBQVF1QjtBQUF4QixPQUFYLENBRjBCLENBRzFCO0FBQ0QsR0FKRDs7QUFNQSxzQkFDRTtBQUFLLGFBQVMsRUFBQyxXQUFmO0FBQUEsMkJBQ0U7QUFDRSxlQUFTLEVBQUMsWUFEWjtBQUVFLFFBQUUsRUFBQyxTQUZMO0FBR0UsY0FBUSxFQUFDLElBSFg7QUFJRSxVQUFJLEVBQUMsUUFKUDtBQUtFLHlCQUFnQixtQkFMbEI7QUFNRSxxQkFBWSxNQU5kO0FBQUEsNkJBUUU7QUFBSyxpQkFBUyxFQUFDLGNBQWY7QUFBOEIsWUFBSSxFQUFDLFVBQW5DO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLGVBQWY7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsY0FBZjtBQUFBLG9DQUNFO0FBQUksdUJBQVMsRUFBQyxhQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBRUU7QUFDRSxrQkFBSSxFQUFDLFFBRFA7QUFFRSx1QkFBUyxFQUFDLE9BRlo7QUFHRSw4QkFBYSxPQUhmO0FBSUUsNEJBQVcsT0FKYjtBQUFBLHFDQU1FO0FBQU0sK0JBQVksTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQVlFO0FBQUsscUJBQVMsRUFBQyxZQUFmO0FBQUEsbUNBQ0U7QUFBSyxnQkFBRSxFQUFDLFdBQVI7QUFBQSxxQ0FDRTtBQUFNLGtCQUFFLEVBQUMsZUFBVDtBQUF5QixvQkFBSSxFQUFDLFFBQTlCO0FBQUEsd0NBQ0U7QUFBSywyQkFBUyxFQUFDLDhCQUFmO0FBQUEsMENBQ0U7QUFBQSxxREFDTztBQUFNLCtCQUFTLEVBQUMsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLGVBSUU7QUFDRSx5QkFBSyxFQUFFRSwyREFEVDtBQUVFLHlCQUFLLEVBQUMsSUFGUjtBQUdFLDBCQUFNLEVBQUMsSUFIVDtBQUlFLDJCQUFPLEVBQUMsV0FKVjtBQUtFLHdCQUFJLEVBQUMsTUFMUDtBQU1FLDBCQUFNLEVBQUMsY0FOVDtBQU9FLCtCQUFXLEVBQUMsR0FQZDtBQVFFLGlDQUFhLEVBQUMsT0FSaEI7QUFTRSxrQ0FBYyxFQUFDLE9BVGpCO0FBVUUsNkJBQVMsRUFBQyx3Q0FWWjtBQUFBLDRDQVlFO0FBQU0sdUJBQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBWkYsZUFhRTtBQUFRLHdCQUFFLEVBQUMsSUFBWDtBQUFnQix3QkFBRSxFQUFDLEdBQW5CO0FBQXVCLHVCQUFDLEVBQUM7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSkYsZUFtQkU7QUFDRSx3QkFBSSxFQUFDLE1BRFA7QUFFRSx3QkFBSSxFQUFDLE1BRlA7QUFHRSw2QkFBUyxFQUFDLG1CQUhaO0FBSUUsMkJBQU8sRUFBQyxZQUpWO0FBS0UsNkJBQVMsRUFBQyxHQUxaO0FBTUUsK0JBQVcsRUFBQyxXQU5kO0FBT0UsNEJBQVEsRUFBQyxFQVBYO0FBUUUsNEJBQVEsRUFBR2pCLENBQUQsSUFBT2MsWUFBWSxDQUFDZCxDQUFELENBUi9CO0FBU0UseUJBQUssRUFBRUgsUUFBUSxDQUFDTDtBQVRsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFnQ0U7QUFBSywyQkFBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFoQ0YsZUFpQ0U7QUFBSywyQkFBUyxFQUFDLDhCQUFmO0FBQUEsMENBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREYsZUFFRTtBQUNFLHlCQUFLLEVBQUV5QiwyREFEVDtBQUVFLHlCQUFLLEVBQUMsSUFGUjtBQUdFLDBCQUFNLEVBQUMsSUFIVDtBQUlFLDJCQUFPLEVBQUMsV0FKVjtBQUtFLHdCQUFJLEVBQUMsTUFMUDtBQU1FLDBCQUFNLEVBQUMsY0FOVDtBQU9FLCtCQUFXLEVBQUMsR0FQZDtBQVFFLGlDQUFhLEVBQUMsT0FSaEI7QUFTRSxrQ0FBYyxFQUFDLE9BVGpCO0FBVUUsNkJBQVMsRUFBQyx3Q0FWWjtBQUFBLDRDQVlFO0FBQU0sdUJBQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBWkYsZUFhRTtBQUFVLDRCQUFNLEVBQUM7QUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRkYsZUFpQkU7QUFDRSx3QkFBSSxFQUFDLE9BRFA7QUFFRSx3QkFBSSxFQUFDLE9BRlA7QUFHRSw2QkFBUyxFQUFDLG1CQUhaO0FBSUUsK0JBQVcsRUFBQyxZQUpkO0FBS0UsNEJBQVEsRUFBQyxFQUxYO0FBTUUsNEJBQVEsRUFBR2pCLENBQUQsSUFBT2MsWUFBWSxDQUFDZCxDQUFELENBTi9CO0FBT0UseUJBQUssRUFBRUgsUUFBUSxDQUFDSjtBQVBsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBakNGLGVBNERFO0FBQUssMkJBQVMsRUFBQyw4QkFBZjtBQUFBLDBDQUNFO0FBQUEsNERBQ2M7QUFBTSwrQkFBUyxFQUFDLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQURkLEVBQ3FELEdBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERixlQUlFO0FBQUssNkJBQVMsRUFBQyxnQkFBZjtBQUFBLDRDQUNFO0FBQUssK0JBQVMsRUFBQyxVQUFmO0FBQUEsNkNBQ0U7QUFDRSw0QkFBSSxFQUFDLGFBRFA7QUFFRSxpQ0FBUyxFQUFDLDBCQUZaO0FBR0UsZ0NBQVEsRUFBQyxFQUhYO0FBSUUsMEJBQUUsRUFBQywyQkFKTDtBQUtFLGdDQUFRLEVBQUdPLENBQUQsSUFBT2MsWUFBWSxDQUFDZCxDQUFELENBTC9CO0FBTUUsNkJBQUssRUFBRUgsUUFBUSxDQUFDRixXQU5sQjtBQUFBLCtDQVFBLHFFQUFDLHdEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFSQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERixlQWFFO0FBQUssK0JBQVMsRUFBQyxVQUFmO0FBQUEsOENBQ0U7QUFDRSw2QkFBSyxFQUFFc0IsMkRBRFQ7QUFFRSw2QkFBSyxFQUFDLElBRlI7QUFHRSw4QkFBTSxFQUFDLElBSFQ7QUFJRSwrQkFBTyxFQUFDLFdBSlY7QUFLRSw0QkFBSSxFQUFDLE1BTFA7QUFNRSw4QkFBTSxFQUFDLGNBTlQ7QUFPRSxtQ0FBVyxFQUFDLEdBUGQ7QUFRRSxxQ0FBYSxFQUFDLE9BUmhCO0FBU0Usc0NBQWMsRUFBQyxPQVRqQjtBQVVFLGlDQUFTLEVBQUMsc0NBVlo7QUFBQSwrQ0FZRTtBQUFNLDJCQUFDLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FERixlQWVFO0FBQ0UsNEJBQUksRUFBQyxRQURQO0FBRUUsMEJBQUUsRUFBQyxzQkFGTDtBQUdFLDRCQUFJLEVBQUMsS0FIUDtBQUlFLGlDQUFTLEVBQUMsbUJBSlo7QUFLRSxtQ0FBVyxFQUFDLGFBTGQ7QUFNRSxnQ0FBUSxFQUFDLEVBTlg7QUFPRSxnQ0FBUSxFQUFHakIsQ0FBRCxJQUFPYyxZQUFZLENBQUNkLENBQUQsQ0FQL0I7QUFRRSw2QkFBSyxFQUFFSCxRQUFRLENBQUNIO0FBUmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBNURGLGVBeUdFO0FBQUssMkJBQVMsRUFBQyw2QkFBZjtBQUFBLDBDQUNFO0FBQU8sNkJBQVMsRUFBQyxNQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERixlQUVFO0FBQUssNkJBQVMsRUFBQyxPQUFmO0FBQUEsMkNBQ0U7QUFBQSw4Q0FDRTtBQUNFLDRCQUFJLEVBQUMsT0FEUDtBQUVFLDRCQUFJLEVBQUMsU0FGUDtBQUdFLGdDQUFRLEVBQUMsRUFIWDtBQUlFLGdDQUFRLEVBQUdNLENBQUQsSUFBT2MsWUFBWSxDQUFDZCxDQUFELENBSi9CO0FBS0UsNkJBQUssRUFBRUgsUUFBUSxDQUFDRDtBQUxsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQURGLGVBUUU7QUFBRyxpQ0FBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUZGLGVBY0U7QUFBSyw2QkFBUyxFQUFDLE9BQWY7QUFBQSwyQ0FDRTtBQUFBLDhDQUNFO0FBQ0UsNEJBQUksRUFBQyxPQURQO0FBRUUsNEJBQUksRUFBQyxTQUZQO0FBR0UsZ0NBQVEsRUFBR0ksQ0FBRCxJQUFPYyxZQUFZLENBQUNkLENBQUQsQ0FIL0I7QUFJRSw2QkFBSyxFQUFFSCxRQUFRLENBQUNEO0FBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBREYsZUFPRTtBQUFHLGlDQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXpHRixlQW1JRTtBQUFLLDJCQUFTLEVBQUMsa0JBQWY7QUFBQSx5Q0FDRTtBQUNFLDZCQUFTLEVBQUMsNkJBRFo7QUFFRSwyQkFBTyxFQUFHSSxDQUFELElBQU9ELFlBQVksQ0FBQ0MsQ0FBRCxDQUY5QjtBQUdFLG9DQUFhLE9BSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQW5JRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTZLRCxDQW5OTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ05QO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSWUsU0FBU2tCLFFBQVQsQ0FBa0I7QUFBQ3pFO0FBQUQsQ0FBbEIsRUFBNkI7QUFDMUMsUUFBTTtBQUFFMEU7QUFBRixNQUE0QjFFLE9BQU8sQ0FBQ0csTUFBMUM7QUFDQSxRQUFNO0FBQUEsT0FBQ3dFLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCakcsc0RBQVEsQ0FBQyxLQUFELENBQXhDOztBQUNBLFFBQU1rRyxnQkFBZ0IsR0FBRyxNQUFNO0FBQzdCRCxlQUFXLENBQUMsSUFBRCxDQUFYO0FBQ0QsR0FGRDs7QUFHRSxzQkFDSTtBQUFBLDRCQUNBLHFFQUFDLDhDQUFEO0FBQVEsYUFBTyxFQUFFNUU7QUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURBLGVBRUMscUVBQUMsOENBQUQ7QUFBUSxhQUFPLEVBQUVBO0FBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFGRCxlQUdBO0FBQVMsUUFBRSxFQUFDLGNBQVo7QUFBQSw2QkFDQTtBQUFLLGlCQUFTLEVBQUMsbUJBQWY7QUFBQSwrQkFDRTtBQUFLLG1CQUFTLEVBQUMsNEJBQWY7QUFBQSxpQ0FDRTtBQUFLLHFCQUFTLEVBQUMsUUFBZjtBQUFBLG9DQUNFO0FBQUssdUJBQVMsRUFBQyxxQkFBZjtBQUFBLHNDQUNFO0FBQUkseUJBQVMsRUFBQyxvQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQUlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBT0UscUVBQUMsd0RBQUQ7QUFBYSxxQkFBTyxFQUFFQTtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUhBLGVBa0JGO0FBQVMsZUFBUyxFQUFDLGNBQW5CO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLG1CQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLDRCQUFmO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLFFBQWY7QUFBQSxvQ0FDRTtBQUFLLHVCQUFTLEVBQUMsZUFBZjtBQUFBLHFDQUNFO0FBQUkseUJBQVMsRUFBQyxZQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUlFO0FBQUssdUJBQVMsRUFBQyw0QkFBZjtBQUFBLHFDQUNFO0FBQUsseUJBQVMsRUFBQyxRQUFmO0FBQUEsdUNBQ0U7QUFBRywyQkFBUyxFQUFDLFdBQWI7QUFBQSw0QkFDRzBFLHFCQUFxQixDQUFDSSxPQUF0QixDQUE4QixDQUE5QixFQUFpQ0EsT0FBakMsQ0FBeUMsQ0FBekMsRUFBNENSO0FBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFKRixlQVdFO0FBQUssdUJBQVMsRUFBQyxhQUFmO0FBQUEscUNBQ0UscUVBQUMsa0VBQUQ7QUFBa0IsdUJBQU8sRUFBRXRFO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVhGLGVBZUU7QUFBSyx1QkFBUyxFQUFDLDJCQUFmO0FBQUEscUNBQ0UscUVBQUMsZ0VBQUQ7QUFBaUIsdUJBQU8sRUFBRUE7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbEJFLGVBMkNGO0FBQVMsZUFBUyxFQUFDLGNBQW5CO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLG1CQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLDRCQUFmO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLFFBQWY7QUFBQSxvQ0FDRTtBQUFLLHVCQUFTLEVBQUMsZUFBZjtBQUFBLHFDQUNFO0FBQUkseUJBQVMsRUFBQyxZQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUlFLHFFQUFDLGtFQUFEO0FBQWtCLHFCQUFPLEVBQUVBO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBM0NFLGVBd0RGLHFFQUFDLHdEQUFEO0FBQ0UsWUFBTSxFQUFDLE9BRFQ7QUFFRSxVQUFJLEVBQUUyRSxRQUZSO0FBR0UsYUFBTyxFQUFFLE1BQU07QUFDYkMsbUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDRCxPQUxIO0FBQUEsNkJBT0U7QUFDRSxhQUFLLEVBQUU7QUFBRWpFLGdCQUFNLEVBQUUsT0FBVjtBQUFtQkMsaUJBQU8sRUFBRSxNQUE1QjtBQUFvQ0MsZUFBSyxFQUFFO0FBQTNDLFNBRFQ7QUFFRSxpQkFBUyxFQUFDLGdCQUZaO0FBQUEsZ0NBSUUscUVBQUMsb0VBQUQ7QUFDRSxpQkFBTyxFQUFFLE1BQU07QUFDYitELHVCQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0QsV0FISDtBQUlFLGVBQUssRUFBQyxTQUpSO0FBS0UsZUFBSyxFQUFFO0FBQ0w5RCxvQkFBUSxFQUFFLFVBREw7QUFFTEMsaUJBQUssRUFBRSxNQUZGO0FBR0xDLGVBQUcsRUFBRSxNQUhBO0FBSUwrRCxrQkFBTSxFQUFFLEdBSkg7QUFLTEMsaUJBQUssRUFBRTtBQUxGLFdBTFQ7QUFBQSxpQ0FhRSxxRUFBQyxpRUFBRDtBQUFlLGlCQUFLLEVBQUM7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSkYsZUFtQkUscUVBQUMsb0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXhERSxlQXFGRjtBQUNFLFVBQUksRUFBQyxRQURQO0FBRUUsZUFBUyxFQUFDLGtCQUZaO0FBR0Usb0JBQVcsTUFIYjtBQUlFLGFBQU8sRUFBRUgsZ0JBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFyRkUsZUE2RkYscUVBQUMsMkNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTdGRSxlQThGRixxRUFBQywrQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBOUZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURKO0FBa0dILEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEhEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFTyxNQUFNSSxTQUFTLEdBQUcsTUFBTTtBQUM3QixNQUFJbkMsV0FBVyxHQUFHO0FBQ2hCQyxRQUFJLEVBQUUsRUFEVTtBQUVoQkMsU0FBSyxFQUFFLEVBRlM7QUFHaEI5RCxTQUFLLEVBQUUsRUFIUztBQUloQmdHLFlBQVEsRUFBRSxFQUpNO0FBS2hCaEMsZUFBVyxFQUFFO0FBTEcsR0FBbEI7QUFPQXRFLHlEQUFTLENBQUMsTUFBTTtBQUNkQyxvRUFBTSxHQUFHQyxJQUFULENBQWVMLElBQUQsSUFBVTtBQUN0QmlFLFlBQU0sQ0FBQ0MsV0FBUCxHQUFxQmxFLElBQUksQ0FBQ21FLFlBQTFCO0FBQ0FGLFlBQU0sQ0FBQ0csSUFBUCxHQUFjcEUsSUFBSSxDQUFDb0UsSUFBbkI7QUFDRCxLQUhEO0FBSUQsR0FMUSxFQUtOLEVBTE0sQ0FBVDtBQU1BLFFBQU1MLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7QUFDQSxRQUFNO0FBQUEsT0FBQ2hFLElBQUQ7QUFBQSxPQUFPQztBQUFQLE1BQWtCQyxzREFBUSxDQUFDbUUsV0FBRCxDQUFoQzs7QUFDQSxRQUFNUSxZQUFZLEdBQUcsTUFBT0MsQ0FBUCxJQUFhO0FBQ2hDQSxLQUFDLENBQUNDLGNBQUY7QUFDQSxRQUFJQyxHQUFHLEdBQUcsRUFBVjtBQUNBQSxPQUFHLENBQUNDLFVBQUosR0FBaUJqRixJQUFJLENBQUNzRSxJQUF0QjtBQUNBVSxPQUFHLENBQUNFLGNBQUosR0FBcUJsRixJQUFJLENBQUNTLEtBQTFCO0FBQ0F1RSxPQUFHLENBQUNHLE9BQUosR0FBY25GLElBQUksQ0FBQ3VFLEtBQW5CO0FBQ0FTLE9BQUcsQ0FBQ0ksYUFBSixHQUFvQnBGLElBQUksQ0FBQ3lFLFdBQXpCO0FBQ0FPLE9BQUcsQ0FBQ00sVUFBSixHQUFpQnJCLE1BQU0sQ0FBQ0MsV0FBeEI7QUFDQWMsT0FBRyxDQUFDTyxZQUFKLEdBQW1CLEVBQW5CO0FBQ0FQLE9BQUcsQ0FBQ1EsUUFBSixHQUFlLFNBQWY7QUFDQVIsT0FBRyxDQUFDUyxNQUFKLEdBQWF4QixNQUFNLENBQUNHLElBQXBCO0FBQ0FzQixxRUFBTyxDQUFDVixHQUFELENBQVA7QUFDQWpCLFVBQU0sQ0FBQzRCLElBQVAsQ0FBWSxXQUFaO0FBQ0QsR0FiRDs7QUFjQSxRQUFNQyxZQUFZLEdBQUlkLENBQUQsSUFBTztBQUMxQixVQUFNO0FBQUVSLFVBQUY7QUFBUXVCO0FBQVIsUUFBa0JmLENBQUMsQ0FBQ2dCLE1BQTFCO0FBQ0E3RixXQUFPLGlDQUFNRCxJQUFOO0FBQVksT0FBQ3NFLElBQUQsR0FBUXVCO0FBQXBCLE9BQVAsQ0FGMEIsQ0FHMUI7QUFDRCxHQUpEOztBQUtBLHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRTtBQUFRLGVBQVMsRUFBQyxrQkFBbEI7QUFBQSw2QkFDRTtBQUFBLGdDQUNFO0FBQU0sZUFBSyxFQUFFO0FBQUVVLGlCQUFLLEVBQUU7QUFBVCxXQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFNRTtBQUFLLGVBQVMsRUFBQyxxQkFBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxtQkFBZjtBQUFBLCtCQUNFO0FBQU0sWUFBRSxFQUFDLE9BQVQ7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsWUFBZjtBQUFBLG9DQUNFO0FBQUEsK0RBQ3VCO0FBQU0seUJBQVMsRUFBQyxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFEdkIsRUFDOEQsR0FEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBS0U7QUFBSyx1QkFBUyxFQUFDLDZCQUFmO0FBQUEsd0JBQ0dHLDZEQUFXLENBQUMzRSxHQUFaLENBQWdCLENBQUNDLElBQUQsRUFBT0MsQ0FBUCxrQkFDZjtBQUFLLHlCQUFTLEVBQUMsaUJBQWY7QUFBQSx3Q0FDRTtBQUNFLHVCQUFLLEVBQUVELElBRFQ7QUFFRSwyQkFBUyxFQUFDLGNBRlo7QUFHRSxzQkFBSSxFQUFDLE9BSFA7QUFJRSxzQkFBSSxFQUFDO0FBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFERixlQU9FO0FBQUssMkJBQVMsRUFBQyxZQUFmO0FBQUEsMENBQ0U7QUFBSyw2QkFBUyxFQUFDLE1BQWY7QUFBQSwyQ0FDRTtBQUNFLHlCQUFHLEVBQUUyRSw4REFBWSxHQUFHM0UsSUFBZixHQUFzQixXQUQ3QjtBQUVFLHlCQUFHLEVBQUM7QUFGTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERixlQU9FO0FBQ0UsMkJBQU8sRUFBQyxNQURWO0FBRUUsNkJBQVMsRUFBQyxrQ0FGWjtBQUFBLDhCQUlHQTtBQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVBGO0FBQUEsaUJBQXNDQyxDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUREO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFpQ0U7QUFBSyxxQkFBUyxFQUFDLFlBQWY7QUFBQSxvQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUVFO0FBQ0Usa0JBQUksRUFBQyxNQURQO0FBRUUsdUJBQVMsRUFBQyxjQUZaO0FBR0UseUJBQVcsRUFBQyxNQUhkO0FBSUUsc0JBQVEsRUFBQyxFQUpYO0FBS0UsZ0JBQUUsRUFBQyxPQUxMO0FBTUUscUJBQU8sRUFBQyxpQkFOVjtBQU9FLGtCQUFJLEVBQUMsTUFQUDtBQVFFLHNCQUFRLEVBQUc2QyxDQUFELElBQU9jLFlBQVksQ0FBQ2QsQ0FBRCxDQVIvQjtBQVNFLG1CQUFLLEVBQUU5RSxJQUFJLENBQUNzRTtBQVRkO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWpDRixlQStDRTtBQUFLLHFCQUFTLEVBQUMsWUFBZjtBQUFBLG9DQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBRUU7QUFDRSxrQkFBSSxFQUFDLE9BRFA7QUFFRSx1QkFBUyxFQUFDLGNBRlo7QUFHRSxrQkFBSSxFQUFDLE9BSFA7QUFJRSx5QkFBVyxFQUFDLE9BSmQ7QUFLRSxxQkFBTyxFQUFDLHFFQUxWO0FBTUUsZ0JBQUUsRUFBQyxRQU5MO0FBT0Usc0JBQVEsRUFBR1EsQ0FBRCxJQUFPYyxZQUFZLENBQUNkLENBQUQsQ0FQL0I7QUFRRSxtQkFBSyxFQUFFOUUsSUFBSSxDQUFDdUU7QUFSZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEvQ0YsZUE0REU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNURGLGVBNkRFO0FBQUsscUJBQVMsRUFBQyxnQkFBZjtBQUFBLG9DQUNFO0FBQUssdUJBQVMsRUFBQyxVQUFmO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLFlBQWY7QUFBQSx1Q0FDRTtBQUNFLHNCQUFJLEVBQUMsYUFEUDtBQUVFLDJCQUFTLEVBQUMsMEJBRlo7QUFHRSwwQkFBUSxFQUFDLEVBSFg7QUFJRSxvQkFBRSxFQUFDLGNBSkw7QUFLRSwwQkFBUSxFQUFHTyxDQUFELElBQU9jLFlBQVksQ0FBQ2QsQ0FBRCxDQUwvQjtBQU1FLHVCQUFLLEVBQUU5RSxJQUFJLENBQUN5RSxXQU5kO0FBQUEsK0NBUUUscUVBQUMsd0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQWVFO0FBQUssdUJBQVMsRUFBQyxVQUFmO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLFlBQWY7QUFBQSx1Q0FDRTtBQUNFLHNCQUFJLEVBQUMsS0FEUDtBQUVFLDJCQUFTLEVBQUMsY0FGWjtBQUdFLHNCQUFJLEVBQUMsT0FIUDtBQUlFLDZCQUFXLEVBQUMsT0FKZDtBQUtFLDJCQUFTLEVBQUMsSUFMWjtBQU1FLDJCQUFTLEVBQUMsSUFOWjtBQU9FLDBCQUFRLEVBQUMsRUFQWDtBQVFFLG9CQUFFLEVBQUMsU0FSTDtBQVNFLHlCQUFPLEVBQUMsWUFUVjtBQVVFLDBCQUFRLEVBQUdLLENBQUQsSUFBT2MsWUFBWSxDQUFDZCxDQUFELENBVi9CO0FBV0UsdUJBQUssRUFBRTlFLElBQUksQ0FBQ1M7QUFYZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTdERixlQThGRTtBQUFLLHFCQUFTLEVBQUMsa0JBQWY7QUFBQSxtQ0FDRTtBQUNFLGtCQUFJLEVBQUMsUUFEUDtBQUVFLGtCQUFJLEVBQUMsUUFGUDtBQUdFLHVCQUFTLEVBQUMsNkJBSFo7QUFJRSxtQkFBSyxFQUFDLFFBSlI7QUFLRSxxQkFBTyxFQUFHcUUsQ0FBRCxJQUFPRCxZQUFZLENBQUNDLENBQUQ7QUFMOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBcUhELENBeEpNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ05QO0FBQ0EsTUFBTXRDLFdBQVcsR0FBR0MsbURBQU8sT0FBQywwSEFBRDtBQUFBO0FBQUEsd0NBQVEsOENBQVI7QUFBQSwrRkFBUSxvQkFBUjtBQUFBO0FBQUEsRUFBM0I7QUFDQTtBQUNBO0FBRU8sTUFBTW1FLGdCQUFnQixHQUFHLENBQUM7QUFBRXJGO0FBQUYsQ0FBRCxLQUFpQjtBQUMvQyxRQUFNbUMsS0FBSyxHQUFHO0FBQ1pWLGNBQVUsRUFBRTtBQUNWLFNBQUc7QUFDREMsYUFBSyxFQUFFO0FBRE4sT0FETztBQUlWLFdBQUs7QUFDSEEsYUFBSyxFQUFFO0FBREosT0FKSztBQU9WLFdBQUs7QUFDSEEsYUFBSyxFQUFFO0FBREosT0FQSztBQVVWLFlBQU07QUFDSkEsYUFBSyxFQUFFO0FBREg7QUFWSTtBQURBLEdBQWQ7QUFnQkEsUUFBTTtBQUFFNEQ7QUFBRixNQUF1QnRGLE9BQU8sQ0FBQ0csTUFBckM7QUFDQSxzQkFDRTtBQUFBLDJCQUNFO0FBQUssZUFBUyxFQUFDLEtBQWY7QUFBQSw2QkFDRSxxRUFBQyxXQUFEO0FBQ0UsYUFBSyxFQUFFLENBRFQ7QUFFRSxpQkFBUyxFQUFDLFdBRlo7QUFHRSxZQUFJLE1BSE47QUFJRSxXQUFHLE1BSkw7QUFLRSxjQUFNLEVBQUUsRUFMVjtBQU1FLGtCQUFVLEVBQUVnQyxLQUFLLENBQUNWLFVBTnBCO0FBQUEsa0JBUUc2RCxnQkFBZ0IsQ0FBQzlFLEdBQWpCLENBQXFCLENBQUNDLElBQUQsRUFBT0MsQ0FBUDtBQUFBOztBQUFBLDhCQUNwQjtBQUNFLHFCQUFTLEVBQUMsa0VBRFo7QUFBQSxtQ0FJRTtBQUFLLHVCQUFTLEVBQUMsZUFBZjtBQUFBLHNDQUNFO0FBQUcsb0JBQUksRUFBQyxJQUFSO0FBQUEsdUNBQ0U7QUFDRSxxQkFBRyx5QkFBRTRFLGdCQUFnQixDQUFDNUUsQ0FBRCxDQUFsQixpRkFBRSxvQkFBcUJQLE1BQXZCLG9GQUFFLHNCQUE2QndCLElBQS9CLDJEQUFFLHVCQUFtQ0MsR0FEMUM7QUFFRSwyQkFBUyxFQUFDLFdBRlo7QUFHRSxxQkFBRywwQkFBRTBELGdCQUFnQixDQUFDNUUsQ0FBRCxDQUFsQixrRkFBRSxxQkFBcUJQLE1BQXZCLDBEQUFFLHNCQUE2Qkw7QUFIcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFRRTtBQUFLLHlCQUFTLEVBQUMsc0JBQWY7QUFBQSx3Q0FDRTtBQUFJLDJCQUFTLEVBQUMsa0JBQWQ7QUFBQSx5Q0FDRTtBQUFHLHdCQUFJLEVBQUMsSUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFJRTtBQUFLLDJCQUFTLEVBQUMsK0NBQWY7QUFBQSx5Q0FDRTtBQUNFLHdCQUFJLEVBQUMsSUFEUDtBQUVFLDZCQUFTLEVBQUMsMEJBRlo7QUFHRSxtQ0FBWSxPQUhkO0FBSUUsbUNBQVksVUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVJGLGVBdUJFO0FBQUsseUJBQVMsRUFBQyw4Q0FBZjtBQUFBLHVDQUNFO0FBQU0sMkJBQVMsRUFBQyxhQUFoQjtBQUFBLG9EQUNHd0YsZ0JBQWdCLENBQUM1RSxDQUFELENBRG5CLGtGQUNHLHFCQUFxQlAsTUFEeEIsMERBQ0csc0JBQTZCTDtBQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkYsYUFFT1ksQ0FGUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURvQjtBQUFBLFNBQXJCO0FBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFtREQsQ0FyRU0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNMUDtBQUNBO0FBQ0EsTUFBTU8sV0FBVyxHQUFHQyxtREFBTyxPQUFDLDBIQUFEO0FBQUE7QUFBQSx3Q0FBUSw4Q0FBUjtBQUFBLDBGQUFRLG9CQUFSO0FBQUE7QUFBQSxFQUEzQjtBQUNBO0FBQ0E7QUFFTyxNQUFNcUUsV0FBVyxHQUFHLENBQUM7QUFBQ3ZGO0FBQUQsQ0FBRCxLQUFlO0FBQ3RDLFFBQU1tQyxLQUFLLEdBQUc7QUFDVlYsY0FBVSxFQUFFO0FBQ1YsU0FBRztBQUNEQyxhQUFLLEVBQUU7QUFETixPQURPO0FBSVYsV0FBSztBQUNIQSxhQUFLLEVBQUU7QUFESixPQUpLO0FBT1YsV0FBSztBQUNIQSxhQUFLLEVBQUU7QUFESixPQVBLO0FBVVYsWUFBTTtBQUNKQSxhQUFLLEVBQUU7QUFESDtBQVZJO0FBREYsR0FBZDtBQWdCQSxRQUFNO0FBQUM4RDtBQUFELE1BQWN4RixPQUFPLENBQUNHLE1BQTVCO0FBQ0Ysc0JBQ0U7QUFBQSwyQkFDRTtBQUFLLGVBQVMsRUFBQyxLQUFmO0FBQUEsNkJBQ0UscUVBQUMsV0FBRDtBQUNFLGFBQUssRUFBRSxDQURUO0FBRUUsaUJBQVMsRUFBQyxXQUZaO0FBR0UsWUFBSSxNQUhOO0FBSUUsV0FBRyxNQUpMO0FBS0UsY0FBTSxFQUFFLEVBTFY7QUFNRSxrQkFBVSxFQUFFZ0MsS0FBSyxDQUFDVixVQU5wQjtBQUFBLGtCQVFHK0QsV0FBVyxDQUFDaEYsR0FBWixDQUFnQixDQUFDQyxJQUFELEVBQU9DLENBQVAsa0JBQ2Y7QUFBSyxtQkFBUyxFQUFDLDhFQUFmO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLGVBQWY7QUFBQSxvQ0FDRTtBQUNFLHVCQUFTLEVBQUMsV0FEWjtBQUVFLGlCQUFHLEVBQUU4RSxXQUFXLENBQUM5RSxDQUFELENBQVgsQ0FBZVAsTUFBZixDQUFzQndCLElBQXRCLENBQTJCQyxHQUZsQztBQUdFLGlCQUFHLEVBQUU0RCxXQUFXLENBQUM5RSxDQUFELENBQVgsQ0FBZVAsTUFBZixDQUFzQkw7QUFIN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQU1FO0FBQUssdUJBQVMsRUFBQyx1QkFBZjtBQUFBLHFDQUNFO0FBQUkseUJBQVMsRUFBQyxZQUFkO0FBQUEsMEJBQTRCMEYsV0FBVyxDQUFDOUUsQ0FBRCxDQUFYLENBQWVQLE1BQWYsQ0FBc0JMO0FBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFdBQW1HWSxDQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUREO0FBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUE2QkQsQ0EvQ00sQzs7Ozs7Ozs7Ozs7O0FDTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFHQSxNQUFNN0IsTUFBTSxHQUFHLFlBQVk7QUFDekIsUUFBTTRHLEdBQUcsR0FBRyxNQUFNQyxLQUFLLENBQUNDLGtEQUFPLEdBQUdDLHVEQUFYLENBQXZCO0FBQ0EsUUFBTUMsSUFBSSxHQUFHLE1BQU1KLEdBQUcsQ0FBQ0ksSUFBSixFQUFuQjtBQUNBLFNBQU9BLElBQUksQ0FBQ0MsTUFBWjtBQUNELENBSkQ7O0FBTUEsTUFBTTNCLE9BQU8sR0FBRyxNQUFPNEIsSUFBUCxJQUFnQjtBQUMvQixRQUFNTCxLQUFLLENBQUNDLGtEQUFPLEdBQUcsT0FBWCxFQUFvQjtBQUM1QkssVUFBTSxFQUFFLE1BRG9CO0FBRTVCQyxXQUFPLEVBQUU7QUFDUCxzQkFBZ0I7QUFEVCxLQUZtQjtBQUs1QkYsUUFBSSxFQUFFRyxJQUFJLENBQUNDLFNBQUwsQ0FBZUosSUFBZjtBQUxzQixHQUFwQixDQUFMLENBTUZqSCxJQU5FLENBTUlnSCxNQUFELElBQVk7QUFDbEJBLFVBQU0sQ0FBQ0QsSUFBUCxHQUFjL0csSUFBZCxDQUFvQnNILElBQUQsSUFBVSxDQUM1QixDQUREO0FBRUQsR0FUSSxDQUFOO0FBVUEsQ0FYRDs7Ozs7Ozs7Ozs7Ozs7QUNUQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUFNL0csWUFBWSxHQUFDLGFBQW5CO0FBQ0EsTUFBTXNHLE9BQU8sR0FBQyxnQ0FBZDtBQUNBLE1BQU1QLFlBQVksR0FBQyxvREFBbkI7QUFDQSxNQUFNWixTQUFTLEdBQUMsNEJBQWhCO0FBQ0EsTUFBTVcsV0FBVyxHQUFDLENBQUUsV0FBRixFQUFjLFNBQWQsRUFBd0IsV0FBeEIsRUFBb0MsT0FBcEMsRUFBNEMsV0FBNUMsQ0FBbEI7QUFDQSxNQUFNa0IsWUFBWSxHQUFDLHVEQUFuQjtBQUNBLE1BQU1ULFlBQVksR0FBQyx3QkFBbkI7QUFDQSxNQUFPVSxZQUFZLEdBQUMsOERBQXBCO0FBQ0EsTUFBTUMsV0FBVyxHQUFDLHlCQUFsQjtBQUNBLE1BQU1DLGdCQUFnQixHQUFDLGtDQUF2QjtBQUNBLE1BQU1DLGlCQUFpQixHQUFDLHlEQUF4Qjs7Ozs7Ozs7Ozs7O0FDVkE7QUFDQTtBQUNBLG1CQUFtQixzQkFBc0I7QUFDekM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSwwQjs7Ozs7Ozs7Ozs7QUNsQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSx3Qzs7Ozs7Ozs7Ozs7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGFBQWEsdUJBQXVCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsK0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZkE7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBTUE7O0FBRUEsVUFBbUM7QUFDakM7QUFBRUMsUUFBRCxzQkFBQ0EsR0FBRCxJQUFDQTtBQUdKOztBQUFBLE1BQU1DLG9CQUFvQixHQUFHLGtCQUE3QixTQUE2QixDQUE3QjtBQWFBLE1BQU1DLE9BQU8sR0FBRyxRQUdkLENBQ0EsVUFEQSxXQUNBLENBREEsRUFFQSxlQUZBLGdCQUVBLENBRkEsRUFHQSxXQUhBLFlBR0EsQ0FIQSxFQUlBLFlBUEYsYUFPRSxDQUpBLENBSGMsQ0FBaEI7QUFVQSxNQUFNQyxtQkFBbUIsR0FBRyw2Q0FBNUIsU0FBNEIsQ0FBNUI7QUErQ0EsTUFBTTtBQUNKQyxhQUFXLEVBRFA7QUFFSkMsWUFBVSxFQUZOO0FBR0pDLFFBQU0sRUFIRjtBQUlKQyxNQUFJLEVBSkE7QUFLSkMsU0FBTyxFQUxIO0FBTUpDLHlCQUF1QixFQU5uQjtBQUFBLElBUUZDLDBMQUF5REMsYUFSN0QsbUIsQ0FTQTs7QUFDQSxNQUFNQyxRQUFRLEdBQUcsQ0FBQyxHQUFELG1CQUF1QixHQUF4QyxnQkFBaUIsQ0FBakI7QUFDQUMsaUJBQWlCLENBQWpCQSxLQUF1QixVQUFVQyxDQUFDLEdBQWxDRDtBQUNBRCxRQUFRLENBQVJBLEtBQWMsVUFBVUUsQ0FBQyxHQUF6QkY7O0FBRUEseUNBSXlDO0FBQ3ZDLE1BQUlHLEtBQUssS0FBS0MsTUFBTSxLQUFOQSxVQUFxQkEsTUFBTSxLQUF6QyxZQUFTLENBQVQsRUFBNkQ7QUFDM0Q7QUFDQSxVQUFNQyxlQUFlLEdBQXJCO0FBQ0EsVUFBTUMsWUFBWSxHQUFsQjs7QUFDQSxTQUFLLElBQUwsT0FBaUJDLEtBQUssR0FBR0YsZUFBZSxDQUFmQSxLQUF6QixLQUF5QkEsQ0FBekIsU0FBOEQ7QUFDNURDLGtCQUFZLENBQVpBLEtBQWtCRSxRQUFRLENBQUNELEtBQUssQ0FBaENELENBQWdDLENBQU4sQ0FBMUJBO0FBRUY7O0FBQUEsUUFBSUEsWUFBWSxDQUFoQixRQUF5QjtBQUN2QixZQUFNRyxhQUFhLEdBQUdDLElBQUksQ0FBSkEsSUFBUyxHQUFUQSxnQkFBdEI7QUFDQSxhQUFPO0FBQ0xDLGNBQU0sRUFBRVgsUUFBUSxDQUFSQSxPQUNMWSxDQUFELElBQU9BLENBQUMsSUFBSVgsaUJBQWlCLENBQWpCQSxDQUFpQixDQUFqQkEsR0FGVCxhQUNHRCxDQURIO0FBSUxhLFlBQUksRUFKTjtBQUFPLE9BQVA7QUFPRjs7QUFBQSxXQUFPO0FBQUVGLFlBQU0sRUFBUjtBQUFvQkUsVUFBSSxFQUEvQjtBQUFPLEtBQVA7QUFFRjs7QUFBQSxNQUNFLDZCQUNBVCxNQUFNLEtBRE4sVUFFQUEsTUFBTSxLQUhSLGNBSUU7QUFDQSxXQUFPO0FBQUVPLFlBQU0sRUFBUjtBQUE2QkUsVUFBSSxFQUF4QztBQUFPLEtBQVA7QUFHRjs7QUFBQSxRQUFNRixNQUFNLEdBQUcsQ0FDYixHQUFHLFNBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVFwSCxLQUFLLEdBQUc7QUFBaEI7QUFBQSxRQUNHdUgsQ0FBRCxJQUFPZCxRQUFRLENBQVJBLEtBQWVlLENBQUQsSUFBT0EsQ0FBQyxJQUF0QmYsTUFBZ0NBLFFBQVEsQ0FBQ0EsUUFBUSxDQUFSQSxTQVh0RCxDQVdxRCxDQURqRCxDQVRDLENBRFUsQ0FBZjtBQWVBLFNBQU87QUFBQTtBQUFVYSxRQUFJLEVBQXJCO0FBQU8sR0FBUDtBQW1CRjs7QUFBQSwwQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBMUI7QUFBMEIsQ0FBMUIsRUFRdUM7QUFDckMsbUJBQWlCO0FBQ2YsV0FBTztBQUFBO0FBQU9HLFlBQU0sRUFBYjtBQUEwQmIsV0FBSyxFQUF0QztBQUFPLEtBQVA7QUFHRjs7QUFBQSxRQUFNO0FBQUE7QUFBQTtBQUFBLE1BQW1CYyxTQUFTLGdCQUFsQyxLQUFrQyxDQUFsQztBQUNBLFFBQU1DLElBQUksR0FBR1AsTUFBTSxDQUFOQSxTQUFiO0FBRUEsU0FBTztBQUNMUixTQUFLLEVBQUUsVUFBVVUsSUFBSSxLQUFkLGdCQURGO0FBRUxHLFVBQU0sRUFBRUwsTUFBTSxDQUFOQSxJQUVKLFVBQ0csR0FBRWpCLE1BQU0sQ0FBQztBQUFBO0FBQUE7QUFBZ0JuRyxXQUFLLEVBQXRCO0FBQUMsS0FBRCxDQUE2QixJQUNwQ3NILElBQUksS0FBSkEsVUFBbUJ6SCxDQUFDLEdBQUcsQ0FDeEIsR0FBRXlILElBTERGLFNBRkgsSUFFR0EsQ0FGSDtBQVdMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBUSxPQUFHLEVBQUV6QixNQUFNLENBQUM7QUFBQTtBQUFBO0FBQWdCbkcsV0FBSyxFQUFFb0gsTUFBTSxDQWpCM0MsSUFpQjJDO0FBQTdCLEtBQUQ7QUFqQk4sR0FBUDtBQXFCRjs7QUFBQSxtQkFBZ0Q7QUFDOUMsTUFBSSxhQUFKLFVBQTJCO0FBQ3pCO0FBRUY7O0FBQUEsTUFBSSxhQUFKLFVBQTJCO0FBQ3pCLFdBQU9ILFFBQVEsSUFBZixFQUFlLENBQWY7QUFFRjs7QUFBQTtBQUdGOztBQUFBLHlDQUEyRDtBQUN6RCxRQUFNWSxJQUFJLEdBQUc5QixPQUFPLENBQVBBLElBQWIsWUFBYUEsQ0FBYjs7QUFDQSxZQUFVO0FBQ1IsV0FBTzhCLElBQUk7QUFBR2pKLFVBQUksRUFBUDtBQUFBLE9BQVgsV0FBVyxFQUFYO0FBRUY7O0FBQUEsUUFBTSxVQUNILHlEQUF3RGtKLHFDQUV2RCxlQUFjQyxZQUhsQixFQUFNLENBQU47QUFPRixDLENBQUE7QUFDQTs7O0FBQ0EsaURBR0U7QUFDQSxNQUFJQyxXQUFXLEtBQVhBLFVBQUosU0FBdUM7QUFDckMsUUFBSUMsT0FBTyxDQUFYLFVBQXNCO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBQSxhQUFPLENBQVBBO0FBSkYsV0FLTztBQUNMQSxhQUFPLENBQVBBLFNBQWlCLE1BQU07QUFDckJBLGVBQU8sQ0FBUEE7QUFERkE7QUFJSDtBQUNGO0FBRWM7O0FBQUEscUJBZ0JBO0FBQUEsTUFoQmU7QUFBQTtBQUFBO0FBRzVCQyxlQUFXLEdBSGlCO0FBSTVCQyxZQUFRLEdBSm9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFZNUJoQyxVQUFNLEdBWnNCO0FBYTVCNkIsZUFBVyxHQWJpQjtBQUFBO0FBQUEsTUFnQmY7QUFBQSxNQURWSSxHQUNVO0FBQ2IsTUFBSUMsSUFBeUIsR0FBN0I7QUFDQSxNQUFJeEIsTUFBZ0MsR0FBR0QsS0FBSyxrQkFBNUM7QUFDQSxNQUFJMEIsT0FBTyxHQUFYOztBQUNBLE1BQUksYUFBSixNQUF1QjtBQUNyQkEsV0FBTyxHQUFHQyxPQUFPLENBQUNGLElBQUksQ0FBdEJDLE9BQWlCLENBQWpCQSxDQURxQixDQUVyQjs7QUFDQSxXQUFPRCxJQUFJLENBQVgsU0FBVyxDQUFYO0FBSEYsU0FJTyxJQUFJLFlBQUosTUFBc0I7QUFDM0I7QUFDQSxRQUFJQSxJQUFJLENBQVIsUUFBaUJ4QixNQUFNLEdBQUd3QixJQUFJLENBQWJ4QixPQUZVLENBSTNCOztBQUNBLFdBQU93QixJQUFJLENBQVgsUUFBVyxDQUFYO0FBR0Y7O0FBQUEsTUFBSSxDQUFKLCtCQUFvQztBQUNsQ0wsZUFBVyxHQUFYQTtBQUdGOztBQUFBLFlBQTJDO0FBQ3pDLFFBQUksQ0FBSixLQUFVO0FBQ1IsWUFBTSxVQUNILDBIQUF5SDNDLElBQUksQ0FBSkEsVUFDeEg7QUFBQTtBQUFBO0FBRHdIQTtBQUN4SCxPQUR3SEEsQ0FENUgsRUFBTSxDQUFOO0FBTUY7O0FBQUEsUUFBSSxDQUFDVyxtQkFBbUIsQ0FBbkJBLFNBQUwsTUFBS0EsQ0FBTCxFQUEyQztBQUN6QyxZQUFNLFVBQ0gsbUJBQWtCNEIsR0FBSSw4Q0FBNkNmLE1BQU8sc0JBQXFCYixtQkFBbUIsQ0FBbkJBLHFCQURsRyxHQUFNLENBQU47QUFNRjs7QUFBQSxRQUFJLENBQUNGLG9CQUFvQixDQUFwQkEsU0FBTCxPQUFLQSxDQUFMLEVBQTZDO0FBQzNDLFlBQU0sVUFDSCxtQkFBa0I4QixHQUFJLCtDQUE4Q1ksT0FBUSxzQkFBcUIxQyxvQkFBb0IsQ0FBcEJBLHFCQURwRyxHQUFNLENBQU47QUFNRjs7QUFBQSxRQUFJcUMsUUFBUSxJQUFJSyxPQUFPLEtBQXZCLFFBQW9DO0FBQ2xDLFlBQU0sVUFDSCxtQkFBa0JaLEdBRHJCLGlGQUFNLENBQU47QUFJRjs7QUFBQSxpQkFBYTtBQUNYLFlBQU0sVUFDSCxtQkFBa0JBLEdBRHJCLGlHQUFNLENBQU47QUFJSDtBQUVEOztBQUFBLE1BQUlhLE1BQU0sR0FDUixjQUFjRCxPQUFPLEtBQVBBLFVBQXNCLG1CQUR0QyxXQUNFLENBREY7O0FBRUEsTUFBSVosR0FBRyxJQUFJQSxHQUFHLENBQUhBLFdBQVgsT0FBV0EsQ0FBWCxFQUFvQztBQUNsQztBQUNBTSxlQUFXLEdBQVhBO0FBQ0FPLFVBQU0sR0FBTkE7QUFHRjs7QUFBQSxRQUFNLDBCQUEwQixzQ0FBa0M7QUFDaEVDLGNBQVUsRUFEc0Q7QUFFaEVDLFlBQVEsRUFBRSxDQUZaO0FBQWtFLEdBQWxDLENBQWhDO0FBSUEsUUFBTUMsU0FBUyxHQUFHLFdBQWxCO0FBRUEsUUFBTUMsUUFBUSxHQUFHQyxNQUFNLENBQXZCLEtBQXVCLENBQXZCO0FBQ0EsUUFBTUMsU0FBUyxHQUFHRCxNQUFNLENBQXhCLE1BQXdCLENBQXhCO0FBQ0EsUUFBTUUsVUFBVSxHQUFHRixNQUFNLENBQXpCLE9BQXlCLENBQXpCO0FBRUEsUUFBTUcsNEJBQTRCLEdBQWxDO0FBQ0EsUUFBTUMsNEJBQTRCLEdBQ2hDTCxRQUFRLElBQVJBLGFBQXlCQSxRQUFRLEdBQVJBLFlBRDNCO0FBRUEsUUFBTU0sMkJBQTJCLEdBQy9CbkIsV0FBVyxLQUFYQSxVQUEwQixDQUQ1QjtBQUdBO0FBQ0E7QUFDQTtBQUNBLE1BQUlvQixRQUFxQztBQUN2Q25KLFlBQVEsRUFEK0I7QUFFdkNFLE9BQUcsRUFGb0M7QUFHdkNrSixRQUFJLEVBSG1DO0FBSXZDQyxVQUFNLEVBSmlDO0FBS3ZDcEosU0FBSyxFQUxrQztBQU92Q3FKLGFBQVMsRUFQOEI7QUFRdkN4SixXQUFPLEVBUmdDO0FBU3ZDeUosVUFBTSxFQVRpQztBQVV2Q0MsVUFBTSxFQVZpQztBQVl2Q0MsV0FBTyxFQVpnQztBQWF2QzFKLFNBQUssRUFia0M7QUFjdkNGLFVBQU0sRUFkaUM7QUFldkM2SixZQUFRLEVBZitCO0FBZ0J2Q0MsWUFBUSxFQWhCK0I7QUFpQnZDQyxhQUFTLEVBakI4QjtBQWtCdkNDLGFBQVMsRUFsQjhCO0FBQUE7QUFBQTtBQUFBLEtBdUJuQ1gsMkJBQTJCLEdBQzNCO0FBQ0VZLGtCQUFjLEVBRGhCO0FBRUVDLG1CQUFlLEVBQUcsUUFBT0MsV0FIQTtBQUMzQixHQUQyQixHQXZCakMsU0FBeUMsQ0FBekM7O0FBOEJBLE1BQ0UsbUNBQ0EscUJBREEsZUFFQXBELE1BQU0sS0FIUixRQUlFO0FBQ0E7QUFDQSxVQUFNcUQsUUFBUSxHQUFHbkIsU0FBUyxHQUExQjtBQUNBLFVBQU1vQixVQUFVLEdBQUdDLEtBQUssQ0FBTEEsUUFBSyxDQUFMQSxZQUE0QixHQUFFRixRQUFRLEdBQUcsR0FBNUQ7O0FBQ0EsUUFBSXJELE1BQU0sS0FBVixjQUE2QjtBQUMzQjtBQUNBd0Qsa0JBQVksR0FBRztBQUNiWCxlQUFPLEVBRE07QUFFYlksZ0JBQVEsRUFGSztBQUdickssZ0JBQVEsRUFISztBQUtic0osaUJBQVMsRUFMSTtBQU1iRSxjQUFNLEVBTlJZO0FBQWUsT0FBZkE7QUFRQUUsZ0JBQVUsR0FBRztBQUFFYixlQUFPLEVBQVQ7QUFBb0JILGlCQUFTLEVBQTdCO0FBQWJnQjtBQUFhLE9BQWJBO0FBVkYsV0FXTyxJQUFJMUQsTUFBTSxLQUFWLGFBQTRCO0FBQ2pDO0FBQ0F3RCxrQkFBWSxHQUFHO0FBQ2JYLGVBQU8sRUFETTtBQUViRSxnQkFBUSxFQUZLO0FBR2JVLGdCQUFRLEVBSEs7QUFJYnJLLGdCQUFRLEVBSks7QUFLYnNKLGlCQUFTLEVBTEk7QUFNYkUsY0FBTSxFQU5SWTtBQUFlLE9BQWZBO0FBUUFFLGdCQUFVLEdBQUc7QUFDWGhCLGlCQUFTLEVBREU7QUFFWEcsZUFBTyxFQUZJO0FBR1hFLGdCQUFRLEVBSFZXO0FBQWEsT0FBYkE7QUFLQUMsY0FBUSxHQUFJLGVBQWMzQixRQUFTLGFBQVlFLFNBQS9DeUI7QUFmSyxXQWdCQSxJQUFJM0QsTUFBTSxLQUFWLFNBQXdCO0FBQzdCO0FBQ0F3RCxrQkFBWSxHQUFHO0FBQ2JDLGdCQUFRLEVBREs7QUFFYmYsaUJBQVMsRUFGSTtBQUdiRyxlQUFPLEVBSE07QUFJYnpKLGdCQUFRLEVBSks7QUFLYkQsYUFBSyxFQUxRO0FBTWJGLGNBQU0sRUFOUnVLO0FBQWUsT0FBZkE7QUFTSDtBQTlDRCxTQThDTyxJQUNMLG1DQUNBLHFCQURBLGVBRUF4RCxNQUFNLEtBSEQsUUFJTDtBQUNBO0FBQ0F3RCxnQkFBWSxHQUFHO0FBQ2JYLGFBQU8sRUFETTtBQUViWSxjQUFRLEVBRks7QUFJYnJLLGNBQVEsRUFKSztBQUtiRSxTQUFHLEVBTFU7QUFNYmtKLFVBQUksRUFOUztBQU9iQyxZQUFNLEVBUE87QUFRYnBKLFdBQUssRUFSUTtBQVVicUosZUFBUyxFQVZJO0FBV2JFLFlBQU0sRUFYUlk7QUFBZSxLQUFmQTtBQU5LLFNBbUJBO0FBQ0w7QUFDQSxjQUEyQztBQUN6QyxZQUFNLFVBQ0gsbUJBQWtCekMsR0FEckIseUVBQU0sQ0FBTjtBQUlIO0FBRUQ7O0FBQUEsTUFBSTZDLGFBQWdDLEdBQUc7QUFDckM3QyxPQUFHLEVBRGtDO0FBR3JDSCxVQUFNLEVBSCtCO0FBSXJDYixTQUFLLEVBSlA7QUFBdUMsR0FBdkM7O0FBT0EsaUJBQWU7QUFDYjZELGlCQUFhLEdBQUdDLGdCQUFnQixDQUFDO0FBQUE7QUFBQTtBQUFBO0FBSS9CMUssV0FBSyxFQUowQjtBQUsvQjJLLGFBQU8sRUFMd0I7QUFBQTtBQUFqQ0Y7QUFBaUMsS0FBRCxDQUFoQ0E7QUFXRjs7QUFBQSxlQUFhO0FBQ1hKLGdCQUFZLEdBQVpBO0FBQ0FFLGNBQVUsR0FBVkE7QUFDQW5CLFlBQVEsR0FBUkE7QUFFRjs7QUFBQSxzQkFDRTtBQUFLLFNBQUssRUFBVjtBQUFBLEtBQ0dtQixVQUFVLGdCQUNUO0FBQUssU0FBSyxFQUFWO0FBQUEsS0FDR0MsUUFBUSxnQkFDUDtBQUNFLFNBQUssRUFBRTtBQUNMWixjQUFRLEVBREg7QUFFTEYsYUFBTyxFQUZGO0FBR0xELFlBQU0sRUFIRDtBQUlMRCxZQUFNLEVBSkQ7QUFLTHpKLGFBQU8sRUFOWDtBQUNTLEtBRFQ7QUFRRSxPQUFHLEVBUkw7QUFTRSxtQkFURjtBQVVFLFFBQUksRUFWTjtBQVdFLE9BQUcsRUFBRyw2QkFBNEIsK0JBWjdCO0FBQ1AsSUFETyxHQUZGLElBQ1QsQ0FEUyxHQURiLE1Bb0JHLDJCQUNDLDREQUNFLDREQUVNMkssZ0JBQWdCLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFJbkIxSyxTQUFLLEVBSmM7QUFLbkIySyxXQUFPLEVBTFk7QUFBQTtBQUZ2QjtBQUV1QixHQUFELENBRnRCO0FBV0UsT0FBRyxFQVhMO0FBWUUsWUFBUSxFQVpWO0FBYUUsU0FBSyxFQWJQO0FBY0UsU0FBSyxFQWRQO0FBZUUsYUFBUyxFQXJDakI7QUFzQk0sS0FERixDQXJCSixlQXlDRTtBQUdFLFlBQVEsRUFIVjtBQUlFLGFBQVMsRUFKWDtBQUtFLE9BQUcsRUFBRzFDLE9BQUQsSUFBYTtBQUNoQjJDLFlBQU0sQ0FBTkEsT0FBTSxDQUFOQTtBQUNBQyx1QkFBaUIsVUFBakJBLFdBQWlCLENBQWpCQTtBQVBKO0FBU0UsU0FBSyxFQWxEVDtBQXlDRSxLQXpDRixFQW9ERzFDLFFBQVE7QUFBQTtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBQyxNQUFELDRCQUNFO0FBQ0UsT0FBRyxFQUNELFlBQ0FzQyxhQUFhLENBRGIsTUFFQUEsYUFBYSxDQUZiLFNBR0FBLGFBQWEsQ0FMakI7QUFPRSxPQUFHLEVBUEw7QUFRRSxNQUFFLEVBUko7QUFTRSxRQUFJLEVBQUVBLGFBQWEsQ0FBYkEscUJBQW1DQSxhQUFhLENBQUM3QyxHQVR6RCxDQVVFO0FBVkY7QUFXRSxlQUFXLEVBQUU2QyxhQUFhLENBQUNoRCxNQVg3QixDQVlFO0FBWkY7QUFhRSxjQUFVLEVBQUVnRCxhQUFhLENBcEJ0QjtBQU9MLElBREYsQ0FOTyxHQXJEYixJQUNFLENBREY7QUFpRkYsQyxDQUFBOzs7QUFFQSwyQkFBMkM7QUFDekMsU0FBTzdDLEdBQUcsQ0FBSEEsQ0FBRyxDQUFIQSxXQUFpQkEsR0FBRyxDQUFIQSxNQUFqQkEsQ0FBaUJBLENBQWpCQSxHQUFQO0FBR0Y7O0FBQUEscUJBQXFCO0FBQUE7QUFBQTtBQUFBO0FBQXJCO0FBQXFCLENBQXJCLEVBS29DO0FBQ2xDO0FBQ0EsUUFBTWtELE1BQU0sR0FBRywyQkFBMkIsT0FBMUMsS0FBZSxDQUFmO0FBQ0EsTUFBSUMsWUFBWSxHQUFoQjs7QUFDQSxlQUFhO0FBQ1hELFVBQU0sQ0FBTkEsS0FBWSxPQUFaQTtBQUdGOztBQUFBLE1BQUlBLE1BQU0sQ0FBVixRQUFtQjtBQUNqQkMsZ0JBQVksR0FBRyxNQUFNRCxNQUFNLENBQU5BLEtBQXJCQyxHQUFxQkQsQ0FBckJDO0FBRUY7O0FBQUEsU0FBUSxHQUFFbk0sSUFBSyxHQUFFb00sWUFBWSxLQUFNLEdBQUVELFlBQXJDO0FBR0Y7O0FBQUEsc0JBQXNCO0FBQUE7QUFBQTtBQUF0QjtBQUFzQixDQUF0QixFQUE2RTtBQUMzRSxTQUFRLEdBQUVuTSxJQUFLLEdBQUVvTSxZQUFZLEtBQU0sWUFBV2hMLEtBQTlDO0FBR0Y7O0FBQUEsMEJBQTBCO0FBQUE7QUFBQTtBQUFBO0FBQTFCO0FBQTBCLENBQTFCLEVBS29DO0FBQ2xDO0FBQ0EsUUFBTThLLE1BQU0sR0FBRyxzQkFBc0IsT0FBdEIsT0FBb0MsUUFBUUgsT0FBTyxJQUFsRSxNQUFtRCxDQUFwQyxDQUFmO0FBQ0EsTUFBSUksWUFBWSxHQUFHRCxNQUFNLENBQU5BLFlBQW5CO0FBQ0EsU0FBUSxHQUFFbE0sSUFBSyxHQUFFbU0sWUFBYSxHQUFFQyxZQUFZLEtBQTVDO0FBR0Y7O0FBQUEsdUJBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQXZCO0FBQXVCLENBQXZCLEVBS29DO0FBQ2xDLFlBQTJDO0FBQ3pDLFVBQU1DLGFBQWEsR0FBbkIsR0FEeUMsQ0FHekM7O0FBQ0EsUUFBSSxDQUFKLEtBQVVBLGFBQWEsQ0FBYkE7QUFDVixRQUFJLENBQUosT0FBWUEsYUFBYSxDQUFiQTs7QUFFWixRQUFJQSxhQUFhLENBQWJBLFNBQUosR0FBOEI7QUFDNUIsWUFBTSxVQUNILG9DQUFtQ0EsYUFBYSxDQUFiQSxVQUVsQyxnR0FBK0Y1RixJQUFJLENBQUpBLFVBQy9GO0FBQUE7QUFBQTtBQUQrRkE7QUFDL0YsT0FEK0ZBLENBSG5HLEVBQU0sQ0FBTjtBQVNGOztBQUFBLFFBQUl1QyxHQUFHLENBQUhBLFdBQUosSUFBSUEsQ0FBSixFQUEwQjtBQUN4QixZQUFNLFVBQ0gsd0JBQXVCQSxHQUQxQiwwR0FBTSxDQUFOO0FBS0Y7O0FBQUEsUUFBSSxDQUFDQSxHQUFHLENBQUhBLFdBQUQsR0FBQ0EsQ0FBRCxJQUFKLGVBQTJDO0FBQ3pDOztBQUNBLFVBQUk7QUFDRnNELGlCQUFTLEdBQUcsUUFBWkEsR0FBWSxDQUFaQTtBQUNBLE9BRkYsQ0FFRSxZQUFZO0FBQ1poTixlQUFPLENBQVBBO0FBQ0EsY0FBTSxVQUNILHdCQUF1QjBKLEdBRDFCLGlJQUFNLENBQU47QUFLRjs7QUFBQSxVQUFJLENBQUN1RCxhQUFhLENBQWJBLFNBQXVCRCxTQUFTLENBQXJDLFFBQUtDLENBQUwsRUFBaUQ7QUFDL0MsY0FBTSxVQUNILHFCQUFvQnZELEdBQUksa0NBQWlDc0QsU0FBUyxDQUFDRSxRQUFwRSwrREFBQyxHQURILDhFQUFNLENBQU47QUFLSDtBQUNGO0FBRUQ7O0FBQUEsU0FBUSxHQUFFeE0sSUFBSyxRQUFPeU0sa0JBQWtCLEtBQU0sTUFBS3JMLEtBQU0sTUFBSzJLLE9BQU8sSUFBSSxFQUF6RTtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN21CTSxNQUFNVyxtQkFBbUIsR0FDN0IsK0JBQStCQyxJQUFJLENBQXBDLG1CQUFDLElBQ0QsY0FFa0I7QUFDaEIsTUFBSUMsS0FBSyxHQUFHQyxJQUFJLENBQWhCLEdBQVlBLEVBQVo7QUFDQSxTQUFPQyxVQUFVLENBQUMsWUFBWTtBQUM1QkMsTUFBRSxDQUFDO0FBQ0RDLGdCQUFVLEVBRFQ7QUFFREMsbUJBQWEsRUFBRSxZQUFZO0FBQ3pCLGVBQU8xRSxJQUFJLENBQUpBLE9BQVksTUFBTXNFLElBQUksQ0FBSkEsUUFBekIsS0FBbUIsQ0FBWnRFLENBQVA7QUFISndFO0FBQUcsS0FBRCxDQUFGQTtBQURlLEtBQWpCLENBQWlCLENBQWpCO0FBTkc7Ozs7QUFnQkEsTUFBTUcsa0JBQWtCLEdBQzVCLCtCQUErQlAsSUFBSSxDQUFwQyxrQkFBQyxJQUNELGNBQXlDO0FBQ3ZDLFNBQU9RLFlBQVksQ0FBbkIsRUFBbUIsQ0FBbkI7QUFIRzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25DUDs7QUFDQTs7QUFjQSxNQUFNQyx1QkFBdUIsR0FBRyxnQ0FBaEM7O0FBRU8seUJBQTRDO0FBQUE7QUFBNUM7QUFBNEMsQ0FBNUMsRUFHcUQ7QUFDMUQsUUFBTUMsVUFBbUIsR0FBR3RELFFBQVEsSUFBSSxDQUF4QztBQUVBLFFBQU11RCxTQUFTLEdBQUcsV0FBbEIsTUFBa0IsR0FBbEI7QUFDQSxRQUFNLHdCQUF3QixxQkFBOUIsS0FBOEIsQ0FBOUI7QUFFQSxRQUFNdEIsTUFBTSxHQUFHLHdCQUNadUIsRUFBRCxJQUFrQjtBQUNoQixRQUFJRCxTQUFTLENBQWIsU0FBdUI7QUFDckJBLGVBQVMsQ0FBVEE7QUFDQUEsZUFBUyxDQUFUQTtBQUdGOztBQUFBLFFBQUlELFVBQVUsSUFBZCxTQUEyQjs7QUFFM0IsUUFBSUUsRUFBRSxJQUFJQSxFQUFFLENBQVosU0FBc0I7QUFDcEJELGVBQVMsQ0FBVEEsVUFBb0JFLE9BQU8sS0FFeEJ4RCxTQUFELElBQWVBLFNBQVMsSUFBSXlELFVBQVUsQ0FGYixTQUVhLENBRmIsRUFHekI7QUFIRkg7QUFHRSxPQUh5QixDQUEzQkE7QUFNSDtBQWhCWSxLQWlCYix5QkFqQkYsT0FpQkUsQ0FqQmEsQ0FBZjtBQW9CQSx3QkFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFKLHlCQUE4QjtBQUM1QixVQUFJLENBQUosU0FBYztBQUNaLGNBQU1JLFlBQVksR0FBRyw4Q0FBb0IsTUFBTUQsVUFBVSxDQUF6RCxJQUF5RCxDQUFwQyxDQUFyQjtBQUNBLGVBQU8sTUFBTSw2Q0FBYixZQUFhLENBQWI7QUFFSDtBQUNGO0FBUEQsS0FPRyxDQVBILE9BT0csQ0FQSDtBQVNBLFNBQU8sU0FBUCxPQUFPLENBQVA7QUFHRjs7QUFBQSw2Q0FJYztBQUNaLFFBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUE2QkUsY0FBYyxDQUFqRCxPQUFpRCxDQUFqRDtBQUNBQyxVQUFRLENBQVJBO0FBRUFDLFVBQVEsQ0FBUkE7QUFDQSxTQUFPLHFCQUEyQjtBQUNoQ0QsWUFBUSxDQUFSQTtBQUNBQyxZQUFRLENBQVJBLG1CQUZnQyxDQUloQzs7QUFDQSxRQUFJRCxRQUFRLENBQVJBLFNBQUosR0FBeUI7QUFDdkJDLGNBQVEsQ0FBUkE7QUFDQUMsZUFBUyxDQUFUQTtBQUVIO0FBVEQ7QUFZRjs7QUFBQSxNQUFNQSxTQUFTLEdBQUcsSUFBbEIsR0FBa0IsRUFBbEI7O0FBQ0EsaUNBQXdFO0FBQ3RFLFFBQU1DLEVBQUUsR0FBR0MsT0FBTyxDQUFQQSxjQUFYO0FBQ0EsTUFBSUMsUUFBUSxHQUFHSCxTQUFTLENBQVRBLElBQWYsRUFBZUEsQ0FBZjs7QUFDQSxnQkFBYztBQUNaO0FBR0Y7O0FBQUEsUUFBTUYsUUFBUSxHQUFHLElBQWpCLEdBQWlCLEVBQWpCO0FBQ0EsUUFBTUMsUUFBUSxHQUFHLHlCQUEwQkssT0FBRCxJQUFhO0FBQ3JEQSxXQUFPLENBQVBBLFFBQWlCQyxLQUFELElBQVc7QUFDekIsWUFBTUMsUUFBUSxHQUFHUixRQUFRLENBQVJBLElBQWFPLEtBQUssQ0FBbkMsTUFBaUJQLENBQWpCO0FBQ0EsWUFBTTVELFNBQVMsR0FBR21FLEtBQUssQ0FBTEEsa0JBQXdCQSxLQUFLLENBQUxBLG9CQUExQzs7QUFDQSxVQUFJQyxRQUFRLElBQVosV0FBMkI7QUFDekJBLGdCQUFRLENBQVJBLFNBQVEsQ0FBUkE7QUFFSDtBQU5ERjtBQURlLEtBQWpCLE9BQWlCLENBQWpCO0FBVUFKLFdBQVMsQ0FBVEEsUUFFR0csUUFBUSxHQUFHO0FBQUE7QUFBQTtBQUZkSDtBQUVjLEdBRmRBO0FBUUE7QUFDRCxDOzs7Ozs7Ozs7OztBQzNHRCxpQkFBaUIsbUJBQU8sQ0FBQyxxRUFBcUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0E5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR08sZUFBZ0JPLGNBQWhCLEdBQ1A7QUFDRSxRQUFNQyxNQUFNLEdBQUdDLCtEQUFZLENBQUM7QUFDM0JDLFNBQUssRUFBQzdHLE9BQU8sQ0FBQzhHLEdBQVIsQ0FBWUMsbUJBRFM7QUFFMUJDLGVBQVcsRUFBQ2hILE9BQU8sQ0FBQzhHLEdBQVIsQ0FBWUc7QUFGRSxHQUFELENBQTNCO0FBSUEsUUFBTTVJLEdBQUcsR0FBQyxNQUFNc0ksTUFBTSxDQUFDTyxVQUFQLENBQWtCO0FBQUNDLGdCQUFZLEVBQUM7QUFBZCxHQUFsQixDQUFoQjtBQUNBeFAsU0FBTyxDQUFDQyxHQUFSLENBQVl5RyxHQUFaO0FBQ0EsU0FBTztBQUNMK0ksU0FBSyxFQUFDO0FBQ0pDLGNBQVEsRUFBQ2hKLEdBQUcsQ0FBQy9EO0FBRFQ7QUFERCxHQUFQO0FBS0Q7QUFFYyxTQUFTZ04sSUFBVCxDQUFjO0FBQUNEO0FBQUQsQ0FBZCxFQUEwQjtBQUN2QzFQLFNBQU8sQ0FBQzRQLElBQVIsQ0FBYUYsUUFBYjtBQUNBLHNCQUNFO0FBQUEsY0FDQUEsUUFBUSxDQUFDak8sR0FBVCxDQUFhLENBQUNSLE9BQUQsRUFBUzRPLEtBQVQsa0JBQ1gscUVBQUMsNkZBQUQ7QUFBc0IsYUFBTyxFQUFFNU87QUFBL0IsT0FBZTRPLEtBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBUUQsQzs7Ozs7Ozs7Ozs7QUNoQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNYQSw4Qzs7Ozs7Ozs7Ozs7QUNBQSxxRDs7Ozs7Ozs7Ozs7QUNBQSx5RDs7Ozs7Ozs7Ozs7QUNBQSxzRDs7Ozs7Ozs7Ozs7QUNBQSx5RDs7Ozs7Ozs7Ozs7QUNBQSxxRDs7Ozs7Ozs7Ozs7QUNBQSwrQzs7Ozs7Ozs7Ozs7QUNBQSwrRDs7Ozs7Ozs7Ozs7QUNBQSx3RDs7Ozs7Ozs7Ozs7QUNBQSx5RDs7Ozs7Ozs7Ozs7QUNBQSx3RDs7Ozs7Ozs7Ozs7QUNBQSwwRDs7Ozs7Ozs7Ozs7QUNBQSwyRDs7Ozs7Ozs7Ozs7QUNBQSxvRDs7Ozs7Ozs7Ozs7QUNBQSxxRDs7Ozs7Ozs7Ozs7QUNBQSx1Qzs7Ozs7Ozs7Ozs7QUNBQSx5Qzs7Ozs7Ozs7Ozs7QUNBQSxzQzs7Ozs7Ozs7Ozs7QUNBQSx3Qzs7Ozs7Ozs7Ozs7QUNBQSxrQzs7Ozs7Ozs7Ozs7QUNBQSxxRDs7Ozs7Ozs7Ozs7QUNBQSwrQzs7Ozs7Ozs7Ozs7QUNBQSxrRCIsImZpbGUiOiJwYWdlcy9pbmRleC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0gcmVxdWlyZSgnLi4vc3NyLW1vZHVsZS1jYWNoZS5qcycpO1xuXG4gXHQvLyBvYmplY3QgdG8gc3RvcmUgbG9hZGVkIGNodW5rc1xuIFx0Ly8gXCIwXCIgbWVhbnMgXCJhbHJlYWR5IGxvYWRlZFwiXG4gXHR2YXIgaW5zdGFsbGVkQ2h1bmtzID0ge1xuIFx0XHRcInBhZ2VzL2luZGV4XCI6IDBcbiBcdH07XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdHZhciB0aHJldyA9IHRydWU7XG4gXHRcdHRyeSB7XG4gXHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG4gXHRcdFx0dGhyZXcgPSBmYWxzZTtcbiBcdFx0fSBmaW5hbGx5IHtcbiBcdFx0XHRpZih0aHJldykgZGVsZXRlIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHR9XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuIFx0Ly8gdW5jYXVnaHQgZXJyb3IgaGFuZGxlciBmb3Igd2VicGFjayBydW50aW1lXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm9lID0gZnVuY3Rpb24oZXJyKSB7XG4gXHRcdHByb2Nlc3MubmV4dFRpY2soZnVuY3Rpb24oKSB7XG4gXHRcdFx0dGhyb3cgZXJyOyAvLyBjYXRjaCB0aGlzIGVycm9yIGJ5IHVzaW5nIGltcG9ydCgpLmNhdGNoKClcbiBcdFx0fSk7XG4gXHR9O1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3BhZ2VzL2luZGV4LmpzXCIpO1xuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvdG8tYmFzZS02NC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvc2VydmVyL2ltYWdlLWNvbmZpZy5qc1wiKTsiLCJpbXBvcnQgUmVhY3Qse3VzZVN0YXRlLHVzZUVmZmVjdH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBGYWNlYm9va0ljb24gZnJvbSBcIkBtYXRlcmlhbC11aS9pY29ucy9GYWNlYm9va1wiO1xyXG5pbXBvcnQgSW5zdGFncmFtSWNvbiBmcm9tIFwiQG1hdGVyaWFsLXVpL2ljb25zL0luc3RhZ3JhbVwiO1xyXG5pbXBvcnQgTGlua2VkSW5JY29uIGZyb20gXCJAbWF0ZXJpYWwtdWkvaWNvbnMvTGlua2VkSW5cIjtcclxuaW1wb3J0IE1haWxPdXRsaW5lSWNvbiBmcm9tIFwiQG1hdGVyaWFsLXVpL2ljb25zL01haWxPdXRsaW5lXCI7XHJcbmltcG9ydCBQaG9uZUljb24gZnJvbSBcIkBtYXRlcmlhbC11aS9pY29ucy9QaG9uZVwiO1xyXG5pbXBvcnQgTG9jYXRpb25Pbkljb24gZnJvbSBcIkBtYXRlcmlhbC11aS9pY29ucy9Mb2NhdGlvbk9uXCI7XHJcbmltcG9ydCB7IFNUQVRJQ19QSE9ORSB9IGZyb20gJy4uLy4uL2NvbmZpZy9zZXJ2ZXJLZXknO1xyXG5pbXBvcnQgeyBnZXRBcGkgfSBmcm9tICcuLi8uLi9jb25maWcvQ3VzdG9tQXBpJztcclxuXHJcblxyXG5leHBvcnQgY29uc3QgRm9vdGVyID0gKCkgPT4ge1xyXG4gXHJcbiAgICBjb25zdCBbZGF0YSwgc2V0RGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgIGdldEFwaSgpLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuICAgICAgICBzZXREYXRhKGRhdGEpO1xyXG4gICAgICB9KTtcclxuICAgIH0sIFtdKTtcclxuICAgIGNvbnN0IHBob25lX25vPWRhdGE/LnBob25lIDtcclxuICAgIGNvbnN0IHdoYXRzYXBwX25vPWRhdGE/LndwX2xpbmtzO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgIDxmb290ZXIgaWQ9XCJmb290ZXJ0b3BcIiBjbGFzc05hbWU9XCJmb290ZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1zZWN0aW9uXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlNvY2lhbEJ1dHRvblwiIGlkPVwiU29jYWlsU2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8dWw+XHJcbiAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtwaG9uZV9ubyB8fCBTVEFUSUNfUEhPTkV9XHJcbiAgICAgICAgICAgICAgICAgIGhyZWY9e1widGVsOlwiK2Ake3Bob25lX25vfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPVwiYXNzZXN0L2ltYWdlcy9waG9uZS5wbmdcIiBhbHQ9XCJwaG9uZUltZ1wiLz5cclxuICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cIndoYXRzYXBfdXJsXCIgaHJlZj17YCR7d2hhdHNhcHBfbm99YCtcIiFJIHdhbnQgdG8ga25vdyBhYm91dCBQcm9qZWN0X25hbWVcIn0+XHJcbiAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPVwiYXNzZXN0L2ltYWdlcy93aGF0c2FwcC5wbmdcIiBhbHQ9XCJ3aGF0c2FwcEltZ1wiLz5cclxuICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBhbGlnbi1pdGVtcy10b3BcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbGctNCBjb2wtMTIgbXQtc20tMCBwdC0yIHB0LXNtLTBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpdGxlLWhlYWRpbmdcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWEgY29udGFjdC1kZXRhaWwgYWxpZ24taXRlbXMtY2VudGVyIG10LTNcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpY29uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPE1haWxPdXRsaW5lSWNvbiBjbGFzc05hbWU9XCJmZWEgaWNvbi1tLW1kIHRleHQtbGlnaHQgbXItM1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhLWJvZHkgY29udGVudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0aXRsZSBmb250LXdlaWdodC1ib2xkIG1iLTBcIj5FbWFpbDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIi8jIFwiIGlkPVwicGVwbGVtYWlsXCIgY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBpbmZvQGhvbWVzZnkuaW5cclxuICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhIGNvbnRhY3QtZGV0YWlsIGFsaWduLWl0ZW1zLWNlbnRlciBtdC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaWNvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxQaG9uZUljb24gY2xhc3NOYW1lPVwiZmVhIGljb24tbS1tZCB0ZXh0LWxpZ2h0IG1yLTNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYS1ib2R5IGNvbnRlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGl0bGUgZm9udC13ZWlnaHQtYm9sZCBtYi0wXCI+UGhvbmU8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwidGVsOjAyMjQwMzc1NzMwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBidG4tY2FsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInBlcGxwaG9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgMDIyNDAzNzU3MzBcclxuICAgICAgICAgICAgICAgICAgICA8L2E+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYSBjb250YWN0LWRldGFpbCBhbGlnbi1pdGVtcy1jZW50ZXIgbXQtM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImljb25cIj5cclxuICAgICAgICAgICAgICAgICAgICA8TG9jYXRpb25Pbkljb24gY2xhc3NOYW1lPVwiZmVhIGljb24tbS1tZCB0ZXh0LWxpZ2h0IG1yLTNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYS1ib2R5IGNvbnRlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGl0bGUgZm9udC13ZWlnaHQtYm9sZCBtYi0wXCI+TG9jYXRpb248L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgMjQsIE15d29ya2FyZWEsIEJlbmFrYSBDb21wbGV4LCAybmQgQ3Jvc3MsIFNpcnVyIFBhcmtcclxuICAgICAgICAgICAgICAgICAgICAgIFJvYWQsIFNoZXNoYWRyaXB1cmFtLCBCYW5nYWxvcmUtIDU2MDAyMFxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LXVuc3R5bGVkIHNvY2lhbC1pY29uIG1iLTAgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwibGlzdC1pbmxpbmUtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiaHR0cHM6Ly93d3cuZmFjZWJvb2suY29tL2hvbWVzZnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX25ld1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8RmFjZWJvb2tJY29uIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwibGlzdC1pbmxpbmUtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiaHR0cHM6Ly93d3cuaW5zdGFncmFtLmNvbS9ob21lc2Z5aW5kaWEvP2lnc2hpZD0xaHVhODltOXB5MHVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9uZXdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEluc3RhZ3JhbUljb24gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJsaXN0LWlubGluZS1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgIGhyZWY9XCJodHRwczovL3d3dy5saW5rZWRpbi5jb20vY29tcGFueS8zMzc0NzA2L1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfbmV3XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxMaW5rZWRJbkljb24gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbGctMyBjb2wtbWQtNCBjb2wtMTIgbXQtNCBtdC1zbS0wIHB0LTIgcHQtc20tMFwiPlxyXG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxpZ2h0IGZvb3Rlci1oZWFkXCI+UmVhZHkgSG9tZXM8L2g0PlxyXG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LXVuc3R5bGVkIGZvb3Rlci1saXN0IG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICBocmVmPVwiaHR0cHM6Ly9zb3V0aC1iYW5nYWxvcmUucHJlc3RpZ2UtcmVhbHR5LmluL1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1mb290XCJcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfbmV3XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cIm1kaSBtZGktY2hldnJvbi1yaWdodCBtci0xXCI+PC9pPiBQcmVzdGlnZSBzb25nXHJcbiAgICAgICAgICAgICAgICAgICAgb2YgdGhlIHNvdXRoXHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vcm95YWxlLWdhcmRlbnMucHJlc3RpZ2UtcmVhbHR5LmluL1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1mb290XCJcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfbmV3XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cIm1kaSBtZGktY2hldnJvbi1yaWdodCBtci0xXCI+PC9pPiBQcmVzdGlnZVxyXG4gICAgICAgICAgICAgICAgICAgIFJveWFsZSBHYXJkZW5zXHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vd3d3LnByZXN0aWdlLXJlYWx0eS5pbi9wcmVzdGlnZS1hdWd1c3RhL1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1mb290XCJcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfbmV3XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cIm1kaSBtZGktY2hldnJvbi1yaWdodCBtci0xXCI+PC9pPiBQcmVzdGlnZVxyXG4gICAgICAgICAgICAgICAgICAgIEF1Z3VzdGEgR29sZiBWaWxsYWdlXHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vd3d3LnByZXN0aWdlLXJlYWx0eS5pbi9wcmVzdGlnZS1sYWtlL1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1mb290XCJcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfbmV3XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cIm1kaSBtZGktY2hldnJvbi1yaWdodCBtci0xXCI+PC9pPiBQcmVzdGlnZSBMYWtlXHJcbiAgICAgICAgICAgICAgICAgICAgUmlkZ2VcclxuICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbGctMyBjb2wtbWQtNCBjb2wtMTIgbXQtNCBtdC1zbS0wIHB0LTIgcHQtc20tMFwiPlxyXG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxpZ2h0IGZvb3Rlci1oZWFkXCI+SG9tZXMgT25nb2luZzwvaDQ+XHJcbiAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtdW5zdHlsZWQgZm9vdGVyLWxpc3QgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9XCJodHRwczovL3d3dy5wcmVzdGlnZS1yZWFsdHkuaW4vZmluc2J1cnktcGFyay9cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZm9vdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX25ld1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJtZGkgbWRpLWNoZXZyb24tcmlnaHQgbXItMVwiPjwvaT4gUHJlc3RpZ2VcclxuICAgICAgICAgICAgICAgICAgICBGaW5zYnVycnlcclxuICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICBocmVmPVwiaHR0cHM6Ly9qaW5kYWwtY2l0eS5wcmVzdGlnZS1yZWFsdHkuaW4vXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWZvb3RcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9uZXdcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwibWRpIG1kaS1jaGV2cm9uLXJpZ2h0IG1yLTFcIj48L2k+IFByZXN0aWdlXHJcbiAgICAgICAgICAgICAgICAgICAgSmluZGFsIENpdHlcclxuICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbGctMiBjb2wtbWQtNCBjb2wtMTIgbXQtNCBtdC1zbS0wIHB0LTIgcHQtc20tMFwiPlxyXG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxpZ2h0IGZvb3Rlci1oZWFkXCI+VXNlZnVsIExpbmtzPC9oND5cclxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibGlzdC11bnN0eWxlZCBmb290ZXItbGlzdCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vd3d3LmhvbWVzZnkuaW4vYWJvdXQtdXMuaHRtbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1mb290XCJcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfbmV3XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cIm1kaSBtZGktY2hldnJvbi1yaWdodCBtci0xXCI+PC9pPiBBYm91dCB1c1xyXG4gICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9XCJodHRwczovL3d3dy5ob21lc2Z5LmluL3JlcmEuaHRtbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1mb290XCJcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfbmV3XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cIm1kaSBtZGktY2hldnJvbi1yaWdodCBtci0xXCI+PC9pPiBBYm91dCBSZXJhXHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vd3d3LmhvbWVzZnkuaW4vcHJpdmFjeS5odG1sXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWZvb3RcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9uZXdcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwibWRpIG1kaS1jaGV2cm9uLXJpZ2h0IG1yLTFcIj48L2k+IFByaXZhY3lcclxuICAgICAgICAgICAgICAgICAgICBQb2xpY3lcclxuICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICBocmVmPVwiaHR0cHM6Ly93d3cuaG9tZXNmeS5pbi90ZXJtcy5odG1sXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWZvb3RcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9uZXdcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwibWRpIG1kaS1jaGV2cm9uLXJpZ2h0IG1yLTFcIj48L2k+IFRlcm1zICZcclxuICAgICAgICAgICAgICAgICAgICBDb25kaXRpb25zXHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9mb290ZXI+XHJcbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiZm9vdGVyIGZvb3Rlci1iYXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1zZWN0aW9uIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc20tMTJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20tY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIERpc2NsYWltZXI6VGhlIGNvbnRlbnQgaXMgZm9yIGluZm9ybWF0aW9uIHB1cnBvc2VzIG9ubHkgYW5kXHJcbiAgICAgICAgICAgICAgICAgIGRvZXMgbm90IGNvbnN0aXR1dGUgYW4gb2ZmZXIgdG8gYXZhaWwgb2YgYW55IHNlcnZpY2UuIFByaWNlc1xyXG4gICAgICAgICAgICAgICAgICBtZW50aW9uZWQgYXJlIHN1YmplY3QgdG8gY2hhbmdlIHdpdGhvdXQgbm90aWNlIGFuZCBwcm9wZXJ0aWVzXHJcbiAgICAgICAgICAgICAgICAgIG1lbnRpb25lZCBhcmUgc3ViamVjdCB0byBhdmFpbGFiaWxpdHkuIEltYWdlcyBmb3JcclxuICAgICAgICAgICAgICAgICAgcmVwcmVzZW50YXRpb24gcHVycG9zZSBvbmx5LiBUaGlzIGlzIG5vdCB0aGUgb2ZmaWNpYWwgd2Vic2l0ZS5cclxuICAgICAgICAgICAgICAgICAgV2Vic2l0ZSBtYWludGFpbmVkIGJ5IG91ciBvbmxpbmUgbWFya2V0aW5nIGFnZW5jeSBwYWN0XHJcbiAgICAgICAgICAgICAgICAgIHBhcnRuZXJzLiBXZSBtYXkgc2hhcmUgZGF0YSB3aXRoIHJlcmEgcmVnaXN0ZXJlZFxyXG4gICAgICAgICAgICAgICAgICBicm9rZXJzL2NvbXBhbmllcyBmb3IgZnVydGhlciBwcm9jZXNzaW5nLiBXZSBtYXkgYWxzbyBzZW5kXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZXMgdG8gdGhlIG1vYmlsZSBudW1iZXIvZW1haWwgaWQgcmVnaXN0ZXJlZCB3aXRoIHVzLiBZb3VcclxuICAgICAgICAgICAgICAgICAgbWF5IHVuc3Vic2NyaWJlIGFueXRpbWUgYnkgd3JpdGluZyB0byB1cyBhdFxyXG4gICAgICAgICAgICAgICAgICB1bnN1YnNjcmliZUBwYWN0cGFydG5lcnMuaW4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9mb290ZXI+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApXHJcbn1cclxuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEFwcEJhciBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvQXBwQmFyXCI7XHJcbmltcG9ydCBUb29sYmFyIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9Ub29sYmFyXCI7XHJcbmltcG9ydCBUeXBvZ3JhcGh5IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9UeXBvZ3JhcGh5XCI7XHJcbmltcG9ydCBJY29uQnV0dG9uIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9JY29uQnV0dG9uXCI7XHJcbmltcG9ydCBNZW51SWNvbiBmcm9tIFwiQG1hdGVyaWFsLXVpL2ljb25zL01lbnVcIjtcclxuaW1wb3J0IHsgQ3NzQmFzZWxpbmUsIERyYXdlciB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xyXG4vLyBpbXBvcnQgeyBQUk9KRUNUX0xPR08sIFNUQVRJQ19QSE9ORSB9IGZyb20gXCIuLi9jb25maWcvc2VydmVyS2V5XCI7XHJcbmltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzXCI7XHJcbmltcG9ydCB7IENsb3NlT3V0bGluZWQgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2ljb25zXCI7XHJcbmltcG9ydCB7IFNUQVRJQ19QSE9ORSB9IGZyb20gXCIuLi8uLi9jb25maWcvc2VydmVyS2V5XCI7XHJcbmltcG9ydCB7IGdldEFwaSB9IGZyb20gXCIuLi8uLi9jb25maWcvQ3VzdG9tQXBpXCI7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICByb290OiB7XHJcbiAgICBmbGV4R3JvdzogMSxcclxuICB9LFxyXG4gIG1lbnVCdXR0b246IHtcclxuICAgIG1hcmdpblJpZ2h0OiB0aGVtZS5zcGFjaW5nKDIpLFxyXG4gIH0sXHJcbiAgdGl0bGU6IHtcclxuICAgIGZsZXhHcm93OiAxLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBjb25zdCBIZWFkZXIgPSAoe2FydGljbGV9KSA9PiB7XHJcbiAgY29uc3Qge2JhbmdhbG9yZVByb2plY3RzTGlzdCxiYW5nYWxvcmVQcm9qZWN0TGlua3N9PWFydGljbGUuZmllbGRzO1xyXG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBoYW5kbGVEcmF3ZXIgPSAoKSA9PiB7XHJcbiAgICBzZXRPcGVuKHRydWUpO1xyXG4gIH07XHJcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBnZXRBcGkoKS50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgIHNldERhdGEoZGF0YSk7XHJcbiAgICB9KTtcclxuICB9LCBbXSk7XHJcbiAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0b3BfaGVhZFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtjbGFzc2VzLnJvb3R9PlxyXG4gICAgICAgICAgPENzc0Jhc2VsaW5lIC8+XHJcbiAgICAgICAgICA8QXBwQmFyPlxyXG4gICAgICAgICAgICA8VG9vbGJhcj5cclxuICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDZcIiBjbGFzc05hbWU9e2NsYXNzZXMudGl0bGV9PlxyXG4gICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICBzcmM9XCJodHRwczovL3d3dy5wcmVzdGlnZWNvbnN0cnVjdGlvbnMuY29tL2ltYWdlcy9sb2dvLnBuZ1wiXHJcbiAgICAgICAgICAgICAgICAgIGFsdD1cImxvZ29cIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm5hdmlnYXRpb24tbWVudSBtb2JCbG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8YSBocmVmPVwiLyNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Ib21lPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImhhcy1zdWJtZW51IFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YSBocmVmPVwiLyNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIFByb2plY3RzIDxzcGFuIGNsYXNzTmFtZT1cIm1lbnUtYXJyb3dcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzdWJtZW51XCI+XHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBiYW5nYWxvcmVQcm9qZWN0c0xpc3QubWFwKChpdGVtLGkpPT4oXHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtpfT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e2JhbmdhbG9yZVByb2plY3RMaW5rc1tpXX0gdGFyZ2V0PVwiX25ld1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YmFuZ2Fsb3JlUHJvamVjdHNMaXN0W2ldfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIi8jXCIgZGF0YS10b2dnbGU9XCJtb2RhbFwiIGRhdGEtdGFyZ2V0PVwiI215bW9kYWxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Db250YWN0IHVzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICA8YSBocmVmPVwiLyNcIiBkYXRhLXRvZ2dsZT1cIm1vZGFsXCIgZGF0YS10YXJnZXQ9XCIjbXltb2RhbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkx1eHVyeSBIb21lczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIi8jXCIgZGF0YS10b2dnbGU9XCJtb2RhbFwiIGRhdGEtdGFyZ2V0PVwiI215bW9kYWxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SZWFkeSBIb21lczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEcmF3ZXJ9XHJcbiAgICAgICAgICAgICAgICAgIGVkZ2U9XCJzdGFydFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7Y2xhc3Nlcy5tZW51QnV0dG9ufSBgfVxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj1cImluaGVyaXRcIlxyXG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwibWVudVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxNZW51SWNvbiAvPlxyXG4gICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L1Rvb2xiYXI+XHJcbiAgICAgICAgICA8L0FwcEJhcj5cclxuICAgICAgICAgIDxEcmF3ZXJcclxuICAgICAgICAgICAgYW5jaG9yPVwicmlnaHRcIlxyXG4gICAgICAgICAgICBvcGVuPXtvcGVufVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiMTAwdmhcIiwgcGFkZGluZzogXCIyMHB4IDQwcHhcIiwgd2lkdGg6IFwiNDE1cHhcIiB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEljb25CdXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBvc2l0aW9uOiBcImFic29sdXRlXCIsIHJpZ2h0OiBcIjBcIiwgdG9wOiBcIi0zcHhcIiB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxDbG9zZU91dGxpbmVkIGNvbG9yPVwicHJpbWFyeVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbW8tbGlzdFwiPlxyXG4gICAgICAgICAgICAgICAgICA8dWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNhYm91dF91c1wiPkFib3V0IFVzIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIvI1wiIGRhdGEtdG9nZ2xlPVwibW9kYWxcIiBkYXRhLXRhcmdldD1cIiNteW1vZGFsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENvbnRhY3QgdXN7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiLyNcIiBkYXRhLXRvZ2dsZT1cIm1vZGFsXCIgZGF0YS10YXJnZXQ9XCIjbXltb2RhbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5MdXh1cnkgSG9tZXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8bGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiLyNcIiBkYXRhLXRvZ2dsZT1cIm1vZGFsXCIgZGF0YS10YXJnZXQ9XCIjbXltb2RhbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SZWFkeSBIb21lczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cInBob25lX3VybFwiIGhyZWY9XCJ0ZWw6MDc5NDkxMzA0NjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGhvbmVfbm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGF0YT8ucGhvbmUgfHwgU1RBVElDX1BIT05FfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvRHJhd2VyPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcbiIsImltcG9ydCBkeW5hbWljIGZyb20gJ25leHQvZHluYW1pYyc7XHJcbmNvbnN0IE93bENhcm91c2VsID0gZHluYW1pYyhpbXBvcnQoJ3JlYWN0LW93bC1jYXJvdXNlbCcpKTtcclxuaW1wb3J0IFwib3dsLmNhcm91c2VsL2Rpc3QvYXNzZXRzL293bC5jYXJvdXNlbC5jc3NcIjtcclxuaW1wb3J0IFwib3dsLmNhcm91c2VsL2Rpc3QvYXNzZXRzL293bC50aGVtZS5kZWZhdWx0LmNzc1wiO1xyXG5pbXBvcnQgQWlybGluZVNlYXRGbGF0SWNvbiBmcm9tIFwiQG1hdGVyaWFsLXVpL2ljb25zL0FpcmxpbmVTZWF0RmxhdFwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IEJhbmdhbG9yZVByb2plY3QgPSAoeyBhcnRpY2xlIH0pID0+IHtcclxuICBjb25zdCB7XHJcbiAgICBwcm9qZWN0c0luQmFuZ2Fsb3JlLFxyXG4gICAgYmFuZ2Fsb3JlU2xpZGUxQWRkcmVzcyxcclxuICAgIGJhbmdhbG9yZVNsaWRlMUJlZEluZm8sXHJcbiAgICBiYW5nYWxvcmVTbGlkZTFQcmljZUluZm8sXHJcbiAgfSA9IGFydGljbGUuZmllbGRzO1xyXG4gIGNvbnN0IHN0YXRlMSA9IHtcclxuICAgIHJlc3BvbnNpdmU6IHtcclxuICAgICAgMDoge1xyXG4gICAgICAgIGl0ZW1zOiAxLFxyXG4gICAgICB9LFxyXG4gICAgICA0NTA6IHtcclxuICAgICAgICBpdGVtczogMixcclxuICAgICAgfSxcclxuICAgICAgNjAwOiB7XHJcbiAgICAgICAgaXRlbXM6IDMsXHJcbiAgICAgIH0sXHJcbiAgICAgIDEwMDA6IHtcclxuICAgICAgICBpdGVtczogMyxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgPE93bENhcm91c2VsXHJcbiAgICAgICAgICBpdGVtcz17M31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cIm93bC10aGVtZVwiXHJcbiAgICAgICAgICBsb29wXHJcbiAgICAgICAgICBuYXZcclxuICAgICAgICAgIG1hcmdpbj17MjB9XHJcbiAgICAgICAgICByZXNwb25zaXZlPXtzdGF0ZTEucmVzcG9uc2l2ZX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7cHJvamVjdHNJbkJhbmdhbG9yZS5tYXAoKGl0ZW0sIGkpID0+IChcclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhcmQgYm9yZGVyLTAgd29yay1jb250YWluZXIgd29yay1ncmlkIHBvc2l0aW9uLXJlbGF0aXZlIGQtYmxvY2tcIlxyXG4gICAgICAgICAgICAgIGtleT17aX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5IHAtMFwiPlxyXG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIi8jXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICBzcmM9e3Byb2plY3RzSW5CYW5nYWxvcmVbaV0/LmZpZWxkcz8uZmlsZT8udXJsfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImltZy1mbHVpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgYWx0PXtwcm9qZWN0c0luQmFuZ2Fsb3JlW2ldPy5maWVsZHM/LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250ZW50IGJnLXdoaXRlIHAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIvI1wiPntwcm9qZWN0c0luQmFuZ2Fsb3JlW2ldPy5maWVsZHM/LnRpdGxlfTwvYT5cclxuICAgICAgICAgICAgICAgICAgPC9oNT5cclxuICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cInRleHQtbXV0ZWQgdGFnIG1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiLyNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInN1YnRpdGxlXCI+e2JhbmdhbG9yZVNsaWRlMUFkZHJlc3NbaV19PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPC9oNj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb3N0LW1ldGEgZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuIG10LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibGlzdC11bnN0eWxlZCBtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwibGlzdC1pbmxpbmUtaXRlbSBtci0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cIm1kaSBtZGktYmVkLWVtcHR5IG1kaS0yNHB4IG1yLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QWlybGluZVNlYXRGbGF0SWNvbiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtiYW5nYWxvcmVTbGlkZTFCZWRJbmZvW2ldfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLXNtIGJ0bi1pbmZvXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdG9nZ2xlPVwibW9kYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YS10YXJnZXQ9XCIjbXltb2RhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiLyNcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtiYW5nYWxvcmVTbGlkZTFQcmljZUluZm9baV19XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkX21vcmUgcHN0YXR1cyB0ZXh0LWNlbnRlciByb3VuZGVkLWNpcmNsZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdGF0dXNsX1JlYWR5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3Byb2plY3RzSW5CYW5nYWxvcmVbaV0/LmZpZWxkcz8uZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvT3dsQ2Fyb3VzZWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuIiwiaW1wb3J0IEFpcmxpbmVTZWF0RmxhdEljb24gZnJvbSBcIkBtYXRlcmlhbC11aS9pY29ucy9BaXJsaW5lU2VhdEZsYXRcIjtcclxuaW1wb3J0IGR5bmFtaWMgZnJvbSAnbmV4dC9keW5hbWljJztcclxuY29uc3QgT3dsQ2Fyb3VzZWwgPSBkeW5hbWljKGltcG9ydCgncmVhY3Qtb3dsLWNhcm91c2VsJykpO1xyXG5pbXBvcnQgXCJvd2wuY2Fyb3VzZWwvZGlzdC9hc3NldHMvb3dsLmNhcm91c2VsLmNzc1wiO1xyXG5pbXBvcnQgXCJvd2wuY2Fyb3VzZWwvZGlzdC9hc3NldHMvb3dsLnRoZW1lLmRlZmF1bHQuY3NzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgQmFuZ2Fsb3JlU2xpZGUyID0gKHthcnRpY2xlfSkgPT4ge1xyXG4gICAgY29uc3Qge1xyXG4gICAgICAgIGJhbmdhbG9yZVByb2plY3RTbGlkZTIsXHJcbiAgICAgICAgYmFuZ2Fsb3JlU2xpZGUyQWRkcmVzcyxcclxuICAgICAgICBiYW5nYWxvcmVTbGlkZTJCZWRJbmZvLFxyXG4gICAgICAgIGJhbmdhbG9yZVNsaWRlMlByaWNlSW5mbyx9PWFydGljbGUuZmllbGRzO1xyXG4gICAgICAgIGNvbnN0IHN0YXRlID0ge1xyXG4gICAgICAgICAgICByZXNwb25zaXZlOiB7XHJcbiAgICAgICAgICAgICAgMDoge1xyXG4gICAgICAgICAgICAgICAgaXRlbXM6IDEsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICA0NTA6IHtcclxuICAgICAgICAgICAgICAgIGl0ZW1zOiAyLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgNjAwOiB7XHJcbiAgICAgICAgICAgICAgICBpdGVtczogMyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIDEwMDA6IHtcclxuICAgICAgICAgICAgICAgIGl0ZW1zOiAzLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9O1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxPd2xDYXJvdXNlbFxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zPXszfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm93bC10aGVtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbG9vcFxyXG4gICAgICAgICAgICAgICAgICAgIG5hdlxyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbj17MjB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2l2ZT17c3RhdGUucmVzcG9uc2l2ZX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtiYW5nYWxvcmVQcm9qZWN0U2xpZGUyLm1hcCgoaXRlbSwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGJvcmRlci0wIHdvcmstY29udGFpbmVyIHdvcmstZ3JpZCBwb3NpdGlvbi1yZWxhdGl2ZSBkLWJsb2NrXCIga2V5PXtpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgcC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIi8jXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17YmFuZ2Fsb3JlUHJvamVjdFNsaWRlMltpXT8uZmllbGRzPy5maWxlPy51cmx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImltZy1mbHVpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17YmFuZ2Fsb3JlUHJvamVjdFNsaWRlMltpXT8uZmllbGRzPy50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGVudCBiZy13aGl0ZSBwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIvI1wiIHRhcmdldD1cIl9uZXdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmFuZ2Fsb3JlUHJvamVjdFNsaWRlMltpXT8uZmllbGRzPy50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oNT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkIHRhZyBtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIvI1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInN1YnRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmFuZ2Fsb3JlU2xpZGUyQWRkcmVzc1tpXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBvc3QtbWV0YSBkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW4gbXQtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibGlzdC11bnN0eWxlZCBtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImxpc3QtaW5saW5lLWl0ZW0gbXItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwibWRpIG1kaS1iZWQtZW1wdHkgbWRpLTI0cHggbXItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWlybGluZVNlYXRGbGF0SWNvbiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2JhbmdhbG9yZVNsaWRlMkJlZEluZm9baV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLXNtIGJ0bi1pbmZvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRvZ2dsZT1cIm1vZGFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRhcmdldD1cIiNteW1vZGFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiLyNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2JhbmdhbG9yZVNsaWRlMlByaWNlSW5mb1tpXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkX21vcmUgcHN0YXR1cyB0ZXh0LWNlbnRlciByb3VuZGVkLWNpcmNsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3RhdHVzbF9SZWFkeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmFuZ2Fsb3JlUHJvamVjdFNsaWRlMltpXT8uZmllbGRzPy5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9Pd2xDYXJvdXNlbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gXHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApXHJcbn1cclxuIiwiaW1wb3J0IENhcm91c2VsIGZyb20gXCJyZWFjdC1ib290c3RyYXAvQ2Fyb3VzZWxcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBCYW5uZXIgPSAoe2FydGljbGV9KSA9PiB7XHJcbiAgICBjb25zdHtiYW5uZXJJbWFnZXN9PWFydGljbGUuZmllbGRzO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIkJhbm5lcl9TZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxDYXJvdXNlbD5cclxuICAgICAgICAgIHtiYW5uZXJJbWFnZXMubWFwKChpdGVtLCBpKSA9PiAoXHJcbiAgICAgICAgICAgIDxDYXJvdXNlbC5JdGVtIGtleT17aX0+XHJcbiAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZC1ibG9jayB3LTEwMFwiXHJcbiAgICAgICAgICAgICAgICBzcmM9e2Jhbm5lckltYWdlc1tpXT8uZmllbGRzPy5maWxlPy51cmx9XHJcbiAgICAgICAgICAgICAgICBhbHQ9e2Jhbm5lckltYWdlc1tpXT8uZmllbGRzPy50aXRsZX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0Nhcm91c2VsLkl0ZW0+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L0Nhcm91c2VsPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG59XHJcbiIsIlxyXG5leHBvcnQgY29uc3QgQ291bnRyeUNvZGUgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIklOXCIgdmFsdWU9XCIrOTFcIiBkZWZhdWx0VmFsdWU+XHJcbiAgICAgICAgSW5kaWEgKCs5MSlcclxuICAgICAgPC9vcHRpb24+XHJcbiAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkFVXCIgdmFsdWU9XCIrNjFcIj5cclxuICAgICAgICBBdXN0cmFsaWEgKCs2MSlcclxuICAgICAgPC9vcHRpb24+XHJcbiAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkJIXCIgdmFsdWU9XCIrOTczXCI+XHJcbiAgICAgICAgQmFocmFpbiAoKzk3MylcclxuICAgICAgPC9vcHRpb24+XHJcbiAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkNBXCIgdmFsdWU9XCIrMVwiPlxyXG4gICAgICAgIENhbmFkYSAoKzEpXHJcbiAgICAgIDwvb3B0aW9uPlxyXG4gICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJIS1wiIHZhbHVlPVwiKzg1MlwiPlxyXG4gICAgICAgIEhvbmcgS29uZyAoKzg1MilcclxuICAgICAgPC9vcHRpb24+XHJcbiAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlFBXCIgdmFsdWU9XCIrOTc0XCI+XHJcbiAgICAgICAgUWF0YXIgKCs5NzQpXHJcbiAgICAgIDwvb3B0aW9uPlxyXG4gICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJTQVwiIHZhbHVlPVwiKzk2NlwiPlxyXG4gICAgICAgIFNhdWRpIEFyYWJpYSAoKzk2NilcclxuICAgICAgPC9vcHRpb24+XHJcbiAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlNHXCIgdmFsdWU9XCIrNjVcIj5cclxuICAgICAgICBTaW5nYXBvcmUgKCs2NSlcclxuICAgICAgPC9vcHRpb24+XHJcbiAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlpBXCIgdmFsdWU9XCIrMjdcIj5cclxuICAgICAgICBTb3V0aCBBZnJpY2EgKCsyNylcclxuICAgICAgPC9vcHRpb24+XHJcbiAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkFFXCIgdmFsdWU9XCIrOTcxXCI+XHJcbiAgICAgICAgVW5pdGVkIEFyYWIgRW1pcmF0ZXMgKCs5NzEpXHJcbiAgICAgIDwvb3B0aW9uPlxyXG4gICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJVU1wiIHZhbHVlPVwiKzFcIj5cclxuICAgICAgICBVU0EgKCsxKVxyXG4gICAgICA8L29wdGlvbj5cclxuICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiR0JcIiBuYW1lPVwiY291bnRyeWNvZGVcIiB2YWx1ZT1cIis0NFwiPlxyXG4gICAgICAgIFVLICgrNDQpXHJcbiAgICAgIDwvb3B0aW9uPlxyXG4gICAgICA8b3B0Z3JvdXAgbGFiZWw9XCJPdGhlciBjb3VudHJpZXNcIj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJBRlwiIHZhbHVlPVwiKzkzXCI+XHJcbiAgICAgICAgICBBZmdoYW5pc3RhbiAoKzkzKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkFMXCIgdmFsdWU9XCIrMzU1XCI+XHJcbiAgICAgICAgICBBbGJhbmlhICgrMzU1KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkRaXCIgdmFsdWU9XCIrMjEzXCI+XHJcbiAgICAgICAgICBBbGdlcmlhICgrMjEzKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkFTXCIgdmFsdWU9XCIrMS02ODRcIj5cclxuICAgICAgICAgIEFtZXJpY2FuIFNhbW9hICgrMS02ODQpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQURcIiB2YWx1ZT1cIiszNzZcIj5cclxuICAgICAgICAgIEFuZG9ycmEgKCszNzYpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQU9cIiB2YWx1ZT1cIisyNDRcIj5cclxuICAgICAgICAgIEFuZ29sYSAoKzI0NClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJBSVwiIHZhbHVlPVwiKzEtMjY0XCI+XHJcbiAgICAgICAgICBBbmd1aWxsYSAoKzEtMjY0KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkFRXCIgdmFsdWU9XCIrNjcyXCI+XHJcbiAgICAgICAgICBBbnRhcmN0aWNhICgrNjcyKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkFHXCIgdmFsdWU9XCIrMS0yNjhcIj5cclxuICAgICAgICAgIEFudGlndWEgYW5kIEJhcmJ1ZGEgKCsxLTI2OClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJBUlwiIHZhbHVlPVwiKzU0XCI+XHJcbiAgICAgICAgICBBcmdlbnRpbmEgKCs1NClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJBTVwiIHZhbHVlPVwiKzM3NFwiPlxyXG4gICAgICAgICAgQXJtZW5pYSAoKzM3NClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJBV1wiIHZhbHVlPVwiKzI5N1wiPlxyXG4gICAgICAgICAgQXJ1YmEgKCsyOTcpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQVRcIiB2YWx1ZT1cIis0M1wiPlxyXG4gICAgICAgICAgQXVzdHJpYSAoKzQzKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkFaXCIgdmFsdWU9XCIrOTk0XCI+XHJcbiAgICAgICAgICBBemVyYmFpamFuICgrOTk0KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkJTXCIgdmFsdWU9XCIrMS0yNDJcIj5cclxuICAgICAgICAgIEJhaGFtYXMgKCsxLTI0MilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJCRFwiIHZhbHVlPVwiKzg4MFwiPlxyXG4gICAgICAgICAgQmFuZ2xhZGVzaCAoKzg4MClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJCQlwiIHZhbHVlPVwiKzEtMjQ2XCI+XHJcbiAgICAgICAgICBCYXJiYWRvcyAoKzEtMjQ2KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkJZXCIgdmFsdWU9XCIrMzc1XCI+XHJcbiAgICAgICAgICBCZWxhcnVzICgrMzc1KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkJFXCIgdmFsdWU9XCIrMzJcIj5cclxuICAgICAgICAgIEJlbGdpdW0gKCszMilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJCWlwiIHZhbHVlPVwiKzUwMVwiPlxyXG4gICAgICAgICAgQmVsaXplICgrNTAxKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkJKXCIgdmFsdWU9XCIrMjI5XCI+XHJcbiAgICAgICAgICBCZW5pbiAoKzIyOSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJCTVwiIHZhbHVlPVwiKzEtNDQxXCI+XHJcbiAgICAgICAgICBCZXJtdWRhICgrMS00NDEpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQlRcIiB2YWx1ZT1cIis5NzVcIj5cclxuICAgICAgICAgIEJodXRhbiAoKzk3NSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJCT1wiIHZhbHVlPVwiKzU5MVwiPlxyXG4gICAgICAgICAgQm9saXZpYSAoKzU5MSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJCQVwiIHZhbHVlPVwiKzM4N1wiPlxyXG4gICAgICAgICAgQm9zbmlhIGFuZCBIZXJ6ZWdvd2luYSAoKzM4NylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJCV1wiIHZhbHVlPVwiKzI2N1wiPlxyXG4gICAgICAgICAgQm90c3dhbmEgKCsyNjcpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQlZcIiB2YWx1ZT1cIis0N1wiPlxyXG4gICAgICAgICAgQm91dmV0IElzbGFuZCAoKzQ3KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkJSXCIgdmFsdWU9XCIrNTVcIj5cclxuICAgICAgICAgIEJyYXppbCAoKzU1KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIklPXCIgdmFsdWU9XCIrMjQ2XCI+XHJcbiAgICAgICAgICBCcml0aXNoIEluZGlhbiBPY2VhbiBUZXJyaXRvcnkgKCsyNDYpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQk5cIiB2YWx1ZT1cIis2NzNcIj5cclxuICAgICAgICAgIEJydW5laSBEYXJ1c3NhbGFtICgrNjczKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkJHXCIgdmFsdWU9XCIrMzU5XCI+XHJcbiAgICAgICAgICBCdWxnYXJpYSAoKzM1OSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJCRlwiIHZhbHVlPVwiKzIyNlwiPlxyXG4gICAgICAgICAgQnVya2luYSBGYXNvICgrMjI2KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkJJXCIgdmFsdWU9XCIrMjU3XCI+XHJcbiAgICAgICAgICBCdXJ1bmRpICgrMjU3KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIktIXCIgdmFsdWU9XCIrODU1XCI+XHJcbiAgICAgICAgICBDYW1ib2RpYSAoKzg1NSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJDTVwiIHZhbHVlPVwiKzIzN1wiPlxyXG4gICAgICAgICAgQ2FtZXJvb24gKCsyMzcpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQ1ZcIiB2YWx1ZT1cIisyMzhcIj5cclxuICAgICAgICAgIENhcGUgVmVyZGUgKCsyMzgpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiS1lcIiB2YWx1ZT1cIisxLTM0NVwiPlxyXG4gICAgICAgICAgQ2F5bWFuIElzbGFuZHMgKCsxLTM0NSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJDRlwiIHZhbHVlPVwiKzIzNlwiPlxyXG4gICAgICAgICAgQ2VudHJhbCBBZnJpY2FuIFJlcHVibGljICgrMjM2KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlREXCIgdmFsdWU9XCIrMjM1XCI+XHJcbiAgICAgICAgICBDaGFkICgrMjM1KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkNMXCIgdmFsdWU9XCIrNTZcIj5cclxuICAgICAgICAgIENoaWxlICgrNTYpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQ05cIiB2YWx1ZT1cIis4NlwiPlxyXG4gICAgICAgICAgQ2hpbmEgKCs4NilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJDWFwiIHZhbHVlPVwiKzYxXCI+XHJcbiAgICAgICAgICBDaHJpc3RtYXMgSXNsYW5kICgrNjEpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQ0NcIiB2YWx1ZT1cIis2MVwiPlxyXG4gICAgICAgICAgQ29jb3MgKEtlZWxpbmcpIElzbGFuZHMgKCs2MSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJDT1wiIHZhbHVlPVwiKzU3XCI+XHJcbiAgICAgICAgICBDb2xvbWJpYSAoKzU3KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIktNXCIgdmFsdWU9XCIrMjY5XCI+XHJcbiAgICAgICAgICBDb21vcm9zICgrMjY5KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkNHXCIgdmFsdWU9XCIrMjQyXCI+XHJcbiAgICAgICAgICBDb25nbyBEZW1vY3JhdGljIFJlcHVibGljIG9mICgrMjQyKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkNLXCIgdmFsdWU9XCIrNjgyXCI+XHJcbiAgICAgICAgICBDb29rIElzbGFuZHMgKCs2ODIpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQ1JcIiB2YWx1ZT1cIis1MDZcIj5cclxuICAgICAgICAgIENvc3RhIFJpY2EgKCs1MDYpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQ0lcIiB2YWx1ZT1cIisyMjVcIj5cclxuICAgICAgICAgIENvdGUgRCdJdm9pcmUgKCsyMjUpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiSFJcIiB2YWx1ZT1cIiszODVcIj5cclxuICAgICAgICAgIENyb2F0aWEgKCszODUpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQ1VcIiB2YWx1ZT1cIis1M1wiPlxyXG4gICAgICAgICAgQ3ViYSAoKzUzKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkNZXCIgdmFsdWU9XCIrMzU3XCI+XHJcbiAgICAgICAgICBDeXBydXMgKCszNTcpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiQ1pcIiB2YWx1ZT1cIis0MjBcIj5cclxuICAgICAgICAgIEN6ZWNoIFJlcHVibGljICgrNDIwKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkRLXCIgdmFsdWU9XCIrNDVcIj5cclxuICAgICAgICAgIERlbm1hcmsgKCs0NSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJESlwiIHZhbHVlPVwiKzI1M1wiPlxyXG4gICAgICAgICAgRGppYm91dGkgKCsyNTMpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiRE1cIiB2YWx1ZT1cIisxLTc2N1wiPlxyXG4gICAgICAgICAgRG9taW5pY2EgKCsxLTc2NylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJET1wiIHZhbHVlPVwiKzEtODA5XCI+XHJcbiAgICAgICAgICBEb21pbmljYW4gUmVwdWJsaWMgKCsxLTgwOSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJUTFwiIHZhbHVlPVwiKzY3MFwiPlxyXG4gICAgICAgICAgVGltb3ItTGVzdGUgKCs2NzApXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiRUNcIiB2YWx1ZT1cIis1OTNcIj5cclxuICAgICAgICAgIEVjdWFkb3IgKCs1OTMpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiRUdcIiB2YWx1ZT1cIisyMFwiPlxyXG4gICAgICAgICAgRWd5cHQgKCsyMClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJTVlwiIHZhbHVlPVwiKzUwM1wiPlxyXG4gICAgICAgICAgRWwgU2FsdmFkb3IgKCs1MDMpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiR1FcIiB2YWx1ZT1cIisyNDBcIj5cclxuICAgICAgICAgIEVxdWF0b3JpYWwgR3VpbmVhICgrMjQwKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkVSXCIgdmFsdWU9XCIrMjkxXCI+XHJcbiAgICAgICAgICBFcml0cmVhICgrMjkxKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkVFXCIgdmFsdWU9XCIrMzcyXCI+XHJcbiAgICAgICAgICBFc3RvbmlhICgrMzcyKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkVUXCIgdmFsdWU9XCIrMjUxXCI+XHJcbiAgICAgICAgICBFdGhpb3BpYSAoKzI1MSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJGS1wiIHZhbHVlPVwiKzUwMFwiPlxyXG4gICAgICAgICAgRmFsa2xhbmQgSXNsYW5kcyAoTWFsdmluYXMpICgrNTAwKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkZPXCIgdmFsdWU9XCIrMjk4XCI+XHJcbiAgICAgICAgICBGYXJvZSBJc2xhbmRzICgrMjk4KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkZKXCIgdmFsdWU9XCIrNjc5XCI+XHJcbiAgICAgICAgICBGaWppICgrNjc5KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkZJXCIgdmFsdWU9XCIrMzU4XCI+XHJcbiAgICAgICAgICBGaW5sYW5kICgrMzU4KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkZSXCIgdmFsdWU9XCIrMzNcIj5cclxuICAgICAgICAgIEZyYW5jZSAoKzMzKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdGXCIgdmFsdWU9XCIrNTk0XCI+XHJcbiAgICAgICAgICBGcmVuY2ggR3VpYW5hICgrNTk0KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlBGXCIgdmFsdWU9XCIrNjg5XCI+XHJcbiAgICAgICAgICBGcmVuY2ggUG9seW5lc2lhICgrNjg5KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlRGXCIgdmFsdWU9XCIrXCI+XHJcbiAgICAgICAgICBGcmVuY2ggU291dGhlcm4gVGVycml0b3JpZXMgKCspXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiR0FcIiB2YWx1ZT1cIisyNDFcIj5cclxuICAgICAgICAgIEdhYm9uICgrMjQxKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdNXCIgdmFsdWU9XCIrMjIwXCI+XHJcbiAgICAgICAgICBHYW1iaWEgKCsyMjApXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiR0VcIiB2YWx1ZT1cIis5OTVcIj5cclxuICAgICAgICAgIEdlb3JnaWEgKCs5OTUpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiREVcIiB2YWx1ZT1cIis0OVwiPlxyXG4gICAgICAgICAgR2VybWFueSAoKzQ5KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdIXCIgdmFsdWU9XCIrMjMzXCI+XHJcbiAgICAgICAgICBHaGFuYSAoKzIzMylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJHSVwiIHZhbHVlPVwiKzM1MFwiPlxyXG4gICAgICAgICAgR2licmFsdGFyICgrMzUwKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdSXCIgdmFsdWU9XCIrMzBcIj5cclxuICAgICAgICAgIEdyZWVjZSAoKzMwKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdMXCIgdmFsdWU9XCIrMjk5XCI+XHJcbiAgICAgICAgICBHcmVlbmxhbmQgKCsyOTkpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiR0RcIiB2YWx1ZT1cIisxLTQ3M1wiPlxyXG4gICAgICAgICAgR3JlbmFkYSAoKzEtNDczKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdQXCIgdmFsdWU9XCIrNTkwXCI+XHJcbiAgICAgICAgICBHdWFkZWxvdXBlICgrNTkwKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdVXCIgdmFsdWU9XCIrMS02NzFcIj5cclxuICAgICAgICAgIEd1YW0gKCsxLTY3MSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJHVFwiIHZhbHVlPVwiKzUwMlwiPlxyXG4gICAgICAgICAgR3VhdGVtYWxhICgrNTAyKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdOXCIgdmFsdWU9XCIrMjI0XCI+XHJcbiAgICAgICAgICBHdWluZWEgKCsyMjQpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiR1dcIiB2YWx1ZT1cIisyNDVcIj5cclxuICAgICAgICAgIEd1aW5lYS1iaXNzYXUgKCsyNDUpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiR1lcIiB2YWx1ZT1cIis1OTJcIj5cclxuICAgICAgICAgIEd1eWFuYSAoKzU5MilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJIVFwiIHZhbHVlPVwiKzUwOVwiPlxyXG4gICAgICAgICAgSGFpdGkgKCs1MDkpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiSE1cIiB2YWx1ZT1cIiswMTFcIj5cclxuICAgICAgICAgIEhlYXJkIElzbGFuZCBhbmQgTWNEb25hbGQgSXNsYW5kcyAoKzAxMSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJITlwiIHZhbHVlPVwiKzUwNFwiPlxyXG4gICAgICAgICAgSG9uZHVyYXMgKCs1MDQpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiSFVcIiB2YWx1ZT1cIiszNlwiPlxyXG4gICAgICAgICAgSHVuZ2FyeSAoKzM2KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIklTXCIgdmFsdWU9XCIrMzU0XCI+XHJcbiAgICAgICAgICBJY2VsYW5kICgrMzU0KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIklEXCIgdmFsdWU9XCIrNjJcIj5cclxuICAgICAgICAgIEluZG9uZXNpYSAoKzYyKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIklSXCIgdmFsdWU9XCIrOThcIj5cclxuICAgICAgICAgIElyYW4gKElzbGFtaWMgUmVwdWJsaWMgb2YpICgrOTgpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiSVFcIiB2YWx1ZT1cIis5NjRcIj5cclxuICAgICAgICAgIElyYXEgKCs5NjQpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiSUVcIiB2YWx1ZT1cIiszNTNcIj5cclxuICAgICAgICAgIElyZWxhbmQgKCszNTMpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiSUxcIiB2YWx1ZT1cIis5NzJcIj5cclxuICAgICAgICAgIElzcmFlbCAoKzk3MilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJJVFwiIHZhbHVlPVwiKzM5XCI+XHJcbiAgICAgICAgICBJdGFseSAoKzM5KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkpNXCIgdmFsdWU9XCIrMS04NzZcIj5cclxuICAgICAgICAgIEphbWFpY2EgKCsxLTg3NilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJKUFwiIHZhbHVlPVwiKzgxXCI+XHJcbiAgICAgICAgICBKYXBhbiAoKzgxKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkpPXCIgdmFsdWU9XCIrOTYyXCI+XHJcbiAgICAgICAgICBKb3JkYW4gKCs5NjIpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiS1pcIiB2YWx1ZT1cIis3XCI+XHJcbiAgICAgICAgICBLYXpha2hzdGFuICgrNylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJLRVwiIHZhbHVlPVwiKzI1NFwiPlxyXG4gICAgICAgICAgS2VueWEgKCsyNTQpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiS0lcIiB2YWx1ZT1cIis2ODZcIj5cclxuICAgICAgICAgIEtpcmliYXRpICgrNjg2KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIktQXCIgdmFsdWU9XCIrODUwXCI+XHJcbiAgICAgICAgICBLb3JlYSwgRGVtb2NyYXRpYyBQZW9wbGUncyBSZXB1YmxpYyBvZiAoKzg1MClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJLUlwiIHZhbHVlPVwiKzgyXCI+XHJcbiAgICAgICAgICBTb3V0aCBLb3JlYSAoKzgyKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIktXXCIgdmFsdWU9XCIrOTY1XCI+XHJcbiAgICAgICAgICBLdXdhaXQgKCs5NjUpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiS0dcIiB2YWx1ZT1cIis5OTZcIj5cclxuICAgICAgICAgIEt5cmd5enN0YW4gKCs5OTYpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTEFcIiB2YWx1ZT1cIis4NTZcIj5cclxuICAgICAgICAgIExhbyBQZW9wbGUncyBEZW1vY3JhdGljIFJlcHVibGljICgrODU2KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkxWXCIgdmFsdWU9XCIrMzcxXCI+XHJcbiAgICAgICAgICBMYXR2aWEgKCszNzEpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTEJcIiB2YWx1ZT1cIis5NjFcIj5cclxuICAgICAgICAgIExlYmFub24gKCs5NjEpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTFNcIiB2YWx1ZT1cIisyNjZcIj5cclxuICAgICAgICAgIExlc290aG8gKCsyNjYpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTFJcIiB2YWx1ZT1cIisyMzFcIj5cclxuICAgICAgICAgIExpYmVyaWEgKCsyMzEpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTFlcIiB2YWx1ZT1cIisyMThcIj5cclxuICAgICAgICAgIExpYnlhICgrMjE4KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkxJXCIgdmFsdWU9XCIrNDIzXCI+XHJcbiAgICAgICAgICBMaWVjaHRlbnN0ZWluICgrNDIzKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkxUXCIgdmFsdWU9XCIrMzcwXCI+XHJcbiAgICAgICAgICBMaXRodWFuaWEgKCszNzApXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTFVcIiB2YWx1ZT1cIiszNTJcIj5cclxuICAgICAgICAgIEx1eGVtYm91cmcgKCszNTIpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTU9cIiB2YWx1ZT1cIis4NTNcIj5cclxuICAgICAgICAgIE1hY2FvICgrODUzKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIk1LXCIgdmFsdWU9XCIrMzg5XCI+XHJcbiAgICAgICAgICBNYWNlZG9uaWEsIFRoZSBGb3JtZXIgWXVnb3NsYXYgUmVwdWJsaWMgb2YgKCszODkpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTUdcIiB2YWx1ZT1cIisyNjFcIj5cclxuICAgICAgICAgIE1hZGFnYXNjYXIgKCsyNjEpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTVdcIiB2YWx1ZT1cIisyNjVcIj5cclxuICAgICAgICAgIE1hbGF3aSAoKzI2NSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJNWVwiIHZhbHVlPVwiKzYwXCI+XHJcbiAgICAgICAgICBNYWxheXNpYSAoKzYwKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIk1WXCIgdmFsdWU9XCIrOTYwXCI+XHJcbiAgICAgICAgICBNYWxkaXZlcyAoKzk2MClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJNTFwiIHZhbHVlPVwiKzIyM1wiPlxyXG4gICAgICAgICAgTWFsaSAoKzIyMylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJNVFwiIHZhbHVlPVwiKzM1NlwiPlxyXG4gICAgICAgICAgTWFsdGEgKCszNTYpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTUhcIiB2YWx1ZT1cIis2OTJcIj5cclxuICAgICAgICAgIE1hcnNoYWxsIElzbGFuZHMgKCs2OTIpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTVFcIiB2YWx1ZT1cIis1OTZcIj5cclxuICAgICAgICAgIE1hcnRpbmlxdWUgKCs1OTYpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTVJcIiB2YWx1ZT1cIisyMjJcIj5cclxuICAgICAgICAgIE1hdXJpdGFuaWEgKCsyMjIpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTVVcIiB2YWx1ZT1cIisyMzBcIj5cclxuICAgICAgICAgIE1hdXJpdGl1cyAoKzIzMClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJZVFwiIHZhbHVlPVwiKzI2MlwiPlxyXG4gICAgICAgICAgTWF5b3R0ZSAoKzI2MilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJNWFwiIHZhbHVlPVwiKzUyXCI+XHJcbiAgICAgICAgICBNZXhpY28gKCs1MilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJGTVwiIHZhbHVlPVwiKzY5MVwiPlxyXG4gICAgICAgICAgTWljcm9uZXNpYSwgRmVkZXJhdGVkIFN0YXRlcyBvZiAoKzY5MSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJNRFwiIHZhbHVlPVwiKzM3M1wiPlxyXG4gICAgICAgICAgTW9sZG92YSAoKzM3MylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJNQ1wiIHZhbHVlPVwiKzM3N1wiPlxyXG4gICAgICAgICAgTW9uYWNvICgrMzc3KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIk1OXCIgdmFsdWU9XCIrOTc2XCI+XHJcbiAgICAgICAgICBNb25nb2xpYSAoKzk3NilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJNU1wiIHZhbHVlPVwiKzEtNjY0XCI+XHJcbiAgICAgICAgICBNb250c2VycmF0ICgrMS02NjQpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTUFcIiB2YWx1ZT1cIisyMTJcIj5cclxuICAgICAgICAgIE1vcm9jY28gKCsyMTIpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTVpcIiB2YWx1ZT1cIisyNThcIj5cclxuICAgICAgICAgIE1vemFtYmlxdWUgKCsyNTgpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTU1cIiB2YWx1ZT1cIis5NVwiPlxyXG4gICAgICAgICAgTXlhbm1hciAoKzk1KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIk5BXCIgdmFsdWU9XCIrMjY0XCI+XHJcbiAgICAgICAgICBOYW1pYmlhICgrMjY0KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIk5SXCIgdmFsdWU9XCIrNjc0XCI+XHJcbiAgICAgICAgICBOYXVydSAoKzY3NClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJOUFwiIHZhbHVlPVwiKzk3N1wiPlxyXG4gICAgICAgICAgTmVwYWwgKCs5NzcpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTkxcIiB2YWx1ZT1cIiszMVwiPlxyXG4gICAgICAgICAgTmV0aGVybGFuZHMgKCszMSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJBTlwiIHZhbHVlPVwiKzU5OVwiPlxyXG4gICAgICAgICAgTmV0aGVybGFuZHMgQW50aWxsZXMgKCs1OTkpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTkNcIiB2YWx1ZT1cIis2ODcgIFwiPlxyXG4gICAgICAgICAgTmV3IENhbGVkb25pYSAoKzY4NyApXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTlpcIiB2YWx1ZT1cIis2NFwiPlxyXG4gICAgICAgICAgTmV3IFplYWxhbmQgKCs2NClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJOSVwiIHZhbHVlPVwiKzUwNVwiPlxyXG4gICAgICAgICAgTmljYXJhZ3VhICgrNTA1KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIk5FXCIgdmFsdWU9XCIrMjI3XCI+XHJcbiAgICAgICAgICBOaWdlciAoKzIyNylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJOR1wiIHZhbHVlPVwiKzIzNFwiPlxyXG4gICAgICAgICAgTmlnZXJpYSAoKzIzNClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJOVVwiIHZhbHVlPVwiKzY4M1wiPlxyXG4gICAgICAgICAgTml1ZSAoKzY4MylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJORlwiIHZhbHVlPVwiKzY3MlwiPlxyXG4gICAgICAgICAgTm9yZm9sayBJc2xhbmQgKCs2NzIpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTVBcIiB2YWx1ZT1cIisxLTY3MFwiPlxyXG4gICAgICAgICAgTm9ydGhlcm4gTWFyaWFuYSBJc2xhbmRzICgrMS02NzApXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTk9cIiB2YWx1ZT1cIis0N1wiPlxyXG4gICAgICAgICAgTm9yd2F5ICgrNDcpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiT01cIiB2YWx1ZT1cIis5NjhcIj5cclxuICAgICAgICAgIE9tYW4gKCs5NjgpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiUEtcIiB2YWx1ZT1cIis5MlwiPlxyXG4gICAgICAgICAgUGFraXN0YW4gKCs5MilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJQV1wiIHZhbHVlPVwiKzY4MFwiPlxyXG4gICAgICAgICAgUGFsYXUgKCs2ODApXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiUEFcIiB2YWx1ZT1cIis1MDdcIj5cclxuICAgICAgICAgIFBhbmFtYSAoKzUwNylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJQR1wiIHZhbHVlPVwiKzY3NVwiPlxyXG4gICAgICAgICAgUGFwdWEgTmV3IEd1aW5lYSAoKzY3NSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJQWVwiIHZhbHVlPVwiKzU5NVwiPlxyXG4gICAgICAgICAgUGFyYWd1YXkgKCs1OTUpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiUEVcIiB2YWx1ZT1cIis1MVwiPlxyXG4gICAgICAgICAgUGVydSAoKzUxKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlBIXCIgdmFsdWU9XCIrNjNcIj5cclxuICAgICAgICAgIFBoaWxpcHBpbmVzICgrNjMpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiUE5cIiB2YWx1ZT1cIis2NFwiPlxyXG4gICAgICAgICAgUGl0Y2Fpcm4gKCs2NClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJQTFwiIHZhbHVlPVwiKzQ4XCI+XHJcbiAgICAgICAgICBQb2xhbmQgKCs0OClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJQVFwiIHZhbHVlPVwiKzM1MVwiPlxyXG4gICAgICAgICAgUG9ydHVnYWwgKCszNTEpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiUFJcIiB2YWx1ZT1cIisxLTc4N1wiPlxyXG4gICAgICAgICAgUHVlcnRvIFJpY28gKCsxLTc4NylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJSRVwiIHZhbHVlPVwiKzI2MlwiPlxyXG4gICAgICAgICAgUmV1bmlvbiAoKzI2MilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJST1wiIHZhbHVlPVwiKzQwXCI+XHJcbiAgICAgICAgICBSb21hbmlhICgrNDApXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiUlVcIiB2YWx1ZT1cIis3XCI+XHJcbiAgICAgICAgICBSdXNzaWFuIEZlZGVyYXRpb24gKCs3KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlJXXCIgdmFsdWU9XCIrMjUwXCI+XHJcbiAgICAgICAgICBSd2FuZGEgKCsyNTApXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiS05cIiB2YWx1ZT1cIisxLTg2OVwiPlxyXG4gICAgICAgICAgU2FpbnQgS2l0dHMgYW5kIE5ldmlzICgrMS04NjkpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiTENcIiB2YWx1ZT1cIisxLTc1OFwiPlxyXG4gICAgICAgICAgU2FpbnQgTHVjaWEgKCsxLTc1OClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJWQ1wiIHZhbHVlPVwiKzEtNzg0XCI+XHJcbiAgICAgICAgICBTYWludCBWaW5jZW50IGFuZCB0aGUgR3JlbmFkaW5lcyAoKzEtNzg0KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIldTXCIgdmFsdWU9XCIrNjg1XCI+XHJcbiAgICAgICAgICBTYW1vYSAoKzY4NSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJTTVwiIHZhbHVlPVwiKzM3OFwiPlxyXG4gICAgICAgICAgU2FuIE1hcmlubyAoKzM3OClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJTVFwiIHZhbHVlPVwiKzIzOVwiPlxyXG4gICAgICAgICAgU2FvIFRvbWUgYW5kIFByaW5jaXBlICgrMjM5KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlNOXCIgdmFsdWU9XCIrMjIxXCI+XHJcbiAgICAgICAgICBTZW5lZ2FsICgrMjIxKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlNDXCIgdmFsdWU9XCIrMjQ4XCI+XHJcbiAgICAgICAgICBTZXljaGVsbGVzICgrMjQ4KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlNMXCIgdmFsdWU9XCIrMjMyXCI+XHJcbiAgICAgICAgICBTaWVycmEgTGVvbmUgKCsyMzIpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiU0tcIiB2YWx1ZT1cIis0MjFcIj5cclxuICAgICAgICAgIFNsb3Zha2lhIChTbG92YWsgUmVwdWJsaWMpICgrNDIxKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlNJXCIgdmFsdWU9XCIrMzg2XCI+XHJcbiAgICAgICAgICBTbG92ZW5pYSAoKzM4NilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJTQlwiIHZhbHVlPVwiKzY3N1wiPlxyXG4gICAgICAgICAgU29sb21vbiBJc2xhbmRzICgrNjc3KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlNPXCIgdmFsdWU9XCIrMjUyXCI+XHJcbiAgICAgICAgICBTb21hbGlhICgrMjUyKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdTXCIgdmFsdWU9XCIrNTAwXCI+XHJcbiAgICAgICAgICBTb3V0aCBHZW9yZ2lhIGFuZCB0aGUgU291dGggU2FuZHdpY2ggSXNsYW5kcyAoKzUwMClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJFU1wiIHZhbHVlPVwiKzM0XCI+XHJcbiAgICAgICAgICBTcGFpbiAoKzM0KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkxLXCIgdmFsdWU9XCIrOTRcIj5cclxuICAgICAgICAgIFNyaSBMYW5rYSAoKzk0KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlNIXCIgdmFsdWU9XCIrMjkwXCI+XHJcbiAgICAgICAgICBTYWludCBIZWxlbmEsIEFzY2Vuc2lvbiBhbmQgVHJpc3RhbiBkYSBDdW5oYSAoKzI5MClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJQTVwiIHZhbHVlPVwiKzUwOFwiPlxyXG4gICAgICAgICAgU3QuIFBpZXJyZSBhbmQgTWlxdWVsb24gKCs1MDgpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiU0RcIiB2YWx1ZT1cIisyNDlcIj5cclxuICAgICAgICAgIFN1ZGFuICgrMjQ5KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlNSXCIgdmFsdWU9XCIrNTk3XCI+XHJcbiAgICAgICAgICBTdXJpbmFtZSAoKzU5NylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJTSlwiIHZhbHVlPVwiKzQ3XCI+XHJcbiAgICAgICAgICBTdmFsYmFyZCBhbmQgSmFuIE1heWVuIElzbGFuZHMgKCs0NylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJTWlwiIHZhbHVlPVwiKzI2OFwiPlxyXG4gICAgICAgICAgU3dhemlsYW5kICgrMjY4KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlNFXCIgdmFsdWU9XCIrNDZcIj5cclxuICAgICAgICAgIFN3ZWRlbiAoKzQ2KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkNIXCIgdmFsdWU9XCIrNDFcIj5cclxuICAgICAgICAgIFN3aXR6ZXJsYW5kICgrNDEpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiU1lcIiB2YWx1ZT1cIis5NjNcIj5cclxuICAgICAgICAgIFN5cmlhbiBBcmFiIFJlcHVibGljICgrOTYzKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlRXXCIgdmFsdWU9XCIrODg2XCI+XHJcbiAgICAgICAgICBUYWl3YW4gKCs4ODYpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiVEpcIiB2YWx1ZT1cIis5OTJcIj5cclxuICAgICAgICAgIFRhamlraXN0YW4gKCs5OTIpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiVFpcIiB2YWx1ZT1cIisyNTVcIj5cclxuICAgICAgICAgIFRhbnphbmlhLCBVbml0ZWQgUmVwdWJsaWMgb2YgKCsyNTUpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiVEhcIiB2YWx1ZT1cIis2NlwiPlxyXG4gICAgICAgICAgVGhhaWxhbmQgKCs2NilcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJUR1wiIHZhbHVlPVwiKzIyOFwiPlxyXG4gICAgICAgICAgVG9nbyAoKzIyOClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJUS1wiIHZhbHVlPVwiKzY5MFwiPlxyXG4gICAgICAgICAgVG9rZWxhdSAoKzY5MClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJUT1wiIHZhbHVlPVwiKzY3NlwiPlxyXG4gICAgICAgICAgVG9uZ2EgKCs2NzYpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiVFRcIiB2YWx1ZT1cIisxLTg2OFwiPlxyXG4gICAgICAgICAgVHJpbmlkYWQgYW5kIFRvYmFnbyAoKzEtODY4KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlROXCIgdmFsdWU9XCIrMjE2XCI+XHJcbiAgICAgICAgICBUdW5pc2lhICgrMjE2KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlRSXCIgdmFsdWU9XCIrOTBcIj5cclxuICAgICAgICAgIFR1cmtleSAoKzkwKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlRNXCIgdmFsdWU9XCIrOTkzXCI+XHJcbiAgICAgICAgICBUdXJrbWVuaXN0YW4gKCs5OTMpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiVENcIiB2YWx1ZT1cIisxLTY0OVwiPlxyXG4gICAgICAgICAgVHVya3MgYW5kIENhaWNvcyBJc2xhbmRzICgrMS02NDkpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiVFZcIiB2YWx1ZT1cIis2ODhcIj5cclxuICAgICAgICAgIFR1dmFsdSAoKzY4OClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJVR1wiIHZhbHVlPVwiKzI1NlwiPlxyXG4gICAgICAgICAgVWdhbmRhICgrMjU2KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlVBXCIgdmFsdWU9XCIrMzgwXCI+XHJcbiAgICAgICAgICBVa3JhaW5lICgrMzgwKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdCXCIgdmFsdWU9XCIrNDRcIj5cclxuICAgICAgICAgIFVuaXRlZCBLaW5nZG9tICgrNDQpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiVVNcIiB2YWx1ZT1cIisxXCI+XHJcbiAgICAgICAgICBVbml0ZWQgU3RhdGVzICgrMSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJVTVwiIHZhbHVlPVwiKzI0NlwiPlxyXG4gICAgICAgICAgVW5pdGVkIFN0YXRlcyBNaW5vciBPdXRseWluZyBJc2xhbmRzICgrMjQ2KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlVZXCIgdmFsdWU9XCIrNTk4XCI+XHJcbiAgICAgICAgICBVcnVndWF5ICgrNTk4KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlVaXCIgdmFsdWU9XCIrOTk4XCI+XHJcbiAgICAgICAgICBVemJla2lzdGFuICgrOTk4KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlZVXCIgdmFsdWU9XCIrNjc4XCI+XHJcbiAgICAgICAgICBWYW51YXR1ICgrNjc4KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlZBXCIgdmFsdWU9XCIrMzc5XCI+XHJcbiAgICAgICAgICBWYXRpY2FuIENpdHkgU3RhdGUgKEhvbHkgU2VlKSAoKzM3OSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJWRVwiIHZhbHVlPVwiKzU4XCI+XHJcbiAgICAgICAgICBWZW5lenVlbGEgKCs1OClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJWTlwiIHZhbHVlPVwiKzg0XCI+XHJcbiAgICAgICAgICBWaWV0bmFtICgrODQpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiVkdcIiB2YWx1ZT1cIisxLTI4NFwiPlxyXG4gICAgICAgICAgVmlyZ2luIElzbGFuZHMgKEJyaXRpc2gpICgrMS0yODQpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiVklcIiB2YWx1ZT1cIisxLTM0MFwiPlxyXG4gICAgICAgICAgVmlyZ2luIElzbGFuZHMgKFUuUy4pICgrMS0zNDApXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiV0ZcIiB2YWx1ZT1cIis2ODFcIj5cclxuICAgICAgICAgIFdhbGxpcyBhbmQgRnV0dW5hIElzbGFuZHMgKCs2ODEpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiRUhcIiB2YWx1ZT1cIisyMTJcIj5cclxuICAgICAgICAgIFdlc3Rlcm4gU2FoYXJhICgrMjEyKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIllFXCIgdmFsdWU9XCIrOTY3XCI+XHJcbiAgICAgICAgICBZZW1lbiAoKzk2NylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJSU1wiIHZhbHVlPVwiKzM4MVwiPlxyXG4gICAgICAgICAgU2VyYmlhICgrMzgxKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIlpNXCIgdmFsdWU9XCIrMjYwXCI+XHJcbiAgICAgICAgICBaYW1iaWEgKCsyNjApXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiWldcIiB2YWx1ZT1cIisyNjNcIj5cclxuICAgICAgICAgIFppbWJhYndlICgrMjYzKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkFYXCIgdmFsdWU9XCIrMzU4XCI+XHJcbiAgICAgICAgICBBYWxhbmQgSXNsYW5kcyAoKzM1OClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJQU1wiIHZhbHVlPVwiKzk3MFwiPlxyXG4gICAgICAgICAgUGFsZXN0aW5lICgrOTcwKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIk1FXCIgdmFsdWU9XCIrMzgyXCI+XHJcbiAgICAgICAgICBNb250ZW5lZ3JvICgrMzgyKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkdHXCIgdmFsdWU9XCIrNDQtMTQ4MVwiPlxyXG4gICAgICAgICAgR3Vlcm5zZXkgKCs0NC0xNDgxKVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIklNXCIgdmFsdWU9XCIrNDQtMTYyNFwiPlxyXG4gICAgICAgICAgSXNsZSBvZiBNYW4gKCs0NC0xNjI0KVxyXG4gICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgIDxvcHRpb24gZGF0YS1jb3VudHJ5Y29kZT1cIkpFXCIgdmFsdWU9XCIrNDQtMTUzNFwiPlxyXG4gICAgICAgICAgSmVyc2V5ICgrNDQtMTUzNClcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJDV1wiIHZhbHVlPVwiKzU5OVwiPlxyXG4gICAgICAgICAgQ3VyYcODwqdhbyAoKzU5OSlcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8b3B0aW9uIGRhdGEtY291bnRyeWNvZGU9XCJDSVwiIHZhbHVlPVwiKzIyNVwiPlxyXG4gICAgICAgICAgSXZvcnkgQ29hc3QgKCsyMjUpXHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPG9wdGlvbiBkYXRhLWNvdW50cnljb2RlPVwiWEtcIiB2YWx1ZT1cIiszODNcIj5cclxuICAgICAgICAgIEtvc292byAoKzM4MylcclxuICAgICAgICA8L29wdGlvbj5cclxuICAgICAgPC9vcHRncm91cD5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJztcclxuaW1wb3J0IHsgZ2V0QXBpLCBwb3N0QXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbmZpZy9DdXN0b21BcGlcIjtcclxuaW1wb3J0IHsgRk9STV9JQ09OIH0gZnJvbSBcIi4uLy4uLy4uL2NvbmZpZy9zZXJ2ZXJLZXlcIjtcclxuaW1wb3J0IHsgQ291bnRyeUNvZGUgfSBmcm9tIFwiLi9Db3VudHJ5Q29kZVwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IEZvcm0gPSAoKSA9PiB7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGdldEFwaSgpLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgd2luZG93LnByb2plY3RuYW1lID0gZGF0YS5wcm9qZWN0X25hbWU7XHJcbiAgICAgIHdpbmRvdy5jaXR5ID0gZGF0YS5jaXR5O1xyXG4gICAgfSk7XHJcbiAgfSwgW10pO1xyXG4gIGxldCBpbml0aWFsRGF0YSA9IHtcclxuICAgIG5hbWU6IFwiXCIsXHJcbiAgICBlbWFpbDogXCJcIixcclxuICAgIG51bWJlcjogXCJcIixcclxuICAgIGNvdW50cnljb2RlOiBcIis5MVwiLFxyXG4gICAgbWVzc2FnZTogXCJcIixcclxuICB9O1xyXG5cclxuICBjb25zdCBbZGF0YUZvcm0sIHNldERhdGFGb3JtXSA9IHVzZVN0YXRlKGluaXRpYWxEYXRhKTtcclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgbGV0IG9iaiA9IHt9O1xyXG4gICAgb2JqLnBfdXNlcm5hbWUgPSBkYXRhRm9ybS5uYW1lO1xyXG4gICAgb2JqLnBfbW9iaWxlbnVtYmVyID0gZGF0YUZvcm0ubnVtYmVyO1xyXG4gICAgb2JqLnBfZW1haWwgPSBkYXRhRm9ybS5lbWFpbDtcclxuICAgIG9iai5wX2NvdW50cnljb2RlID0gZGF0YUZvcm0uY291bnRyeWNvZGU7XHJcbiAgICBvYmoucF9tc2cgPSBkYXRhRm9ybS5tZXNzYWdlO1xyXG4gICAgb2JqLnBfbGVhZHR5cGUgPSB3aW5kb3cucHJvamVjdG5hbWU7XHJcbiAgICBvYmoucF9sYXVuY2huYW1lID0gXCJcIjtcclxuICAgIG9iai5wX3NvdXJjZSA9IFwid2Vic2l0ZVwiO1xyXG4gICAgb2JqLnBfY2l0eSA9IHdpbmRvdy5jaXR5O1xyXG4gICAgcG9zdEFwaShvYmopO1xyXG4gICAgcm91dGVyLnB1c2goXCIvdGhhbmt5b3VcIik7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXREYXRhRm9ybSh7IC4uLmRhdGFGb3JtLCBbbmFtZV06IHZhbHVlIH0pO1xyXG4gICAgLy8gY29uc29sZS5sb2coYG5hbWU6ICR7ZS50YXJnZXQubmFtZX0sdmFsdWU6ICR7ZS50YXJnZXQudmFsdWV9YCk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgIDxkaXZcclxuICAgICAgICBjbGFzc05hbWU9XCJtb2RhbCBmYWRlXCJcclxuICAgICAgICBpZD1cIm15bW9kYWxcIlxyXG4gICAgICAgIHRhYkluZGV4PVwiLTFcIlxyXG4gICAgICAgIHJvbGU9XCJkaWFsb2dcIlxyXG4gICAgICAgIGFyaWEtbGFiZWxsZWRieT1cImV4YW1wbGVNb2RhbExhYmVsXCJcclxuICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1kaWFsb2dcIiByb2xlPVwiZG9jdW1lbnRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtY29udGVudFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtb2RhbC10aXRsZVwiPlJlZ2lzdGVyIEhlcmU8L2g1PlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2xvc2VcIlxyXG4gICAgICAgICAgICAgICAgZGF0YS1kaXNtaXNzPVwibW9kYWxcIlxyXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNsb3NlXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj4mdGltZXM7PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBpZD1cImVmb3JtY2RpdlwiPlxyXG4gICAgICAgICAgICAgICAgPGZvcm0gaWQ9XCJkcm9wQW5FbnF1aXJ5XCIgbmFtZT1cImVjZm9ybVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAgcG9zaXRpb24tcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZGFuZ2VyXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICAgIHhtbG5zPXtGT1JNX0lDT059XHJcbiAgICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjI0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjI0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmZWF0aGVyIGZlYXRoZXItdXNlciBmZWEgaWNvbi1zbSBpY29uc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0yMCAyMXYtMmE0IDQgMCAwIDAtNC00SDhhNCA0IDAgMCAwLTQgNHYyXCI+PC9wYXRoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCI3XCIgcj1cIjRcIj48L2NpcmNsZT5cclxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbCBwbC01XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBhdHRlcm49XCJbYS16QS1aIF0rXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG1pbkxlbmd0aD1cIjNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJZb3VyIG5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGF0YUZvcm0ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwIHBvc2l0aW9uLXJlbGF0aXZlXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cCBwb3NpdGlvbi1yZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbD5FbWFpbCBJRCA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICAgIHhtbG5zPXtGT1JNX0lDT059XHJcbiAgICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjI0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjI0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmZWF0aGVyIGZlYXRoZXItbWFpbCBmZWEgaWNvbi1zbSBpY29uc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk00IDRoMTZjMS4xIDAgMiAuOSAyIDJ2MTJjMCAxLjEtLjkgMi0yIDJINGMtMS4xIDAtMi0uOS0yLTJWNmMwLTEuMS45LTIgMi0yelwiPjwvcGF0aD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwb2x5bGluZSBwb2ludHM9XCIyMiw2IDEyLDEzIDIsNlwiPjwvcG9seWxpbmU+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbCBwbC01XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiWW91ciBlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZD1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoYW5nZShlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRhRm9ybS5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwIHBvc2l0aW9uLXJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgWW91ciBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1kYW5nZXJcIj4qPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IG5vLWd1dHRlcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb3VudHJ5Y29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sIGNvdW50cnljb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZD1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkcm9wQW5FbnF1aXJ5X2NvdW50cnljb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoYW5nZShlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGF0YUZvcm0uY291bnRyeWNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENvdW50cnlDb2RlLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLThcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHhtbG5zPXtGT1JNX0lDT059XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCIyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmZWF0aGVyIGZlYXRoZXItYWN0aXZpdHkgcGhvbmVfc3R5bGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0yMiAxNi45MnYzYTIgMiAwIDAgMS0yLjE4IDIgMTkuNzkgMTkuNzkgMCAwIDEtOC42My0zLjA3IDE5LjUgMTkuNSAwIDAgMS02LTYgMTkuNzkgMTkuNzkgMCAwIDEtMy4wNy04LjY3QTIgMiAwIDAgMSA0LjExIDJoM2EyIDIgMCAwIDEgMiAxLjcyIDEyLjg0IDEyLjg0IDAgMCAwIC43IDIuODEgMiAyIDAgMCAxLS40NSAyLjExTDguMDkgOS45MWExNiAxNiAwIDAgMCA2IDZsMS4yNy0xLjI3YTIgMiAwIDAgMSAyLjExLS40NSAxMi44NCAxMi44NCAwIDAgMCAyLjgxLjdBMiAyIDAgMCAxIDIyIDE2LjkyelwiPjwvcGF0aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZHJvcEFuRW5xdWlyeV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbCBwbC01XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIllvdXIgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZD1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RhdGFGb3JtLm51bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwIGZvcm0tcmFkaW8gZmxleGRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibGVmdFwiPlJlcXVlc3QgYSBTaXRlIFZpc2l0PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJhZGlvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1lc3NhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkPVwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoYW5nZShlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGF0YUZvcm0ubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiaGVscGVyXCI+PC9pPlllc1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJhZGlvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1lc3NhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKGUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRhRm9ybS5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJoZWxwZXJcIj48L2k+Tm9cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ1dHRvbi1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidXR0b24gYnRuIGJ0bi1pbmZvIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZVN1Ym1pdChlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZGlzbWlzcz1cIm1vZGFsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdWJtaXRcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuIiwiaW1wb3J0IHsgQmFuZ2Fsb3JlUHJvamVjdCB9IGZyb20gJy4vQmFuZ2Fsb3JlUHJvamVjdCc7XHJcbmltcG9ydCB7IEJhbmdhbG9yZVNsaWRlMiB9IGZyb20gJy4vQmFuZ2Fsb3JlU2xpZGUyJztcclxuaW1wb3J0IHsgQmFubmVyIH0gZnJvbSAnLi9CYW5uZXInO1xyXG5pbXBvcnQgeyBXaHlQcmVzdGlnZSB9IGZyb20gJy4vV2h5UHJlc3RpZ2UnO1xyXG5pbXBvcnQgeyBQcmVzdGlnZVByaW1yb3NlIH0gZnJvbSAnLi9QcmVzdGlnZVByaW1yb3NlJztcclxuaW1wb3J0IHsgSGVhZGVyIH0gZnJvbSAnLi4vSGVhZGVyJztcclxuaW1wb3J0IHsgTW9kYWxGb3JtIH0gZnJvbSAnLi9Nb2RhbEZvcm0nO1xyXG5pbXBvcnQgeyBEcmF3ZXIgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBJY29uQnV0dG9uIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9JY29uQnV0dG9uXCI7XHJcbmltcG9ydCB7IENsb3NlT3V0bGluZWQgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2ljb25zXCI7XHJcbmltcG9ydCB7IEZvcm0gfSBmcm9tICcuL0Zvcm0nO1xyXG5pbXBvcnQgeyBGb290ZXIgfSBmcm9tICcuLi9Gb290ZXInO1xyXG5cclxuIFxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZVBhZ2Uoe2FydGljbGV9KSB7XHJcbiAgY29uc3QgeyBwcmVzdGlnZUJhbmdhbG9yZVBhcmEgfSA9IGFydGljbGUuZmllbGRzO1xyXG4gIGNvbnN0IFtvcGVuRm9ybSwgc2V0T3BlbkZvcm1dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGhhbmRsZURyYXdlckZvcm0gPSAoKSA9PiB7XHJcbiAgICBzZXRPcGVuRm9ybSh0cnVlKTtcclxuICB9O1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgIDxIZWFkZXIgYXJ0aWNsZT17YXJ0aWNsZX0vPlxyXG4gICAgICAgICA8QmFubmVyIGFydGljbGU9e2FydGljbGV9Lz5cclxuICAgICAgICA8c2VjdGlvbiBpZD1cIndoeV9wcmVzdGlnZVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXNlY3Rpb25cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGp1c3RpZnktY29udGVudC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGUgIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0aXRsZSBhYm91dF9jaXJjbGVcIj5cclxuICAgICAgICAgICAgICAgICAgV2h5IENob29zZSBQcmVzdGlnZSBHcm91cFxyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxXaHlQcmVzdGlnZSBhcnRpY2xlPXthcnRpY2xlfSAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNlY3Rpb24gbWItNVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXNlY3Rpb25cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IGp1c3RpZnktY29udGVudC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIj5cclxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0aXRsZSBtYi00XCI+UHJvamVjdHMgaW4gQmFuZ2Fsb3JlPC9oND5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtbC00IG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7cHJlc3RpZ2VCYW5nYWxvcmVQYXJhLmNvbnRlbnRbMF0uY29udGVudFswXS52YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCIgbm8tcGFkZGluZ1wiPlxyXG4gICAgICAgICAgICAgICAgPEJhbmdhbG9yZVByb2plY3QgYXJ0aWNsZT17YXJ0aWNsZX0gLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbGctMTIgbm8tcGFkZGluZyBtdC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8QmFuZ2Fsb3JlU2xpZGUyIGFydGljbGU9e2FydGljbGV9IC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic2VjdGlvbiBtYi01XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItc2VjdGlvblwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cganVzdGlmeS1jb250ZW50LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRpdGxlIG1iLTRcIj5QcmVzdGlnZSBQcmltcm9zZSBIaWxsczwvaDQ+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPFByZXN0aWdlUHJpbXJvc2UgYXJ0aWNsZT17YXJ0aWNsZX0vPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8RHJhd2VyXHJcbiAgICAgICAgYW5jaG9yPVwicmlnaHRcIlxyXG4gICAgICAgIG9wZW49e29wZW5Gb3JtfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgIHNldE9wZW5Gb3JtKGZhbHNlKTtcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjEwMHZoXCIsIHBhZGRpbmc6IFwiMjBweFwiLCB3aWR0aDogXCI1ODBweFwiIH19XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyZWdpc3Rlcl9wYW5lbFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEljb25CdXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldE9wZW5Gb3JtKGZhbHNlKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxyXG4gICAgICAgICAgICAgIHJpZ2h0OiBcIjIwcHhcIixcclxuICAgICAgICAgICAgICB0b3A6IFwiMTBweFwiLFxyXG4gICAgICAgICAgICAgIHpJbmRleDogXCIzXCIsXHJcbiAgICAgICAgICAgICAgY29sb3I6IFwiIzAwMFwiLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8Q2xvc2VPdXRsaW5lZCBjb2xvcj1cInByaW1hcnlcIiAvPlxyXG4gICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgPE1vZGFsRm9ybS8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvRHJhd2VyPlxyXG4gICAgICA8YnV0dG9uXHJcbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiZW5xdWlyZU5vd1Njcm9sbFwiXHJcbiAgICAgICAgZGF0YS1wYW5lbD1cIm1haW5cIlxyXG4gICAgICAgIG9uQ2xpY2s9e2hhbmRsZURyYXdlckZvcm19XHJcbiAgICAgID5cclxuICAgICAgICBSZWdpc3RlciBIZXJlXHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8Rm9ybS8+XHJcbiAgICAgIDxGb290ZXIvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG59XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IENvdW50cnlDb2RlIH0gZnJvbSBcIi4vQ291bnRyeUNvZGVcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xyXG5pbXBvcnQgeyBnZXRBcGksIHBvc3RBcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29uZmlnL0N1c3RvbUFwaVwiO1xyXG5pbXBvcnQgeyBMT0NBVElPTl9JTUcsIE1ZX0xPQ0FUSU9OIH0gZnJvbSBcIi4uLy4uLy4uL2NvbmZpZy9zZXJ2ZXJLZXlcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBNb2RhbEZvcm0gPSAoKSA9PiB7XHJcbiAgbGV0IGluaXRpYWxEYXRhID0ge1xyXG4gICAgbmFtZTogXCJcIixcclxuICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgcGhvbmU6IFwiXCIsXHJcbiAgICBsb2NhdGlvbjogXCJcIixcclxuICAgIGNvdW50cnljb2RlOiBcIis5MVwiLFxyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGdldEFwaSgpLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgd2luZG93LnByb2plY3RuYW1lID0gZGF0YS5wcm9qZWN0X25hbWU7XHJcbiAgICAgIHdpbmRvdy5jaXR5ID0gZGF0YS5jaXR5O1xyXG4gICAgfSk7XHJcbiAgfSwgW10pO1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IFtkYXRhLCBzZXREYXRhXSA9IHVzZVN0YXRlKGluaXRpYWxEYXRhKTtcclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgbGV0IG9iaiA9IHt9O1xyXG4gICAgb2JqLnBfdXNlcm5hbWUgPSBkYXRhLm5hbWU7XHJcbiAgICBvYmoucF9tb2JpbGVudW1iZXIgPSBkYXRhLnBob25lO1xyXG4gICAgb2JqLnBfZW1haWwgPSBkYXRhLmVtYWlsO1xyXG4gICAgb2JqLnBfY291bnRyeWNvZGUgPSBkYXRhLmNvdW50cnljb2RlO1xyXG4gICAgb2JqLnBfbGVhZHR5cGUgPSB3aW5kb3cucHJvamVjdG5hbWU7XHJcbiAgICBvYmoucF9sYXVuY2huYW1lID0gXCJcIjtcclxuICAgIG9iai5wX3NvdXJjZSA9IFwid2Vic2l0ZVwiO1xyXG4gICAgb2JqLnBfY2l0eSA9IHdpbmRvdy5jaXR5O1xyXG4gICAgcG9zdEFwaShvYmopO1xyXG4gICAgcm91dGVyLnB1c2goXCIvdGhhbmt5b3VcIik7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXREYXRhKHsgLi4uZGF0YSwgW25hbWVdOiB2YWx1ZSB9KTtcclxuICAgIC8vIGNvbnNvbGUubG9nKGBuYW1lOiAke2UudGFyZ2V0Lm5hbWV9LHZhbHVlOiAke2UudGFyZ2V0LnZhbHVlfWApXHJcbiAgfTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJcIj5cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJjZC1wYW5lbF9faGVhZGVyXCI+XHJcbiAgICAgICAgPGgxPlxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwiIzk5NjYwMFwiIH19PkVYUFJFU1M8L3NwYW4+IFlvdXIgSW50ZXJlc3QgSGVyZVxyXG4gICAgICAgIDwvaDE+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNkLXBhbmVsX19jb250YWluZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNkLXBhbmVsX19jb250ZW50XCI+XHJcbiAgICAgICAgICA8Zm9ybSBpZD1cInNmb3JtXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5cclxuICAgICAgICAgICAgICAgIFByZWZlcnJlZCBMb2NhdGlvbiA/IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZGFuZ2VyXCI+Kjwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAoQ2xpY2sgdG8gc2VsZWN0KVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYWRpby10aWxlLWdyb3VwIGZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgIHtNWV9MT0NBVElPTi5tYXAoKGl0ZW0sIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbnB1dC1jb250YWluZXJcIiBrZXk9e2l9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyYWRpby1idXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsb2NhdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJhZGlvLXRpbGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaWNvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtMT0NBVElPTl9JTUcgKyBpdGVtICsgXCItaWNvbi5wbmdcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJjaXR5LWljb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIndhbGtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyYWRpby10aWxlLWxhYmVsIHRleHQtY2FwaXRhbGl6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5Zb3VyIE5hbWU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sXCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTmFtZVwiXHJcbiAgICAgICAgICAgICAgICByZXF1aXJlZD1cIlwiXHJcbiAgICAgICAgICAgICAgICBpZD1cInNuYW1lXCJcclxuICAgICAgICAgICAgICAgIHBhdHRlcm49XCJbYS16QS1aIF17NCwzNX1cIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoZSl9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZGF0YS5uYW1lfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+WW91ciBFbWFpbDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sXCJcclxuICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVtYWlsXCJcclxuICAgICAgICAgICAgICAgIHBhdHRlcm49XCJeKFthLXpBLVowLTlfLl17Mix9QFthLXpBLVowLTldezIsfS5bYS16QS1aXXsyLH0oLlthLXpBLVpdezIsM30pPykkXCJcclxuICAgICAgICAgICAgICAgIGlkPVwic2VtYWlsXCJcclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKGUpfVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2RhdGEuZW1haWx9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbD5Zb3VyIE51bWJlcjwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IG5vLWd1dHRlcnNcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb3VudHJ5Y29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sIGNvdW50cnljb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZD1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJzY291bnRyeWNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKGUpfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRhLmNvdW50cnljb2RlfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICA9PENvdW50cnlDb2RlLz5cclxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC04XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGhvbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGhvbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1pbkxlbmd0aD1cIjEwXCJcclxuICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9XCIxNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwic251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGF0dGVybj1cIlswLTldezEwfSRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKGUpfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRhLnBob25lfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ1dHRvbi1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cInNlYXJjaFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidXR0b24gYnRuIGJ0bi1pbmZvIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9XCJTVUJNSVRcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZVN1Ym1pdChlKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG4iLCJpbXBvcnQgZHluYW1pYyBmcm9tICduZXh0L2R5bmFtaWMnO1xyXG5jb25zdCBPd2xDYXJvdXNlbCA9IGR5bmFtaWMoaW1wb3J0KCdyZWFjdC1vd2wtY2Fyb3VzZWwnKSk7XHJcbmltcG9ydCBcIm93bC5jYXJvdXNlbC9kaXN0L2Fzc2V0cy9vd2wuY2Fyb3VzZWwuY3NzXCI7XHJcbmltcG9ydCBcIm93bC5jYXJvdXNlbC9kaXN0L2Fzc2V0cy9vd2wudGhlbWUuZGVmYXVsdC5jc3NcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBQcmVzdGlnZVByaW1yb3NlID0gKHsgYXJ0aWNsZSB9KSA9PiB7XHJcbiAgY29uc3Qgc3RhdGUgPSB7XHJcbiAgICByZXNwb25zaXZlOiB7XHJcbiAgICAgIDA6IHtcclxuICAgICAgICBpdGVtczogMSxcclxuICAgICAgfSxcclxuICAgICAgNDUwOiB7XHJcbiAgICAgICAgaXRlbXM6IDIsXHJcbiAgICAgIH0sXHJcbiAgICAgIDYwMDoge1xyXG4gICAgICAgIGl0ZW1zOiAzLFxyXG4gICAgICB9LFxyXG4gICAgICAxMDAwOiB7XHJcbiAgICAgICAgaXRlbXM6IDMsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIH07XHJcbiAgY29uc3QgeyBwcmVzdGlnZVByaW1yb3NlIH0gPSBhcnRpY2xlLmZpZWxkcztcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cclxuICAgICAgICA8T3dsQ2Fyb3VzZWxcclxuICAgICAgICAgIGl0ZW1zPXszfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwib3dsLXRoZW1lXCJcclxuICAgICAgICAgIGxvb3BcclxuICAgICAgICAgIG5hdlxyXG4gICAgICAgICAgbWFyZ2luPXsyMH1cclxuICAgICAgICAgIHJlc3BvbnNpdmU9e3N0YXRlLnJlc3BvbnNpdmV9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3ByZXN0aWdlUHJpbXJvc2UubWFwKChpdGVtLCBpKSA9PiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYXJkIGJvcmRlci0wIHdvcmstY29udGFpbmVyIHdvcmstZ3JpZCBwb3NpdGlvbi1yZWxhdGl2ZSBkLWJsb2NrXCJcclxuICAgICAgICAgICAgICBrZXk9e2l9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keSBwLTBcIj5cclxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIvI1wiPlxyXG4gICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgc3JjPXtwcmVzdGlnZVByaW1yb3NlW2ldPy5maWVsZHM/LmZpbGU/LnVybH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbWctZmx1aWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGFsdD17cHJlc3RpZ2VQcmltcm9zZVtpXT8uZmllbGRzPy50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGVudCBiZy13aGl0ZSBwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cIm1iLTAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiLyNcIj5HZXQgTmV3IExhdW5jaCBQcm9qZWN0IERldGFpbHMgPC9hPlxyXG4gICAgICAgICAgICAgICAgICA8L2g1PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBvc3QtbWV0YSBkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiLyNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi1zbSBidG4taW5mbyBidG4xXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdG9nZ2xlPVwibW9kYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YS10YXJnZXQ9XCIjbXltb2RhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ2xpY2sgVG8gS25vdyBNb3JlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkX21vcmUgcHN0YXR1cyB0ZXh0LWNlbnRlciByb3VuZGVkLWNpcmNsZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdGF0dXNsX05ld1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwcmVzdGlnZVByaW1yb3NlW2ldPy5maWVsZHM/LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L093bENhcm91c2VsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGR5bmFtaWMgZnJvbSAnbmV4dC9keW5hbWljJztcclxuY29uc3QgT3dsQ2Fyb3VzZWwgPSBkeW5hbWljKGltcG9ydCgncmVhY3Qtb3dsLWNhcm91c2VsJykpO1xyXG5pbXBvcnQgXCJvd2wuY2Fyb3VzZWwvZGlzdC9hc3NldHMvb3dsLmNhcm91c2VsLmNzc1wiO1xyXG5pbXBvcnQgXCJvd2wuY2Fyb3VzZWwvZGlzdC9hc3NldHMvb3dsLnRoZW1lLmRlZmF1bHQuY3NzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgV2h5UHJlc3RpZ2UgPSAoe2FydGljbGV9KSA9PiB7XHJcbiAgICBjb25zdCBzdGF0ZSA9IHtcclxuICAgICAgICByZXNwb25zaXZlOiB7XHJcbiAgICAgICAgICAwOiB7XHJcbiAgICAgICAgICAgIGl0ZW1zOiAxLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIDQ1MDoge1xyXG4gICAgICAgICAgICBpdGVtczogMixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICA2MDA6IHtcclxuICAgICAgICAgICAgaXRlbXM6IDMsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgMTAwMDoge1xyXG4gICAgICAgICAgICBpdGVtczogMyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgfTtcclxuICAgIGNvbnN0IHt3aHlQcmVzdGlnZX09YXJ0aWNsZS5maWVsZHM7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgPE93bENhcm91c2VsXHJcbiAgICAgICAgICBpdGVtcz17M31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cIm93bC10aGVtZVwiXHJcbiAgICAgICAgICBsb29wXHJcbiAgICAgICAgICBuYXZcclxuICAgICAgICAgIG1hcmdpbj17MjB9XHJcbiAgICAgICAgICByZXNwb25zaXZlPXtzdGF0ZS5yZXNwb25zaXZlfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHt3aHlQcmVzdGlnZS5tYXAoKGl0ZW0sIGkpID0+IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJQcm9qZWN0UGFydCBjYXJkIGJvcmRlci0wIHdvcmstY29udGFpbmVyIHdvcmstZ3JpZCBwb3NpdGlvbi1yZWxhdGl2ZSBkLWJsb2NrXCIga2V5PXtpfT5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keSBwLTBcIj5cclxuICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW1nLWZsdWlkXCJcclxuICAgICAgICAgICAgICAgICAgc3JjPXt3aHlQcmVzdGlnZVtpXS5maWVsZHMuZmlsZS51cmx9XHJcbiAgICAgICAgICAgICAgICAgIGFsdD17d2h5UHJlc3RpZ2VbaV0uZmllbGRzLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGVudDEgYmctd2hpdGUgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtYi00IHRpdGxlXCI+e3doeVByZXN0aWdlW2ldLmZpZWxkcy50aXRsZX08L2g1PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9Pd2xDYXJvdXNlbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG4iLCJpbXBvcnQgeyBBUElfVVJMLCBHRVRfREFUQV9BUEkgfSBmcm9tIFwiLi9zZXJ2ZXJLZXlcIjtcclxuXHJcblxyXG5jb25zdCBnZXRBcGkgPSBhc3luYyAoKSA9PiB7XHJcbiAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goQVBJX1VSTCArIEdFVF9EQVRBX0FQSSlcclxuICBjb25zdCBqc29uID0gYXdhaXQgcmVzLmpzb24oKVxyXG4gIHJldHVybiBqc29uLnJlc3VsdFxyXG59XHJcblxyXG5jb25zdCBwb3N0QXBpID0gYXN5bmMgKGJvZHkpID0+IHtcclxuIGF3YWl0IGZldGNoKEFQSV9VUkwgKyBcImxlYWRzXCIsIHtcclxuICAgIG1ldGhvZDogXCJwb3N0XCIsXHJcbiAgICBoZWFkZXJzOiB7XHJcbiAgICAgIFwiY29udGVudC10eXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gICAgfSxcclxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpLFxyXG4gIH0pLnRoZW4oKHJlc3VsdCkgPT4ge1xyXG4gICAgcmVzdWx0Lmpzb24oKS50aGVuKChyZXNwKSA9PiB7XHJcbiAgICB9KTtcclxuICB9KTtcclxufTtcclxuXHJcbmV4cG9ydCB7IGdldEFwaSxwb3N0QXBpIH07XHJcbiIsImNvbnN0IFNUQVRJQ19QSE9ORT0nMDc0MTE3ODI0MDYnO1xyXG5jb25zdCBBUElfVVJMPVwiaHR0cHM6Ly93d3cubXlob21lc2Z5LmNvbS9hcGkvXCI7XHJcbmNvbnN0IExPQ0FUSU9OX0lNRz1cImh0dHBzOi8vd3d3LnByZXN0aWdlY29uc3RydWN0aW9ucy5jb20vaW1hZ2VzL2NpdHkvXCI7XHJcbmNvbnN0IEZPUk1fSUNPTj1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI7XHJcbmNvbnN0IE1ZX0xPQ0FUSU9OPVsgXCJiYW5nYWxvcmVcIixcImNoZW5uYWlcIixcImh5ZGVyYWJhZFwiLFwia29jaGlcIixcIm1hbmdhbG9yZVwiLF1cclxuY29uc3QgUFJPSkVDVF9MT0dPPVwiaHR0cHM6Ly93d3cucHJlc3RpZ2Vjb25zdHJ1Y3Rpb25zLmNvbS9pbWFnZXMvbG9nby5wbmdcIjtcclxuY29uc3QgR0VUX0RBVEFfQVBJPVwibGVhZHMvcHJvamVjdGRhdGEvMTI2MFwiO1xyXG5jb25zdCAgSE9NRVNGWV9MT0dPPVwiaHR0cHM6Ly9yZWZyYW5jZS5zMy5hcC1zb3V0aC0xLmFtYXpvbmF3cy5jb20vSG9tZXNmeUxvZ28ucG5nXCI7XHJcbmNvbnN0IEhPTUVTRllfVVJMPVwiaHR0cHM6Ly93d3cuaG9tZXNmeS5pbi9cIjtcclxuY29uc3QgSE9NRVNGWV9GQUNFQk9PSz1cImh0dHBzOi8vd3d3LmZhY2Vib29rLmNvbS9ob21lc2Z5XCI7XHJcbmNvbnN0IEhPTUVTRllfSU5TVEFHUkFNPVwiaHR0cHM6Ly9pbnN0YWdyYW0uY29tL2hvbWVzZnlpbmRpYT9pZ3NoaWQ9MWh1YTg5bTlweTB1ZVwiO1xyXG5leHBvcnQge1NUQVRJQ19QSE9ORSwgQVBJX1VSTCxMT0NBVElPTl9JTUcsRk9STV9JQ09OLFxyXG4gICAgTVlfTE9DQVRJT04sUFJPSkVDVF9MT0dPLEdFVF9EQVRBX0FQSSxIT01FU0ZZX0xPR08sSE9NRVNGWV9VUkwsSE9NRVNGWV9GQUNFQk9PSyxIT01FU0ZZX0lOU1RBR1JBTX1cclxuIiwiZnVuY3Rpb24gX2V4dGVuZHMoKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uICh0YXJnZXQpIHtcbiAgICBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXTtcblxuICAgICAgZm9yICh2YXIga2V5IGluIHNvdXJjZSkge1xuICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHNvdXJjZSwga2V5KSkge1xuICAgICAgICAgIHRhcmdldFtrZXldID0gc291cmNlW2tleV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9O1xuXG4gIHJldHVybiBfZXh0ZW5kcy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9leHRlbmRzOyIsImZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgXCJkZWZhdWx0XCI6IG9ialxuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQ7IiwiZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCkge1xuICBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTtcbiAgdmFyIHRhcmdldCA9IHt9O1xuICB2YXIgc291cmNlS2V5cyA9IE9iamVjdC5rZXlzKHNvdXJjZSk7XG4gIHZhciBrZXksIGk7XG5cbiAgZm9yIChpID0gMDsgaSA8IHNvdXJjZUtleXMubGVuZ3RoOyBpKyspIHtcbiAgICBrZXkgPSBzb3VyY2VLZXlzW2ldO1xuICAgIGlmIChleGNsdWRlZC5pbmRleE9mKGtleSkgPj0gMCkgY29udGludWU7XG4gICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgfVxuXG4gIHJldHVybiB0YXJnZXQ7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2U7IiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEhlYWQgZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL2hlYWQnXG5pbXBvcnQgeyB0b0Jhc2U2NCB9IGZyb20gJy4uL25leHQtc2VydmVyL2xpYi90by1iYXNlLTY0J1xuaW1wb3J0IHtcbiAgSW1hZ2VDb25maWcsXG4gIGltYWdlQ29uZmlnRGVmYXVsdCxcbiAgTG9hZGVyVmFsdWUsXG4gIFZBTElEX0xPQURFUlMsXG59IGZyb20gJy4uL25leHQtc2VydmVyL3NlcnZlci9pbWFnZS1jb25maWcnXG5pbXBvcnQgeyB1c2VJbnRlcnNlY3Rpb24gfSBmcm9tICcuL3VzZS1pbnRlcnNlY3Rpb24nXG5cbmlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykge1xuICA7KGdsb2JhbCBhcyBhbnkpLl9fTkVYVF9JTUFHRV9JTVBPUlRFRCA9IHRydWVcbn1cblxuY29uc3QgVkFMSURfTE9BRElOR19WQUxVRVMgPSBbJ2xhenknLCAnZWFnZXInLCB1bmRlZmluZWRdIGFzIGNvbnN0XG50eXBlIExvYWRpbmdWYWx1ZSA9IHR5cGVvZiBWQUxJRF9MT0FESU5HX1ZBTFVFU1tudW1iZXJdXG5cbmV4cG9ydCB0eXBlIEltYWdlTG9hZGVyID0gKHJlc29sdmVyUHJvcHM6IEltYWdlTG9hZGVyUHJvcHMpID0+IHN0cmluZ1xuXG5leHBvcnQgdHlwZSBJbWFnZUxvYWRlclByb3BzID0ge1xuICBzcmM6IHN0cmluZ1xuICB3aWR0aDogbnVtYmVyXG4gIHF1YWxpdHk/OiBudW1iZXJcbn1cblxudHlwZSBEZWZhdWx0SW1hZ2VMb2FkZXJQcm9wcyA9IEltYWdlTG9hZGVyUHJvcHMgJiB7IHJvb3Q6IHN0cmluZyB9XG5cbmNvbnN0IGxvYWRlcnMgPSBuZXcgTWFwPFxuICBMb2FkZXJWYWx1ZSxcbiAgKHByb3BzOiBEZWZhdWx0SW1hZ2VMb2FkZXJQcm9wcykgPT4gc3RyaW5nXG4+KFtcbiAgWydpbWdpeCcsIGltZ2l4TG9hZGVyXSxcbiAgWydjbG91ZGluYXJ5JywgY2xvdWRpbmFyeUxvYWRlcl0sXG4gIFsnYWthbWFpJywgYWthbWFpTG9hZGVyXSxcbiAgWydkZWZhdWx0JywgZGVmYXVsdExvYWRlcl0sXG5dKVxuXG5jb25zdCBWQUxJRF9MQVlPVVRfVkFMVUVTID0gW1xuICAnZmlsbCcsXG4gICdmaXhlZCcsXG4gICdpbnRyaW5zaWMnLFxuICAncmVzcG9uc2l2ZScsXG4gIHVuZGVmaW5lZCxcbl0gYXMgY29uc3RcbnR5cGUgTGF5b3V0VmFsdWUgPSB0eXBlb2YgVkFMSURfTEFZT1VUX1ZBTFVFU1tudW1iZXJdXG5cbnR5cGUgUGxhY2Vob2xkZXJWYWx1ZSA9ICdibHVyJyB8ICdlbXB0eSdcblxudHlwZSBJbWdFbGVtZW50U3R5bGUgPSBOb25OdWxsYWJsZTxKU1guSW50cmluc2ljRWxlbWVudHNbJ2ltZyddWydzdHlsZSddPlxuXG5leHBvcnQgdHlwZSBJbWFnZVByb3BzID0gT21pdDxcbiAgSlNYLkludHJpbnNpY0VsZW1lbnRzWydpbWcnXSxcbiAgJ3NyYycgfCAnc3JjU2V0JyB8ICdyZWYnIHwgJ3dpZHRoJyB8ICdoZWlnaHQnIHwgJ2xvYWRpbmcnIHwgJ3N0eWxlJ1xuPiAmIHtcbiAgc3JjOiBzdHJpbmdcbiAgbG9hZGVyPzogSW1hZ2VMb2FkZXJcbiAgcXVhbGl0eT86IG51bWJlciB8IHN0cmluZ1xuICBwcmlvcml0eT86IGJvb2xlYW5cbiAgbG9hZGluZz86IExvYWRpbmdWYWx1ZVxuICB1bm9wdGltaXplZD86IGJvb2xlYW5cbiAgb2JqZWN0Rml0PzogSW1nRWxlbWVudFN0eWxlWydvYmplY3RGaXQnXVxuICBvYmplY3RQb3NpdGlvbj86IEltZ0VsZW1lbnRTdHlsZVsnb2JqZWN0UG9zaXRpb24nXVxufSAmIChcbiAgICB8IHtcbiAgICAgICAgd2lkdGg/OiBuZXZlclxuICAgICAgICBoZWlnaHQ/OiBuZXZlclxuICAgICAgICAvKiogQGRlcHJlY2F0ZWQgVXNlIGBsYXlvdXQ9XCJmaWxsXCJgIGluc3RlYWQgKi9cbiAgICAgICAgdW5zaXplZDogdHJ1ZVxuICAgICAgfVxuICAgIHwgeyB3aWR0aD86IG5ldmVyOyBoZWlnaHQ/OiBuZXZlcjsgbGF5b3V0OiAnZmlsbCcgfVxuICAgIHwge1xuICAgICAgICB3aWR0aDogbnVtYmVyIHwgc3RyaW5nXG4gICAgICAgIGhlaWdodDogbnVtYmVyIHwgc3RyaW5nXG4gICAgICAgIGxheW91dD86IEV4Y2x1ZGU8TGF5b3V0VmFsdWUsICdmaWxsJz5cbiAgICAgIH1cbiAgKSAmXG4gIChcbiAgICB8IHtcbiAgICAgICAgcGxhY2Vob2xkZXI/OiBFeGNsdWRlPFBsYWNlaG9sZGVyVmFsdWUsICdibHVyJz5cbiAgICAgICAgYmx1ckRhdGFVUkw/OiBuZXZlclxuICAgICAgfVxuICAgIHwgeyBwbGFjZWhvbGRlcjogJ2JsdXInOyBibHVyRGF0YVVSTDogc3RyaW5nIH1cbiAgKVxuXG5jb25zdCB7XG4gIGRldmljZVNpemVzOiBjb25maWdEZXZpY2VTaXplcyxcbiAgaW1hZ2VTaXplczogY29uZmlnSW1hZ2VTaXplcyxcbiAgbG9hZGVyOiBjb25maWdMb2FkZXIsXG4gIHBhdGg6IGNvbmZpZ1BhdGgsXG4gIGRvbWFpbnM6IGNvbmZpZ0RvbWFpbnMsXG4gIGVuYWJsZUJsdXJyeVBsYWNlaG9sZGVyOiBjb25maWdFbmFibGVCbHVycnlQbGFjZWhvbGRlcixcbn0gPVxuICAoKHByb2Nlc3MuZW52Ll9fTkVYVF9JTUFHRV9PUFRTIGFzIGFueSkgYXMgSW1hZ2VDb25maWcpIHx8IGltYWdlQ29uZmlnRGVmYXVsdFxuLy8gc29ydCBzbWFsbGVzdCB0byBsYXJnZXN0XG5jb25zdCBhbGxTaXplcyA9IFsuLi5jb25maWdEZXZpY2VTaXplcywgLi4uY29uZmlnSW1hZ2VTaXplc11cbmNvbmZpZ0RldmljZVNpemVzLnNvcnQoKGEsIGIpID0+IGEgLSBiKVxuYWxsU2l6ZXMuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cbmZ1bmN0aW9uIGdldFdpZHRocyhcbiAgd2lkdGg6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgbGF5b3V0OiBMYXlvdXRWYWx1ZSxcbiAgc2l6ZXM6IHN0cmluZyB8IHVuZGVmaW5lZFxuKTogeyB3aWR0aHM6IG51bWJlcltdOyBraW5kOiAndycgfCAneCcgfSB7XG4gIGlmIChzaXplcyAmJiAobGF5b3V0ID09PSAnZmlsbCcgfHwgbGF5b3V0ID09PSAncmVzcG9uc2l2ZScpKSB7XG4gICAgLy8gRmluZCBhbGwgdGhlIFwidndcIiBwZXJjZW50IHNpemVzIHVzZWQgaW4gdGhlIHNpemVzIHByb3BcbiAgICBjb25zdCB2aWV3cG9ydFdpZHRoUmUgPSAvKF58XFxzKSgxP1xcZD9cXGQpdncvZ1xuICAgIGNvbnN0IHBlcmNlbnRTaXplcyA9IFtdXG4gICAgZm9yIChsZXQgbWF0Y2g7IChtYXRjaCA9IHZpZXdwb3J0V2lkdGhSZS5leGVjKHNpemVzKSk7IG1hdGNoKSB7XG4gICAgICBwZXJjZW50U2l6ZXMucHVzaChwYXJzZUludChtYXRjaFsyXSkpXG4gICAgfVxuICAgIGlmIChwZXJjZW50U2l6ZXMubGVuZ3RoKSB7XG4gICAgICBjb25zdCBzbWFsbGVzdFJhdGlvID0gTWF0aC5taW4oLi4ucGVyY2VudFNpemVzKSAqIDAuMDFcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHdpZHRoczogYWxsU2l6ZXMuZmlsdGVyKFxuICAgICAgICAgIChzKSA9PiBzID49IGNvbmZpZ0RldmljZVNpemVzWzBdICogc21hbGxlc3RSYXRpb1xuICAgICAgICApLFxuICAgICAgICBraW5kOiAndycsXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7IHdpZHRoczogYWxsU2l6ZXMsIGtpbmQ6ICd3JyB9XG4gIH1cbiAgaWYgKFxuICAgIHR5cGVvZiB3aWR0aCAhPT0gJ251bWJlcicgfHxcbiAgICBsYXlvdXQgPT09ICdmaWxsJyB8fFxuICAgIGxheW91dCA9PT0gJ3Jlc3BvbnNpdmUnXG4gICkge1xuICAgIHJldHVybiB7IHdpZHRoczogY29uZmlnRGV2aWNlU2l6ZXMsIGtpbmQ6ICd3JyB9XG4gIH1cblxuICBjb25zdCB3aWR0aHMgPSBbXG4gICAgLi4ubmV3IFNldChcbiAgICAgIC8vID4gVGhpcyBtZWFucyB0aGF0IG1vc3QgT0xFRCBzY3JlZW5zIHRoYXQgc2F5IHRoZXkgYXJlIDN4IHJlc29sdXRpb24sXG4gICAgICAvLyA+IGFyZSBhY3R1YWxseSAzeCBpbiB0aGUgZ3JlZW4gY29sb3IsIGJ1dCBvbmx5IDEuNXggaW4gdGhlIHJlZCBhbmRcbiAgICAgIC8vID4gYmx1ZSBjb2xvcnMuIFNob3dpbmcgYSAzeCByZXNvbHV0aW9uIGltYWdlIGluIHRoZSBhcHAgdnMgYSAyeFxuICAgICAgLy8gPiByZXNvbHV0aW9uIGltYWdlIHdpbGwgYmUgdmlzdWFsbHkgdGhlIHNhbWUsIHRob3VnaCB0aGUgM3ggaW1hZ2VcbiAgICAgIC8vID4gdGFrZXMgc2lnbmlmaWNhbnRseSBtb3JlIGRhdGEuIEV2ZW4gdHJ1ZSAzeCByZXNvbHV0aW9uIHNjcmVlbnMgYXJlXG4gICAgICAvLyA+IHdhc3RlZnVsIGFzIHRoZSBodW1hbiBleWUgY2Fubm90IHNlZSB0aGF0IGxldmVsIG9mIGRldGFpbCB3aXRob3V0XG4gICAgICAvLyA+IHNvbWV0aGluZyBsaWtlIGEgbWFnbmlmeWluZyBnbGFzcy5cbiAgICAgIC8vIGh0dHBzOi8vYmxvZy50d2l0dGVyLmNvbS9lbmdpbmVlcmluZy9lbl91cy90b3BpY3MvaW5mcmFzdHJ1Y3R1cmUvMjAxOS9jYXBwaW5nLWltYWdlLWZpZGVsaXR5LW9uLXVsdHJhLWhpZ2gtcmVzb2x1dGlvbi1kZXZpY2VzLmh0bWxcbiAgICAgIFt3aWR0aCwgd2lkdGggKiAyIC8qLCB3aWR0aCAqIDMqL10ubWFwKFxuICAgICAgICAodykgPT4gYWxsU2l6ZXMuZmluZCgocCkgPT4gcCA+PSB3KSB8fCBhbGxTaXplc1thbGxTaXplcy5sZW5ndGggLSAxXVxuICAgICAgKVxuICAgICksXG4gIF1cbiAgcmV0dXJuIHsgd2lkdGhzLCBraW5kOiAneCcgfVxufVxuXG50eXBlIEdlbkltZ0F0dHJzRGF0YSA9IHtcbiAgc3JjOiBzdHJpbmdcbiAgdW5vcHRpbWl6ZWQ6IGJvb2xlYW5cbiAgbGF5b3V0OiBMYXlvdXRWYWx1ZVxuICBsb2FkZXI6IEltYWdlTG9hZGVyXG4gIHdpZHRoPzogbnVtYmVyXG4gIHF1YWxpdHk/OiBudW1iZXJcbiAgc2l6ZXM/OiBzdHJpbmdcbn1cblxudHlwZSBHZW5JbWdBdHRyc1Jlc3VsdCA9IHtcbiAgc3JjOiBzdHJpbmdcbiAgc3JjU2V0OiBzdHJpbmcgfCB1bmRlZmluZWRcbiAgc2l6ZXM6IHN0cmluZyB8IHVuZGVmaW5lZFxufVxuXG5mdW5jdGlvbiBnZW5lcmF0ZUltZ0F0dHJzKHtcbiAgc3JjLFxuICB1bm9wdGltaXplZCxcbiAgbGF5b3V0LFxuICB3aWR0aCxcbiAgcXVhbGl0eSxcbiAgc2l6ZXMsXG4gIGxvYWRlcixcbn06IEdlbkltZ0F0dHJzRGF0YSk6IEdlbkltZ0F0dHJzUmVzdWx0IHtcbiAgaWYgKHVub3B0aW1pemVkKSB7XG4gICAgcmV0dXJuIHsgc3JjLCBzcmNTZXQ6IHVuZGVmaW5lZCwgc2l6ZXM6IHVuZGVmaW5lZCB9XG4gIH1cblxuICBjb25zdCB7IHdpZHRocywga2luZCB9ID0gZ2V0V2lkdGhzKHdpZHRoLCBsYXlvdXQsIHNpemVzKVxuICBjb25zdCBsYXN0ID0gd2lkdGhzLmxlbmd0aCAtIDFcblxuICByZXR1cm4ge1xuICAgIHNpemVzOiAhc2l6ZXMgJiYga2luZCA9PT0gJ3cnID8gJzEwMHZ3JyA6IHNpemVzLFxuICAgIHNyY1NldDogd2lkdGhzXG4gICAgICAubWFwKFxuICAgICAgICAodywgaSkgPT5cbiAgICAgICAgICBgJHtsb2FkZXIoeyBzcmMsIHF1YWxpdHksIHdpZHRoOiB3IH0pfSAke1xuICAgICAgICAgICAga2luZCA9PT0gJ3cnID8gdyA6IGkgKyAxXG4gICAgICAgICAgfSR7a2luZH1gXG4gICAgICApXG4gICAgICAuam9pbignLCAnKSxcblxuICAgIC8vIEl0J3MgaW50ZW5kZWQgdG8ga2VlcCBgc3JjYCB0aGUgbGFzdCBhdHRyaWJ1dGUgYmVjYXVzZSBSZWFjdCB1cGRhdGVzXG4gICAgLy8gYXR0cmlidXRlcyBpbiBvcmRlci4gSWYgd2Uga2VlcCBgc3JjYCB0aGUgZmlyc3Qgb25lLCBTYWZhcmkgd2lsbFxuICAgIC8vIGltbWVkaWF0ZWx5IHN0YXJ0IHRvIGZldGNoIGBzcmNgLCBiZWZvcmUgYHNpemVzYCBhbmQgYHNyY1NldGAgYXJlIGV2ZW5cbiAgICAvLyB1cGRhdGVkIGJ5IFJlYWN0LiBUaGF0IGNhdXNlcyBtdWx0aXBsZSB1bm5lY2Vzc2FyeSByZXF1ZXN0cyBpZiBgc3JjU2V0YFxuICAgIC8vIGFuZCBgc2l6ZXNgIGFyZSBkZWZpbmVkLlxuICAgIC8vIFRoaXMgYnVnIGNhbm5vdCBiZSByZXByb2R1Y2VkIGluIENocm9tZSBvciBGaXJlZm94LlxuICAgIHNyYzogbG9hZGVyKHsgc3JjLCBxdWFsaXR5LCB3aWR0aDogd2lkdGhzW2xhc3RdIH0pLFxuICB9XG59XG5cbmZ1bmN0aW9uIGdldEludCh4OiB1bmtub3duKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcbiAgaWYgKHR5cGVvZiB4ID09PSAnbnVtYmVyJykge1xuICAgIHJldHVybiB4XG4gIH1cbiAgaWYgKHR5cGVvZiB4ID09PSAnc3RyaW5nJykge1xuICAgIHJldHVybiBwYXJzZUludCh4LCAxMClcbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkXG59XG5cbmZ1bmN0aW9uIGRlZmF1bHRJbWFnZUxvYWRlcihsb2FkZXJQcm9wczogSW1hZ2VMb2FkZXJQcm9wcykge1xuICBjb25zdCBsb2FkID0gbG9hZGVycy5nZXQoY29uZmlnTG9hZGVyKVxuICBpZiAobG9hZCkge1xuICAgIHJldHVybiBsb2FkKHsgcm9vdDogY29uZmlnUGF0aCwgLi4ubG9hZGVyUHJvcHMgfSlcbiAgfVxuICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgYFVua25vd24gXCJsb2FkZXJcIiBmb3VuZCBpbiBcIm5leHQuY29uZmlnLmpzXCIuIEV4cGVjdGVkOiAke1ZBTElEX0xPQURFUlMuam9pbihcbiAgICAgICcsICdcbiAgICApfS4gUmVjZWl2ZWQ6ICR7Y29uZmlnTG9hZGVyfWBcbiAgKVxufVxuXG4vLyBTZWUgaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xLzM5Nzc3ODMzLzI2NjUzNSBmb3Igd2h5IHdlIHVzZSB0aGlzIHJlZlxuLy8gaGFuZGxlciBpbnN0ZWFkIG9mIHRoZSBpbWcncyBvbkxvYWQgYXR0cmlidXRlLlxuZnVuY3Rpb24gcmVtb3ZlUGxhY2Vob2xkZXIoXG4gIGVsZW1lbnQ6IEhUTUxJbWFnZUVsZW1lbnQgfCBudWxsLFxuICBwbGFjZWhvbGRlcjogUGxhY2Vob2xkZXJWYWx1ZVxuKSB7XG4gIGlmIChwbGFjZWhvbGRlciA9PT0gJ2JsdXInICYmIGVsZW1lbnQpIHtcbiAgICBpZiAoZWxlbWVudC5jb21wbGV0ZSkge1xuICAgICAgLy8gSWYgdGhlIHJlYWwgaW1hZ2UgZmFpbHMgdG8gbG9hZCwgdGhpcyB3aWxsIHN0aWxsIHJlbW92ZSB0aGUgcGxhY2Vob2xkZXIuXG4gICAgICAvLyBUaGlzIGlzIHRoZSBkZXNpcmVkIGJlaGF2aW9yIGZvciBub3csIGFuZCB3aWxsIGJlIHJldmlzaXRlZCB3aGVuIGVycm9yXG4gICAgICAvLyBoYW5kbGluZyBpcyB3b3JrZWQgb24gZm9yIHRoZSBpbWFnZSBjb21wb25lbnQgaXRzZWxmLlxuICAgICAgZWxlbWVudC5zdHlsZS5iYWNrZ3JvdW5kSW1hZ2UgPSAnbm9uZSdcbiAgICB9IGVsc2Uge1xuICAgICAgZWxlbWVudC5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUuYmFja2dyb3VuZEltYWdlID0gJ25vbmUnXG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEltYWdlKHtcbiAgc3JjLFxuICBzaXplcyxcbiAgdW5vcHRpbWl6ZWQgPSBmYWxzZSxcbiAgcHJpb3JpdHkgPSBmYWxzZSxcbiAgbG9hZGluZyxcbiAgY2xhc3NOYW1lLFxuICBxdWFsaXR5LFxuICB3aWR0aCxcbiAgaGVpZ2h0LFxuICBvYmplY3RGaXQsXG4gIG9iamVjdFBvc2l0aW9uLFxuICBsb2FkZXIgPSBkZWZhdWx0SW1hZ2VMb2FkZXIsXG4gIHBsYWNlaG9sZGVyID0gJ2VtcHR5JyxcbiAgYmx1ckRhdGFVUkwsXG4gIC4uLmFsbFxufTogSW1hZ2VQcm9wcykge1xuICBsZXQgcmVzdDogUGFydGlhbDxJbWFnZVByb3BzPiA9IGFsbFxuICBsZXQgbGF5b3V0OiBOb25OdWxsYWJsZTxMYXlvdXRWYWx1ZT4gPSBzaXplcyA/ICdyZXNwb25zaXZlJyA6ICdpbnRyaW5zaWMnXG4gIGxldCB1bnNpemVkID0gZmFsc2VcbiAgaWYgKCd1bnNpemVkJyBpbiByZXN0KSB7XG4gICAgdW5zaXplZCA9IEJvb2xlYW4ocmVzdC51bnNpemVkKVxuICAgIC8vIFJlbW92ZSBwcm9wZXJ0eSBzbyBpdCdzIG5vdCBzcHJlYWQgaW50byBpbWFnZTpcbiAgICBkZWxldGUgcmVzdFsndW5zaXplZCddXG4gIH0gZWxzZSBpZiAoJ2xheW91dCcgaW4gcmVzdCkge1xuICAgIC8vIE92ZXJyaWRlIGRlZmF1bHQgbGF5b3V0IGlmIHRoZSB1c2VyIHNwZWNpZmllZCBvbmU6XG4gICAgaWYgKHJlc3QubGF5b3V0KSBsYXlvdXQgPSByZXN0LmxheW91dFxuXG4gICAgLy8gUmVtb3ZlIHByb3BlcnR5IHNvIGl0J3Mgbm90IHNwcmVhZCBpbnRvIGltYWdlOlxuICAgIGRlbGV0ZSByZXN0WydsYXlvdXQnXVxuICB9XG5cbiAgaWYgKCFjb25maWdFbmFibGVCbHVycnlQbGFjZWhvbGRlcikge1xuICAgIHBsYWNlaG9sZGVyID0gJ2VtcHR5J1xuICB9XG5cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBpZiAoIXNyYykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2UgaXMgbWlzc2luZyByZXF1aXJlZCBcInNyY1wiIHByb3BlcnR5LiBNYWtlIHN1cmUgeW91IHBhc3MgXCJzcmNcIiBpbiBwcm9wcyB0byB0aGUgXFxgbmV4dC9pbWFnZVxcYCBjb21wb25lbnQuIFJlY2VpdmVkOiAke0pTT04uc3RyaW5naWZ5KFxuICAgICAgICAgIHsgd2lkdGgsIGhlaWdodCwgcXVhbGl0eSB9XG4gICAgICAgICl9YFxuICAgICAgKVxuICAgIH1cbiAgICBpZiAoIVZBTElEX0xBWU9VVF9WQUxVRVMuaW5jbHVkZXMobGF5b3V0KSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgaW52YWxpZCBcImxheW91dFwiIHByb3BlcnR5LiBQcm92aWRlZCBcIiR7bGF5b3V0fVwiIHNob3VsZCBiZSBvbmUgb2YgJHtWQUxJRF9MQVlPVVRfVkFMVUVTLm1hcChcbiAgICAgICAgICBTdHJpbmdcbiAgICAgICAgKS5qb2luKCcsJyl9LmBcbiAgICAgIClcbiAgICB9XG4gICAgaWYgKCFWQUxJRF9MT0FESU5HX1ZBTFVFUy5pbmNsdWRlcyhsb2FkaW5nKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgaW52YWxpZCBcImxvYWRpbmdcIiBwcm9wZXJ0eS4gUHJvdmlkZWQgXCIke2xvYWRpbmd9XCIgc2hvdWxkIGJlIG9uZSBvZiAke1ZBTElEX0xPQURJTkdfVkFMVUVTLm1hcChcbiAgICAgICAgICBTdHJpbmdcbiAgICAgICAgKS5qb2luKCcsJyl9LmBcbiAgICAgIClcbiAgICB9XG4gICAgaWYgKHByaW9yaXR5ICYmIGxvYWRpbmcgPT09ICdsYXp5Jykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgYm90aCBcInByaW9yaXR5XCIgYW5kIFwibG9hZGluZz0nbGF6eSdcIiBwcm9wZXJ0aWVzLiBPbmx5IG9uZSBzaG91bGQgYmUgdXNlZC5gXG4gICAgICApXG4gICAgfVxuICAgIGlmICh1bnNpemVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBkZXByZWNhdGVkIFwidW5zaXplZFwiIHByb3BlcnR5LCB3aGljaCB3YXMgcmVtb3ZlZCBpbiBmYXZvciBvZiB0aGUgXCJsYXlvdXQ9J2ZpbGwnXCIgcHJvcGVydHlgXG4gICAgICApXG4gICAgfVxuICB9XG5cbiAgbGV0IGlzTGF6eSA9XG4gICAgIXByaW9yaXR5ICYmIChsb2FkaW5nID09PSAnbGF6eScgfHwgdHlwZW9mIGxvYWRpbmcgPT09ICd1bmRlZmluZWQnKVxuICBpZiAoc3JjICYmIHNyYy5zdGFydHNXaXRoKCdkYXRhOicpKSB7XG4gICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSFRUUC9CYXNpY3Nfb2ZfSFRUUC9EYXRhX1VSSXNcbiAgICB1bm9wdGltaXplZCA9IHRydWVcbiAgICBpc0xhenkgPSBmYWxzZVxuICB9XG5cbiAgY29uc3QgW3NldFJlZiwgaXNJbnRlcnNlY3RlZF0gPSB1c2VJbnRlcnNlY3Rpb248SFRNTEltYWdlRWxlbWVudD4oe1xuICAgIHJvb3RNYXJnaW46ICcyMDBweCcsXG4gICAgZGlzYWJsZWQ6ICFpc0xhenksXG4gIH0pXG4gIGNvbnN0IGlzVmlzaWJsZSA9ICFpc0xhenkgfHwgaXNJbnRlcnNlY3RlZFxuXG4gIGNvbnN0IHdpZHRoSW50ID0gZ2V0SW50KHdpZHRoKVxuICBjb25zdCBoZWlnaHRJbnQgPSBnZXRJbnQoaGVpZ2h0KVxuICBjb25zdCBxdWFsaXR5SW50ID0gZ2V0SW50KHF1YWxpdHkpXG5cbiAgY29uc3QgTUlOX0lNR19TSVpFX0ZPUl9QTEFDRUhPTERFUiA9IDUwMDBcbiAgY29uc3QgdG9vU21hbGxGb3JCbHVycnlQbGFjZWhvbGRlciA9XG4gICAgd2lkdGhJbnQgJiYgaGVpZ2h0SW50ICYmIHdpZHRoSW50ICogaGVpZ2h0SW50IDwgTUlOX0lNR19TSVpFX0ZPUl9QTEFDRUhPTERFUlxuICBjb25zdCBzaG91bGRTaG93Qmx1cnJ5UGxhY2Vob2xkZXIgPVxuICAgIHBsYWNlaG9sZGVyID09PSAnYmx1cicgJiYgIXRvb1NtYWxsRm9yQmx1cnJ5UGxhY2Vob2xkZXJcblxuICBsZXQgd3JhcHBlclN0eWxlOiBKU1guSW50cmluc2ljRWxlbWVudHNbJ2RpdiddWydzdHlsZSddIHwgdW5kZWZpbmVkXG4gIGxldCBzaXplclN0eWxlOiBKU1guSW50cmluc2ljRWxlbWVudHNbJ2RpdiddWydzdHlsZSddIHwgdW5kZWZpbmVkXG4gIGxldCBzaXplclN2Zzogc3RyaW5nIHwgdW5kZWZpbmVkXG4gIGxldCBpbWdTdHlsZTogSW1nRWxlbWVudFN0eWxlIHwgdW5kZWZpbmVkID0ge1xuICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgIHRvcDogMCxcbiAgICBsZWZ0OiAwLFxuICAgIGJvdHRvbTogMCxcbiAgICByaWdodDogMCxcblxuICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgIHBhZGRpbmc6IDAsXG4gICAgYm9yZGVyOiAnbm9uZScsXG4gICAgbWFyZ2luOiAnYXV0bycsXG5cbiAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgIHdpZHRoOiAwLFxuICAgIGhlaWdodDogMCxcbiAgICBtaW5XaWR0aDogJzEwMCUnLFxuICAgIG1heFdpZHRoOiAnMTAwJScsXG4gICAgbWluSGVpZ2h0OiAnMTAwJScsXG4gICAgbWF4SGVpZ2h0OiAnMTAwJScsXG5cbiAgICBvYmplY3RGaXQsXG4gICAgb2JqZWN0UG9zaXRpb24sXG5cbiAgICAuLi4oc2hvdWxkU2hvd0JsdXJyeVBsYWNlaG9sZGVyXG4gICAgICA/IHtcbiAgICAgICAgICBiYWNrZ3JvdW5kU2l6ZTogJ2NvdmVyJyxcbiAgICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6IGB1cmwoXCIke2JsdXJEYXRhVVJMfVwiKWAsXG4gICAgICAgIH1cbiAgICAgIDogdW5kZWZpbmVkKSxcbiAgfVxuICBpZiAoXG4gICAgdHlwZW9mIHdpZHRoSW50ICE9PSAndW5kZWZpbmVkJyAmJlxuICAgIHR5cGVvZiBoZWlnaHRJbnQgIT09ICd1bmRlZmluZWQnICYmXG4gICAgbGF5b3V0ICE9PSAnZmlsbCdcbiAgKSB7XG4gICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiAvPlxuICAgIGNvbnN0IHF1b3RpZW50ID0gaGVpZ2h0SW50IC8gd2lkdGhJbnRcbiAgICBjb25zdCBwYWRkaW5nVG9wID0gaXNOYU4ocXVvdGllbnQpID8gJzEwMCUnIDogYCR7cXVvdGllbnQgKiAxMDB9JWBcbiAgICBpZiAobGF5b3V0ID09PSAncmVzcG9uc2l2ZScpIHtcbiAgICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgbGF5b3V0PVwicmVzcG9uc2l2ZVwiIC8+XG4gICAgICB3cmFwcGVyU3R5bGUgPSB7XG4gICAgICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG5cbiAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgIG1hcmdpbjogMCxcbiAgICAgIH1cbiAgICAgIHNpemVyU3R5bGUgPSB7IGRpc3BsYXk6ICdibG9jaycsIGJveFNpemluZzogJ2JvcmRlci1ib3gnLCBwYWRkaW5nVG9wIH1cbiAgICB9IGVsc2UgaWYgKGxheW91dCA9PT0gJ2ludHJpbnNpYycpIHtcbiAgICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgbGF5b3V0PVwiaW50cmluc2ljXCIgLz5cbiAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgZGlzcGxheTogJ2lubGluZS1ibG9jaycsXG4gICAgICAgIG1heFdpZHRoOiAnMTAwJScsXG4gICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG4gICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICBtYXJnaW46IDAsXG4gICAgICB9XG4gICAgICBzaXplclN0eWxlID0ge1xuICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICAgIH1cbiAgICAgIHNpemVyU3ZnID0gYDxzdmcgd2lkdGg9XCIke3dpZHRoSW50fVwiIGhlaWdodD1cIiR7aGVpZ2h0SW50fVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2ZXJzaW9uPVwiMS4xXCIvPmBcbiAgICB9IGVsc2UgaWYgKGxheW91dCA9PT0gJ2ZpeGVkJykge1xuICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiBsYXlvdXQ9XCJmaXhlZFwiIC8+XG4gICAgICB3cmFwcGVyU3R5bGUgPSB7XG4gICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICAgICAgd2lkdGg6IHdpZHRoSW50LFxuICAgICAgICBoZWlnaHQ6IGhlaWdodEludCxcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSBpZiAoXG4gICAgdHlwZW9mIHdpZHRoSW50ID09PSAndW5kZWZpbmVkJyAmJlxuICAgIHR5cGVvZiBoZWlnaHRJbnQgPT09ICd1bmRlZmluZWQnICYmXG4gICAgbGF5b3V0ID09PSAnZmlsbCdcbiAgKSB7XG4gICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgbGF5b3V0PVwiZmlsbFwiIC8+XG4gICAgd3JhcHBlclN0eWxlID0ge1xuICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcblxuICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICB0b3A6IDAsXG4gICAgICBsZWZ0OiAwLFxuICAgICAgYm90dG9tOiAwLFxuICAgICAgcmlnaHQ6IDAsXG5cbiAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgbWFyZ2luOiAwLFxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiAvPlxuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIG11c3QgdXNlIFwid2lkdGhcIiBhbmQgXCJoZWlnaHRcIiBwcm9wZXJ0aWVzIG9yIFwibGF5b3V0PSdmaWxsJ1wiIHByb3BlcnR5LmBcbiAgICAgIClcbiAgICB9XG4gIH1cblxuICBsZXQgaW1nQXR0cmlidXRlczogR2VuSW1nQXR0cnNSZXN1bHQgPSB7XG4gICAgc3JjOlxuICAgICAgJ2RhdGE6aW1hZ2UvZ2lmO2Jhc2U2NCxSMGxHT0RsaEFRQUJBSUFBQUFBQUFQLy8veUg1QkFFQUFBQUFMQUFBQUFBQkFBRUFBQUlCUkFBNycsXG4gICAgc3JjU2V0OiB1bmRlZmluZWQsXG4gICAgc2l6ZXM6IHVuZGVmaW5lZCxcbiAgfVxuXG4gIGlmIChpc1Zpc2libGUpIHtcbiAgICBpbWdBdHRyaWJ1dGVzID0gZ2VuZXJhdGVJbWdBdHRycyh7XG4gICAgICBzcmMsXG4gICAgICB1bm9wdGltaXplZCxcbiAgICAgIGxheW91dCxcbiAgICAgIHdpZHRoOiB3aWR0aEludCxcbiAgICAgIHF1YWxpdHk6IHF1YWxpdHlJbnQsXG4gICAgICBzaXplcyxcbiAgICAgIGxvYWRlcixcbiAgICB9KVxuICB9XG5cbiAgaWYgKHVuc2l6ZWQpIHtcbiAgICB3cmFwcGVyU3R5bGUgPSB1bmRlZmluZWRcbiAgICBzaXplclN0eWxlID0gdW5kZWZpbmVkXG4gICAgaW1nU3R5bGUgPSB1bmRlZmluZWRcbiAgfVxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3dyYXBwZXJTdHlsZX0+XG4gICAgICB7c2l6ZXJTdHlsZSA/IChcbiAgICAgICAgPGRpdiBzdHlsZT17c2l6ZXJTdHlsZX0+XG4gICAgICAgICAge3NpemVyU3ZnID8gKFxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIG1heFdpZHRoOiAnMTAwJScsXG4gICAgICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgICAgICAgICBtYXJnaW46IDAsXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMCxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgYWx0PVwiXCJcbiAgICAgICAgICAgICAgYXJpYS1oaWRkZW49e3RydWV9XG4gICAgICAgICAgICAgIHJvbGU9XCJwcmVzZW50YXRpb25cIlxuICAgICAgICAgICAgICBzcmM9e2BkYXRhOmltYWdlL3N2Zyt4bWw7YmFzZTY0LCR7dG9CYXNlNjQoc2l6ZXJTdmcpfWB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiBudWxsfVxuICAgICAgeyFpc1Zpc2libGUgJiYgKFxuICAgICAgICA8bm9zY3JpcHQ+XG4gICAgICAgICAgPGltZ1xuICAgICAgICAgICAgey4uLnJlc3R9XG4gICAgICAgICAgICB7Li4uZ2VuZXJhdGVJbWdBdHRycyh7XG4gICAgICAgICAgICAgIHNyYyxcbiAgICAgICAgICAgICAgdW5vcHRpbWl6ZWQsXG4gICAgICAgICAgICAgIGxheW91dCxcbiAgICAgICAgICAgICAgd2lkdGg6IHdpZHRoSW50LFxuICAgICAgICAgICAgICBxdWFsaXR5OiBxdWFsaXR5SW50LFxuICAgICAgICAgICAgICBzaXplcyxcbiAgICAgICAgICAgICAgbG9hZGVyLFxuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICBzcmM9e3NyY31cbiAgICAgICAgICAgIGRlY29kaW5nPVwiYXN5bmNcIlxuICAgICAgICAgICAgc2l6ZXM9e3NpemVzfVxuICAgICAgICAgICAgc3R5bGU9e2ltZ1N0eWxlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc05hbWV9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9ub3NjcmlwdD5cbiAgICAgICl9XG4gICAgICA8aW1nXG4gICAgICAgIHsuLi5yZXN0fVxuICAgICAgICB7Li4uaW1nQXR0cmlidXRlc31cbiAgICAgICAgZGVjb2Rpbmc9XCJhc3luY1wiXG4gICAgICAgIGNsYXNzTmFtZT17Y2xhc3NOYW1lfVxuICAgICAgICByZWY9eyhlbGVtZW50KSA9PiB7XG4gICAgICAgICAgc2V0UmVmKGVsZW1lbnQpXG4gICAgICAgICAgcmVtb3ZlUGxhY2Vob2xkZXIoZWxlbWVudCwgcGxhY2Vob2xkZXIpXG4gICAgICAgIH19XG4gICAgICAgIHN0eWxlPXtpbWdTdHlsZX1cbiAgICAgIC8+XG4gICAgICB7cHJpb3JpdHkgPyAoXG4gICAgICAgIC8vIE5vdGUgaG93IHdlIG9taXQgdGhlIGBocmVmYCBhdHRyaWJ1dGUsIGFzIGl0IHdvdWxkIG9ubHkgYmUgcmVsZXZhbnRcbiAgICAgICAgLy8gZm9yIGJyb3dzZXJzIHRoYXQgZG8gbm90IHN1cHBvcnQgYGltYWdlc3Jjc2V0YCwgYW5kIGluIHRob3NlIGNhc2VzXG4gICAgICAgIC8vIGl0IHdvdWxkIGxpa2VseSBjYXVzZSB0aGUgaW5jb3JyZWN0IGltYWdlIHRvIGJlIHByZWxvYWRlZC5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gaHR0cHM6Ly9odG1sLnNwZWMud2hhdHdnLm9yZy9tdWx0aXBhZ2Uvc2VtYW50aWNzLmh0bWwjYXR0ci1saW5rLWltYWdlc3Jjc2V0XG4gICAgICAgIDxIZWFkPlxuICAgICAgICAgIDxsaW5rXG4gICAgICAgICAgICBrZXk9e1xuICAgICAgICAgICAgICAnX19uaW1nLScgK1xuICAgICAgICAgICAgICBpbWdBdHRyaWJ1dGVzLnNyYyArXG4gICAgICAgICAgICAgIGltZ0F0dHJpYnV0ZXMuc3JjU2V0ICtcbiAgICAgICAgICAgICAgaW1nQXR0cmlidXRlcy5zaXplc1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVsPVwicHJlbG9hZFwiXG4gICAgICAgICAgICBhcz1cImltYWdlXCJcbiAgICAgICAgICAgIGhyZWY9e2ltZ0F0dHJpYnV0ZXMuc3JjU2V0ID8gdW5kZWZpbmVkIDogaW1nQXR0cmlidXRlcy5zcmN9XG4gICAgICAgICAgICAvLyBAdHMtaWdub3JlOiBpbWFnZXNyY3NldCBpcyBub3QgeWV0IGluIHRoZSBsaW5rIGVsZW1lbnQgdHlwZVxuICAgICAgICAgICAgaW1hZ2VzcmNzZXQ9e2ltZ0F0dHJpYnV0ZXMuc3JjU2V0fVxuICAgICAgICAgICAgLy8gQHRzLWlnbm9yZTogaW1hZ2VzaXplcyBpcyBub3QgeWV0IGluIHRoZSBsaW5rIGVsZW1lbnQgdHlwZVxuICAgICAgICAgICAgaW1hZ2VzaXplcz17aW1nQXR0cmlidXRlcy5zaXplc31cbiAgICAgICAgICA+PC9saW5rPlxuICAgICAgICA8L0hlYWQ+XG4gICAgICApIDogbnVsbH1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG4vL0JVSUxUIElOIExPQURFUlNcblxuZnVuY3Rpb24gbm9ybWFsaXplU3JjKHNyYzogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHNyY1swXSA9PT0gJy8nID8gc3JjLnNsaWNlKDEpIDogc3JjXG59XG5cbmZ1bmN0aW9uIGltZ2l4TG9hZGVyKHtcbiAgcm9vdCxcbiAgc3JjLFxuICB3aWR0aCxcbiAgcXVhbGl0eSxcbn06IERlZmF1bHRJbWFnZUxvYWRlclByb3BzKTogc3RyaW5nIHtcbiAgLy8gRGVtbzogaHR0cHM6Ly9zdGF0aWMuaW1naXgubmV0L2RhaXN5LnBuZz9mb3JtYXQ9YXV0byZmaXQ9bWF4Jnc9MzAwXG4gIGNvbnN0IHBhcmFtcyA9IFsnYXV0bz1mb3JtYXQnLCAnZml0PW1heCcsICd3PScgKyB3aWR0aF1cbiAgbGV0IHBhcmFtc1N0cmluZyA9ICcnXG4gIGlmIChxdWFsaXR5KSB7XG4gICAgcGFyYW1zLnB1c2goJ3E9JyArIHF1YWxpdHkpXG4gIH1cblxuICBpZiAocGFyYW1zLmxlbmd0aCkge1xuICAgIHBhcmFtc1N0cmluZyA9ICc/JyArIHBhcmFtcy5qb2luKCcmJylcbiAgfVxuICByZXR1cm4gYCR7cm9vdH0ke25vcm1hbGl6ZVNyYyhzcmMpfSR7cGFyYW1zU3RyaW5nfWBcbn1cblxuZnVuY3Rpb24gYWthbWFpTG9hZGVyKHsgcm9vdCwgc3JjLCB3aWR0aCB9OiBEZWZhdWx0SW1hZ2VMb2FkZXJQcm9wcyk6IHN0cmluZyB7XG4gIHJldHVybiBgJHtyb290fSR7bm9ybWFsaXplU3JjKHNyYyl9P2ltd2lkdGg9JHt3aWR0aH1gXG59XG5cbmZ1bmN0aW9uIGNsb3VkaW5hcnlMb2FkZXIoe1xuICByb290LFxuICBzcmMsXG4gIHdpZHRoLFxuICBxdWFsaXR5LFxufTogRGVmYXVsdEltYWdlTG9hZGVyUHJvcHMpOiBzdHJpbmcge1xuICAvLyBEZW1vOiBodHRwczovL3Jlcy5jbG91ZGluYXJ5LmNvbS9kZW1vL2ltYWdlL3VwbG9hZC93XzMwMCxjX2xpbWl0LHFfYXV0by90dXJ0bGVzLmpwZ1xuICBjb25zdCBwYXJhbXMgPSBbJ2ZfYXV0bycsICdjX2xpbWl0JywgJ3dfJyArIHdpZHRoLCAncV8nICsgKHF1YWxpdHkgfHwgJ2F1dG8nKV1cbiAgbGV0IHBhcmFtc1N0cmluZyA9IHBhcmFtcy5qb2luKCcsJykgKyAnLydcbiAgcmV0dXJuIGAke3Jvb3R9JHtwYXJhbXNTdHJpbmd9JHtub3JtYWxpemVTcmMoc3JjKX1gXG59XG5cbmZ1bmN0aW9uIGRlZmF1bHRMb2FkZXIoe1xuICByb290LFxuICBzcmMsXG4gIHdpZHRoLFxuICBxdWFsaXR5LFxufTogRGVmYXVsdEltYWdlTG9hZGVyUHJvcHMpOiBzdHJpbmcge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGNvbnN0IG1pc3NpbmdWYWx1ZXMgPSBbXVxuXG4gICAgLy8gdGhlc2Ugc2hvdWxkIGFsd2F5cyBiZSBwcm92aWRlZCBidXQgbWFrZSBzdXJlIHRoZXkgYXJlXG4gICAgaWYgKCFzcmMpIG1pc3NpbmdWYWx1ZXMucHVzaCgnc3JjJylcbiAgICBpZiAoIXdpZHRoKSBtaXNzaW5nVmFsdWVzLnB1c2goJ3dpZHRoJylcblxuICAgIGlmIChtaXNzaW5nVmFsdWVzLmxlbmd0aCA+IDApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYE5leHQgSW1hZ2UgT3B0aW1pemF0aW9uIHJlcXVpcmVzICR7bWlzc2luZ1ZhbHVlcy5qb2luKFxuICAgICAgICAgICcsICdcbiAgICAgICAgKX0gdG8gYmUgcHJvdmlkZWQuIE1ha2Ugc3VyZSB5b3UgcGFzcyB0aGVtIGFzIHByb3BzIHRvIHRoZSBcXGBuZXh0L2ltYWdlXFxgIGNvbXBvbmVudC4gUmVjZWl2ZWQ6ICR7SlNPTi5zdHJpbmdpZnkoXG4gICAgICAgICAgeyBzcmMsIHdpZHRoLCBxdWFsaXR5IH1cbiAgICAgICAgKX1gXG4gICAgICApXG4gICAgfVxuXG4gICAgaWYgKHNyYy5zdGFydHNXaXRoKCcvLycpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBGYWlsZWQgdG8gcGFyc2Ugc3JjIFwiJHtzcmN9XCIgb24gXFxgbmV4dC9pbWFnZVxcYCwgcHJvdG9jb2wtcmVsYXRpdmUgVVJMICgvLykgbXVzdCBiZSBjaGFuZ2VkIHRvIGFuIGFic29sdXRlIFVSTCAoaHR0cDovLyBvciBodHRwczovLylgXG4gICAgICApXG4gICAgfVxuXG4gICAgaWYgKCFzcmMuc3RhcnRzV2l0aCgnLycpICYmIGNvbmZpZ0RvbWFpbnMpIHtcbiAgICAgIGxldCBwYXJzZWRTcmM6IFVSTFxuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VkU3JjID0gbmV3IFVSTChzcmMpXG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihlcnIpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICBgRmFpbGVkIHRvIHBhcnNlIHNyYyBcIiR7c3JjfVwiIG9uIFxcYG5leHQvaW1hZ2VcXGAsIGlmIHVzaW5nIHJlbGF0aXZlIGltYWdlIGl0IG11c3Qgc3RhcnQgd2l0aCBhIGxlYWRpbmcgc2xhc2ggXCIvXCIgb3IgYmUgYW4gYWJzb2x1dGUgVVJMIChodHRwOi8vIG9yIGh0dHBzOi8vKWBcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICBpZiAoIWNvbmZpZ0RvbWFpbnMuaW5jbHVkZXMocGFyc2VkU3JjLmhvc3RuYW1lKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYEludmFsaWQgc3JjIHByb3AgKCR7c3JjfSkgb24gXFxgbmV4dC9pbWFnZVxcYCwgaG9zdG5hbWUgXCIke3BhcnNlZFNyYy5ob3N0bmFtZX1cIiBpcyBub3QgY29uZmlndXJlZCB1bmRlciBpbWFnZXMgaW4geW91ciBcXGBuZXh0LmNvbmZpZy5qc1xcYFxcbmAgK1xuICAgICAgICAgICAgYFNlZSBtb3JlIGluZm86IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL25leHQtaW1hZ2UtdW5jb25maWd1cmVkLWhvc3RgXG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gYCR7cm9vdH0/dXJsPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHNyYyl9Jnc9JHt3aWR0aH0mcT0ke3F1YWxpdHkgfHwgNzV9YFxufVxuIiwidHlwZSBSZXF1ZXN0SWRsZUNhbGxiYWNrSGFuZGxlID0gYW55XG50eXBlIFJlcXVlc3RJZGxlQ2FsbGJhY2tPcHRpb25zID0ge1xuICB0aW1lb3V0OiBudW1iZXJcbn1cbnR5cGUgUmVxdWVzdElkbGVDYWxsYmFja0RlYWRsaW5lID0ge1xuICByZWFkb25seSBkaWRUaW1lb3V0OiBib29sZWFuXG4gIHRpbWVSZW1haW5pbmc6ICgpID0+IG51bWJlclxufVxuXG5kZWNsYXJlIGdsb2JhbCB7XG4gIGludGVyZmFjZSBXaW5kb3cge1xuICAgIHJlcXVlc3RJZGxlQ2FsbGJhY2s6IChcbiAgICAgIGNhbGxiYWNrOiAoZGVhZGxpbmU6IFJlcXVlc3RJZGxlQ2FsbGJhY2tEZWFkbGluZSkgPT4gdm9pZCxcbiAgICAgIG9wdHM/OiBSZXF1ZXN0SWRsZUNhbGxiYWNrT3B0aW9uc1xuICAgICkgPT4gUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZVxuICAgIGNhbmNlbElkbGVDYWxsYmFjazogKGlkOiBSZXF1ZXN0SWRsZUNhbGxiYWNrSGFuZGxlKSA9PiB2b2lkXG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IHJlcXVlc3RJZGxlQ2FsbGJhY2sgPVxuICAodHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnICYmIHNlbGYucmVxdWVzdElkbGVDYWxsYmFjaykgfHxcbiAgZnVuY3Rpb24gKFxuICAgIGNiOiAoZGVhZGxpbmU6IFJlcXVlc3RJZGxlQ2FsbGJhY2tEZWFkbGluZSkgPT4gdm9pZFxuICApOiBOb2RlSlMuVGltZW91dCB7XG4gICAgbGV0IHN0YXJ0ID0gRGF0ZS5ub3coKVxuICAgIHJldHVybiBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgIGNiKHtcbiAgICAgICAgZGlkVGltZW91dDogZmFsc2UsXG4gICAgICAgIHRpbWVSZW1haW5pbmc6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICByZXR1cm4gTWF0aC5tYXgoMCwgNTAgLSAoRGF0ZS5ub3coKSAtIHN0YXJ0KSlcbiAgICAgICAgfSxcbiAgICAgIH0pXG4gICAgfSwgMSlcbiAgfVxuXG5leHBvcnQgY29uc3QgY2FuY2VsSWRsZUNhbGxiYWNrID1cbiAgKHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyAmJiBzZWxmLmNhbmNlbElkbGVDYWxsYmFjaykgfHxcbiAgZnVuY3Rpb24gKGlkOiBSZXF1ZXN0SWRsZUNhbGxiYWNrSGFuZGxlKSB7XG4gICAgcmV0dXJuIGNsZWFyVGltZW91dChpZClcbiAgfVxuIiwiaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtcbiAgcmVxdWVzdElkbGVDYWxsYmFjayxcbiAgY2FuY2VsSWRsZUNhbGxiYWNrLFxufSBmcm9tICcuL3JlcXVlc3QtaWRsZS1jYWxsYmFjaydcblxudHlwZSBVc2VJbnRlcnNlY3Rpb25PYnNlcnZlckluaXQgPSBQaWNrPEludGVyc2VjdGlvbk9ic2VydmVySW5pdCwgJ3Jvb3RNYXJnaW4nPlxudHlwZSBVc2VJbnRlcnNlY3Rpb24gPSB7IGRpc2FibGVkPzogYm9vbGVhbiB9ICYgVXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0XG50eXBlIE9ic2VydmVDYWxsYmFjayA9IChpc1Zpc2libGU6IGJvb2xlYW4pID0+IHZvaWRcbnR5cGUgT2JzZXJ2ZXIgPSB7XG4gIGlkOiBzdHJpbmdcbiAgb2JzZXJ2ZXI6IEludGVyc2VjdGlvbk9ic2VydmVyXG4gIGVsZW1lbnRzOiBNYXA8RWxlbWVudCwgT2JzZXJ2ZUNhbGxiYWNrPlxufVxuXG5jb25zdCBoYXNJbnRlcnNlY3Rpb25PYnNlcnZlciA9IHR5cGVvZiBJbnRlcnNlY3Rpb25PYnNlcnZlciAhPT0gJ3VuZGVmaW5lZCdcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUludGVyc2VjdGlvbjxUIGV4dGVuZHMgRWxlbWVudD4oe1xuICByb290TWFyZ2luLFxuICBkaXNhYmxlZCxcbn06IFVzZUludGVyc2VjdGlvbik6IFsoZWxlbWVudDogVCB8IG51bGwpID0+IHZvaWQsIGJvb2xlYW5dIHtcbiAgY29uc3QgaXNEaXNhYmxlZDogYm9vbGVhbiA9IGRpc2FibGVkIHx8ICFoYXNJbnRlcnNlY3Rpb25PYnNlcnZlclxuXG4gIGNvbnN0IHVub2JzZXJ2ZSA9IHVzZVJlZjxGdW5jdGlvbj4oKVxuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBzZXRSZWYgPSB1c2VDYWxsYmFjayhcbiAgICAoZWw6IFQgfCBudWxsKSA9PiB7XG4gICAgICBpZiAodW5vYnNlcnZlLmN1cnJlbnQpIHtcbiAgICAgICAgdW5vYnNlcnZlLmN1cnJlbnQoKVxuICAgICAgICB1bm9ic2VydmUuY3VycmVudCA9IHVuZGVmaW5lZFxuICAgICAgfVxuXG4gICAgICBpZiAoaXNEaXNhYmxlZCB8fCB2aXNpYmxlKSByZXR1cm5cblxuICAgICAgaWYgKGVsICYmIGVsLnRhZ05hbWUpIHtcbiAgICAgICAgdW5vYnNlcnZlLmN1cnJlbnQgPSBvYnNlcnZlKFxuICAgICAgICAgIGVsLFxuICAgICAgICAgIChpc1Zpc2libGUpID0+IGlzVmlzaWJsZSAmJiBzZXRWaXNpYmxlKGlzVmlzaWJsZSksXG4gICAgICAgICAgeyByb290TWFyZ2luIH1cbiAgICAgICAgKVxuICAgICAgfVxuICAgIH0sXG4gICAgW2lzRGlzYWJsZWQsIHJvb3RNYXJnaW4sIHZpc2libGVdXG4gIClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIpIHtcbiAgICAgIGlmICghdmlzaWJsZSkge1xuICAgICAgICBjb25zdCBpZGxlQ2FsbGJhY2sgPSByZXF1ZXN0SWRsZUNhbGxiYWNrKCgpID0+IHNldFZpc2libGUodHJ1ZSkpXG4gICAgICAgIHJldHVybiAoKSA9PiBjYW5jZWxJZGxlQ2FsbGJhY2soaWRsZUNhbGxiYWNrKVxuICAgICAgfVxuICAgIH1cbiAgfSwgW3Zpc2libGVdKVxuXG4gIHJldHVybiBbc2V0UmVmLCB2aXNpYmxlXVxufVxuXG5mdW5jdGlvbiBvYnNlcnZlKFxuICBlbGVtZW50OiBFbGVtZW50LFxuICBjYWxsYmFjazogT2JzZXJ2ZUNhbGxiYWNrLFxuICBvcHRpb25zOiBVc2VJbnRlcnNlY3Rpb25PYnNlcnZlckluaXRcbik6ICgpID0+IHZvaWQge1xuICBjb25zdCB7IGlkLCBvYnNlcnZlciwgZWxlbWVudHMgfSA9IGNyZWF0ZU9ic2VydmVyKG9wdGlvbnMpXG4gIGVsZW1lbnRzLnNldChlbGVtZW50LCBjYWxsYmFjaylcblxuICBvYnNlcnZlci5vYnNlcnZlKGVsZW1lbnQpXG4gIHJldHVybiBmdW5jdGlvbiB1bm9ic2VydmUoKTogdm9pZCB7XG4gICAgZWxlbWVudHMuZGVsZXRlKGVsZW1lbnQpXG4gICAgb2JzZXJ2ZXIudW5vYnNlcnZlKGVsZW1lbnQpXG5cbiAgICAvLyBEZXN0cm95IG9ic2VydmVyIHdoZW4gdGhlcmUncyBub3RoaW5nIGxlZnQgdG8gd2F0Y2g6XG4gICAgaWYgKGVsZW1lbnRzLnNpemUgPT09IDApIHtcbiAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKVxuICAgICAgb2JzZXJ2ZXJzLmRlbGV0ZShpZClcbiAgICB9XG4gIH1cbn1cblxuY29uc3Qgb2JzZXJ2ZXJzID0gbmV3IE1hcDxzdHJpbmcsIE9ic2VydmVyPigpXG5mdW5jdGlvbiBjcmVhdGVPYnNlcnZlcihvcHRpb25zOiBVc2VJbnRlcnNlY3Rpb25PYnNlcnZlckluaXQpOiBPYnNlcnZlciB7XG4gIGNvbnN0IGlkID0gb3B0aW9ucy5yb290TWFyZ2luIHx8ICcnXG4gIGxldCBpbnN0YW5jZSA9IG9ic2VydmVycy5nZXQoaWQpXG4gIGlmIChpbnN0YW5jZSkge1xuICAgIHJldHVybiBpbnN0YW5jZVxuICB9XG5cbiAgY29uc3QgZWxlbWVudHMgPSBuZXcgTWFwPEVsZW1lbnQsIE9ic2VydmVDYWxsYmFjaz4oKVxuICBjb25zdCBvYnNlcnZlciA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcigoZW50cmllcykgPT4ge1xuICAgIGVudHJpZXMuZm9yRWFjaCgoZW50cnkpID0+IHtcbiAgICAgIGNvbnN0IGNhbGxiYWNrID0gZWxlbWVudHMuZ2V0KGVudHJ5LnRhcmdldClcbiAgICAgIGNvbnN0IGlzVmlzaWJsZSA9IGVudHJ5LmlzSW50ZXJzZWN0aW5nIHx8IGVudHJ5LmludGVyc2VjdGlvblJhdGlvID4gMFxuICAgICAgaWYgKGNhbGxiYWNrICYmIGlzVmlzaWJsZSkge1xuICAgICAgICBjYWxsYmFjayhpc1Zpc2libGUpXG4gICAgICB9XG4gICAgfSlcbiAgfSwgb3B0aW9ucylcblxuICBvYnNlcnZlcnMuc2V0KFxuICAgIGlkLFxuICAgIChpbnN0YW5jZSA9IHtcbiAgICAgIGlkLFxuICAgICAgb2JzZXJ2ZXIsXG4gICAgICBlbGVtZW50cyxcbiAgICB9KVxuICApXG4gIHJldHVybiBpbnN0YW5jZVxufVxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2Rpc3QvY2xpZW50L2ltYWdlJylcbiIsImltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCc7XG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MnO1xuaW1wb3J0IHtjcmVhdGVDbGllbnR9IGZyb20gJ2NvbnRlbnRmdWwnO1xuaW1wb3J0IEhvbWVQYWdlIGZyb20gJy4uL2NvbXBvbmVudHMvTGF5b3V0L2NvbXBvbmVudHMvcGFnZV9jb21wb25lbnQvSG9tZVBhZ2UnO1xuXG5cbmV4cG9ydCBhc3luYyAgZnVuY3Rpb24gZ2V0U3RhdGljUHJvcHMoKVxue1xuICBjb25zdCBjbGllbnQgPSBjcmVhdGVDbGllbnQoe1xuICAgc3BhY2U6cHJvY2Vzcy5lbnYuQ09OVEVOVEZVTF9TUEFDRV9JRCxcbiAgICBhY2Nlc3NUb2tlbjpwcm9jZXNzLmVudi5DT05URU5URlVMX0FDQ0VTU19LRVksXG4gIH0pXG4gIGNvbnN0IHJlcz1hd2FpdCBjbGllbnQuZ2V0RW50cmllcyh7Y29udGVudF90eXBlOidsb2RoYUdvdXAnfSlcbiAgY29uc29sZS5sb2cocmVzKTtcbiAgcmV0dXJuIHtcbiAgICBwcm9wczp7XG4gICAgICBhcnRpY2xlczpyZXMuaXRlbXNcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSh7YXJ0aWNsZXN9KSB7XG4gIGNvbnNvbGUud2FybihhcnRpY2xlcylcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAge2FydGljbGVzLm1hcCgoYXJ0aWNsZSxpbmRleCk9PlxuICAgICAgPEhvbWVQYWdlIGtleT17aW5kZXh9IGFydGljbGU9e2FydGljbGV9IC8+XG4gICAgICBcbiAgICApfVxuICAgIDwvZGl2PlxuICApXG59XG4iLCIvLyBFeHBvcnRzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJjb250YWluZXJcIjogXCJIb21lX2NvbnRhaW5lcl9fMUVjc1VcIixcblx0XCJtYWluXCI6IFwiSG9tZV9tYWluX18xeDhnQ1wiLFxuXHRcImZvb3RlclwiOiBcIkhvbWVfZm9vdGVyX18xV2RoRFwiLFxuXHRcInRpdGxlXCI6IFwiSG9tZV90aXRsZV9fM0RqUjdcIixcblx0XCJkZXNjcmlwdGlvblwiOiBcIkhvbWVfZGVzY3JpcHRpb25fXzE3WjRGXCIsXG5cdFwiY29kZVwiOiBcIkhvbWVfY29kZV9fYXh4MllcIixcblx0XCJncmlkXCI6IFwiSG9tZV9ncmlkX18yRWkyRlwiLFxuXHRcImNhcmRcIjogXCJIb21lX2NhcmRfXzJTZHRCXCIsXG5cdFwibG9nb1wiOiBcIkhvbWVfbG9nb19fMVlickhcIlxufTtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0FwcEJhclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9JY29uQnV0dG9uXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL1Rvb2xiYXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvVHlwb2dyYXBoeVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9BaXJsaW5lU2VhdEZsYXRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zL0ZhY2Vib29rXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9JbnN0YWdyYW1cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zL0xpbmtlZEluXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9Mb2NhdGlvbk9uXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9NYWlsT3V0bGluZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvaWNvbnMvTWVudVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvaWNvbnMvUGhvbmVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiY29udGVudGZ1bFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2R5bmFtaWNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9oZWFkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvcm91dGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LWJvb3RzdHJhcC9DYXJvdXNlbFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1vd2wtY2Fyb3VzZWxcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=